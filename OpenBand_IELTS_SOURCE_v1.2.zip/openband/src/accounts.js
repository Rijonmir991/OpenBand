/* OpenBand — student accounts, certificate generator, how-to-use guide */
(function () {
  const { $, $$, esc, on, icon, store, toast, modal, confirmBox, bandLabel, overallBand, fmtDate, today, uid } = OB;
  const bn = () => store.s.settings.lang === 'bn';
  const L = (en, b) => bn() ? b : en;
  const BANDS = [5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9];
  const fieldErr = (root, errs) => { $$('[data-e]', root).forEach(x => x.textContent = ''); Object.entries(errs || {}).forEach(([k, m]) => { const el = $(`[data-e="${k}"]`, root); if (el) el.textContent = m; }); };
  OB.requireLoginGate = (v, what) => {
    v.innerHTML = `<div class="wrap section" style="max-width:560px"><div class="card center" style="padding:34px"><div class="mod-icon mod-L" style="margin:0 auto">${icon('lock', 24)}</div><h2 style="margin-top:14px">${L('Please log in to continue', 'চালিয়ে যেতে লগ ইন করুন')}</h2><p class="muted">${L(`The administrator requires a free account for ${what}.`, `${what}-এর জন্য একটি ফ্রি অ্যাকাউন্ট দরকার।`)}</p><div class="row" style="justify-content:center"><a class="btn btn-primary" href="#/account?tab=register">${L('Create free account', 'ফ্রি অ্যাকাউন্ট খুলুন')}</a><a class="btn btn-ghost" href="#/account?tab=login">${L('Log in', 'লগ ইন')}</a></div></div></div>`;
  };

  /* ---------- ACCOUNT ---------- */
  OB.route('/account', () => {
    const v = OB.page('Account'); const me = OB.me(); const q = OB.query();
    if (!me) return authPage(v, q.tab || 'login');
    profilePage(v, me);
  });
  function authPage(v, tab) {
    const guestHas = store.s.attempts.length || store.s.writing.length || store.s.speaking.length; const gp = store.s.profile || {};
    v.innerHTML = `<div class="auth-wrap"><div class="auth-side"><div>${OB.LOGO(46)}<h2 style="color:#fff;margin:22px 0 10px">${L('Your free IELTS study space', 'আপনার ফ্রি IELTS পড়ার জায়গা')}</h2>
      <p style="color:#C9D3F2">${L('Save your results under your own name, track your bands, continue on any visit and earn certificates — all free.', 'নিজের নামে ফলাফল সেভ করুন, ব্যান্ড ট্র্যাক করুন, যেকোনো সময় চালিয়ে যান আর সার্টিফিকেট নিন — সবকিছু ফ্রি।')}</p>
      <ul class="auth-points">${[L('All tests and mock exams — free', 'সব টেস্ট ও মক পরীক্ষা — ফ্রি'), L('Progress saved to your profile', 'অগ্রগতি আপনার প্রোফাইলে সেভ থাকে'), L('Printable achievement certificate', 'প্রিন্টযোগ্য অর্জন সার্টিফিকেট'), L('No payment, ever', 'কখনো কোনো পেমেন্ট নেই')].map(x => `<li>${icon('check', 16)} ${x}</li>`).join('')}</ul></div>
      <p class="tiny" style="color:#8E9BC4">${L('Your password is stored only as a secure hash.', 'আপনার পাসওয়ার্ড শুধু নিরাপদ হ্যাশ আকারে সংরক্ষিত হয়।')}</p></div>
      <div class="auth-main"><div class="seg" style="margin-bottom:18px" data-at><button data-v="login">${L('Log in', 'লগ ইন')}</button><button data-v="register">${L('Create account', 'অ্যাকাউন্ট খুলুন')}</button></div><div data-form></div>
      <p class="small muted center" style="margin-top:16px"><a href="#/dashboard">${L('Continue as guest', 'অতিথি হিসেবে চালিয়ে যান')}</a></p></div></div>`;
    const f = $('[data-form]', v);
    const draw = () => {
      $$('[data-at] button', v).forEach(b => b.classList.toggle('on', b.dataset.v === tab));
      if (tab === 'login') {
        f.innerHTML = `<form data-login novalidate><h2>${L('Welcome back', 'আবার স্বাগতম')}</h2><div class="field"><label class="lbl" for="li">${L('Email, phone or roll ID', 'ইমেইল, ফোন বা রোল আইডি')}</label><input class="input" id="li" name="id" autocomplete="username" required></div>
          <div class="field"><label class="lbl" for="lp">${L('Password', 'পাসওয়ার্ড')}</label><div class="pw-wrap"><input class="input" id="lp" name="pw" type="password" autocomplete="current-password" required><button type="button" class="pw-eye" data-eye aria-label="Show password">${icon('eye', 16)}</button></div></div>
          <div class="err" data-err></div><button class="btn btn-primary btn-block btn-lg" type="submit">${L('Log in', 'লগ ইন')}</button>
          <p class="small muted" style="margin-top:12px">${L('Forgot your password? Ask your administrator to reset it.', 'পাসওয়ার্ড ভুলে গেছেন? অ্যাডমিনকে রিসেট করতে বলুন।')}</p></form>`;
        $('[data-login]', f).onsubmit = async e => {
          e.preventDefault(); const d = Object.fromEntries(new FormData(e.target)); const err = $('[data-err]', f); const btn = $('button[type=submit]', f);
          if (!d.id.trim() || !d.pw) return err.textContent = L('Enter your login details.', 'লগইনের তথ্য দিন।');
          btn.disabled = true; btn.innerHTML = '<span class="loader"></span>';
          try { const u = await OB.auth.login(d.id, d.pw); toast(L(`Welcome back, ${u.name.split(' ')[0]}!`, `আবার স্বাগতম, ${u.name.split(' ')[0]}!`), 'ok'); OB.shell(); OB.go('#/dashboard'); }
          catch (ex) { err.textContent = L(ex.message, { 'Incorrect login details.': 'লগইনের তথ্য সঠিক নয়।', 'This account has been disabled. Please contact the administrator.': 'এই অ্যাকাউন্টটি বন্ধ করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।', 'Too many attempts. Please wait a minute and try again.': 'অনেকবার চেষ্টা হয়েছে। এক মিনিট পর আবার চেষ্টা করুন।' }[ex.message] || ex.message); btn.disabled = false; btn.textContent = L('Log in', 'লগ ইন'); }
        };
      } else {
        if (!store.s.settings.allowRegister) { f.innerHTML = `<div class="empty">${L('New registrations are currently closed by the administrator.', 'অ্যাডমিন এখন নতুন রেজিস্ট্রেশন বন্ধ রেখেছেন।')}</div>`; return; }
        f.innerHTML = `<form data-reg novalidate><h2>${L('Create your free account', 'আপনার ফ্রি অ্যাকাউন্ট খুলুন')}</h2>
          <div class="grid g2" style="gap:0 14px"><div class="field"><label class="lbl" for="rn">${L('Full name', 'পূর্ণ নাম')} *</label><input class="input" id="rn" name="name" value="${esc(gp.name || '')}" autocomplete="name"><div class="err" data-e="name"></div></div>
          <div class="field"><label class="lbl" for="rr">${L('Roll / Student ID (optional)', 'রোল / স্টুডেন্ট আইডি (ঐচ্ছিক)')}</label><input class="input" id="rr" name="roll"><div class="err" data-e="roll"></div></div>
          <div class="field"><label class="lbl" for="re">${L('Email', 'ইমেইল')}</label><input class="input" id="re" name="email" type="email" value="${esc(gp.email || '')}" autocomplete="email"><div class="err" data-e="email"></div></div>
          <div class="field"><label class="lbl" for="rp">${L('Phone', 'ফোন')}</label><input class="input" id="rp" name="phone" type="tel" placeholder="01XXXXXXXXX" autocomplete="tel"><div class="err" data-e="phone"></div></div>
          <div class="field"><label class="lbl" for="rw">${L('Password', 'পাসওয়ার্ড')} *</label><input class="input" id="rw" name="password" type="password" autocomplete="new-password"><div class="err" data-e="password"></div></div>
          <div class="field"><label class="lbl" for="rw2">${L('Confirm password', 'পাসওয়ার্ড আবার লিখুন')} *</label><input class="input" id="rw2" name="password2" type="password" autocomplete="new-password"><div class="err" data-e="password2"></div></div>
          <div class="field"><label class="lbl" for="rt">${L('Target band', 'লক্ষ্য ব্যান্ড')}</label><select class="select" id="rt" name="target">${BANDS.map(b => `<option ${b === (gp.target || 6.5) ? 'selected' : ''}>${bandLabel(b)}</option>`).join('')}</select></div>
          <div class="field"><label class="lbl" for="ry">${L('Test type', 'টেস্টের ধরন')}</label><select class="select" id="ry" name="type"><option value="academic">Academic</option><option value="general" ${gp.type === 'general' ? 'selected' : ''}>General Training</option></select></div>
          <div class="field"><label class="lbl" for="ri">${L('Institution (optional)', 'প্রতিষ্ঠান (ঐচ্ছিক)')}</label><input class="input" id="ri" name="institution"></div>
          <div class="field"><label class="lbl" for="rc">${L('Target country (optional)', 'লক্ষ্য দেশ (ঐচ্ছিক)')}</label><input class="input" id="rc" name="country" placeholder="UK, Canada, Australia…"></div>
          <div class="field"><label class="lbl" for="rd">${L('Exam date (optional)', 'পরীক্ষার তারিখ (ঐচ্ছিক)')}</label><input class="input" id="rd" name="examDate" type="date"></div></div>
          <p class="tiny muted" style="margin-top:-4px">${L('Give an email or a phone number (or both). You can log in with either, or with your roll ID.', 'ইমেইল বা ফোন নম্বর দিন (বা দুটোই)। যেকোনোটি বা রোল আইডি দিয়ে লগ ইন করা যাবে।')}</p>
          ${guestHas ? `<label class="row small" style="gap:8px;margin:8px 0"><input type="checkbox" name="keep" checked> ${L('Keep my guest progress in this account', 'অতিথি হিসেবে করা অগ্রগতি এই অ্যাকাউন্টে রাখুন')}</label>` : ''}
          <div class="err" data-err></div><button class="btn btn-primary btn-block btn-lg" type="submit">${L('Create account', 'অ্যাকাউন্ট খুলুন')}</button></form>`;
        $('[data-reg]', f).onsubmit = async e => {
          e.preventDefault(); const d = Object.fromEntries(new FormData(e.target)); const btn = $('button[type=submit]', f);
          btn.disabled = true; btn.innerHTML = '<span class="loader"></span>';
          try { const u = await OB.auth.register(d, !!d.keep); store.s.profile = null; store.save(true); toast(L(`Account created. Welcome, ${u.name.split(' ')[0]}!`, `অ্যাকাউন্ট তৈরি হয়েছে। স্বাগতম, ${u.name.split(' ')[0]}!`), 'ok'); OB.shell(); OB.go('#/dashboard'); }
          catch (ex) { fieldErr(f, ex.fields); $('[data-err]', f).textContent = ex.message; btn.disabled = false; btn.textContent = L('Create account', 'অ্যাকাউন্ট খুলুন'); }
        };
      }
      const eye = $('[data-eye]', f); if (eye) eye.onclick = () => { const i = $('#lp', f); i.type = i.type === 'password' ? 'text' : 'password'; };
      setTimeout(() => { const i = $('input', f); i && i.focus(); }, 30);
    };
    on(v, 'click', '[data-at] button', (e, b) => { tab = b.dataset.v; draw(); }); draw();
  }
  function profilePage(v, me) {
    const st = store.s.settings;
    const initials = me.name.split(/\s+/).map(x => x[0]).slice(0, 2).join('').toUpperCase();
    v.innerHTML = `<div class="page-head"><div class="wrap"><div class="row" style="gap:16px"><div class="avatar-lg">${esc(initials)}</div><div><span class="eyebrow">${icon('user', 16)} ${L('My profile', 'আমার প্রোফাইল')}</span><h1 style="font-size:2rem;margin:2px 0" data-notr>${esc(me.name)}</h1><div class="row small muted">${me.roll ? `<span class="chip">${L('Roll', 'রোল')}: ${esc(me.roll)}</span>` : ''}<span class="chip blue">${me.type === 'general' ? 'General Training' : 'Academic'}</span><span class="chip mint">${L('Target', 'লক্ষ্য')} ${bandLabel(me.target)}</span><span>${L('Member since', 'সদস্য')} ${fmtDate(me.created)}</span></div></div><button class="btn btn-ghost" style="margin-left:auto" data-logout>${icon('logout', 16)} ${L('Log out', 'লগ আউট')}</button></div></div></div>
    <div class="wrap" style="padding-bottom:40px"><div class="grid g2" style="align-items:start">
      <div class="stack"><div class="card"><h3>${L('Edit profile', 'প্রোফাইল সম্পাদনা')}</h3><form data-prof novalidate><div class="grid g2" style="gap:0 14px">
        <div class="field"><label class="lbl">${L('Full name', 'পূর্ণ নাম')}</label><input class="input" name="name" value="${esc(me.name)}"><div class="err" data-e="name"></div></div>
        <div class="field"><label class="lbl">${L('Roll / Student ID (optional)', 'রোল / স্টুডেন্ট আইডি (ঐচ্ছিক)')}</label><input class="input" name="roll" value="${esc(me.roll)}"><div class="err" data-e="roll"></div></div>
        <div class="field"><label class="lbl">${L('Email', 'ইমেইল')}</label><input class="input" name="email" type="email" value="${esc(me.email)}"><div class="err" data-e="email"></div></div>
        <div class="field"><label class="lbl">${L('Phone', 'ফোন')}</label><input class="input" name="phone" value="${esc(me.phone)}"><div class="err" data-e="phone"></div></div>
        <div class="field"><label class="lbl">${L('Target band', 'লক্ষ্য ব্যান্ড')}</label><select class="select" name="target">${BANDS.map(b => `<option ${b === me.target ? 'selected' : ''}>${bandLabel(b)}</option>`).join('')}</select></div>
        <div class="field"><label class="lbl">${L('Test type', 'টেস্টের ধরন')}</label><select class="select" name="type"><option value="academic">Academic</option><option value="general" ${me.type === 'general' ? 'selected' : ''}>General Training</option></select></div>
        <div class="field"><label class="lbl">${L('Institution (optional)', 'প্রতিষ্ঠান (ঐচ্ছিক)')}</label><input class="input" name="institution" value="${esc(me.institution)}"></div>
        <div class="field"><label class="lbl">${L('Target country (optional)', 'লক্ষ্য দেশ (ঐচ্ছিক)')}</label><input class="input" name="country" value="${esc(me.country)}"></div>
        <div class="field"><label class="lbl">${L('Exam date (optional)', 'পরীক্ষার তারিখ (ঐচ্ছিক)')}</label><input class="input" name="examDate" type="date" value="${esc(me.examDate)}"></div>
        <div class="field"><label class="lbl">${L('Daily goal (activities per day)', 'দৈনিক লক্ষ্য (প্রতিদিন কতটি কাজ)')}</label><input class="input" name="goal" type="number" min="1" max="20" value="${me.dailyGoal || st.dailyGoal}"></div></div>
        <button class="btn btn-primary" type="submit">${L('Save profile', 'প্রোফাইল সেভ করুন')}</button></form></div>
        <div class="card"><h3>${L('Change password', 'পাসওয়ার্ড বদলান')}</h3><form data-pw class="grid g2" style="gap:0 14px" novalidate><div class="field"><label class="lbl">${L('Current password', 'বর্তমান পাসওয়ার্ড')}</label><input class="input" type="password" name="old" autocomplete="current-password"></div><div class="field"><label class="lbl">${L('New password', 'নতুন পাসওয়ার্ড')}</label><input class="input" type="password" name="np" autocomplete="new-password"></div><div class="err" data-pwerr style="grid-column:1/-1"></div><div><button class="btn btn-ghost" type="submit">${L('Change password', 'পাসওয়ার্ড বদলান')}</button></div></form></div></div>
      <div class="stack"><div class="card"><h3>${L('Preferences', 'পছন্দসমূহ')}</h3><div class="row between"><span>${L('Theme', 'থিম')}</span><div class="seg" data-th><button data-v="light">${L('Light', 'লাইট')}</button><button data-v="dark">${L('Dark', 'ডার্ক')}</button><button data-v="">${L('System', 'সিস্টেম')}</button></div></div><div class="hr"></div><div class="row between"><span>${L('Interface language', 'ইন্টারফেসের ভাষা')}</span><div class="seg" data-lg><button data-v="en">English</button><button data-v="bn">বাংলা</button></div></div><p class="tiny muted" style="margin-top:8px">${L('Practice questions and answers always remain in English.', 'অনুশীলনের প্রশ্ন ও উত্তর সবসময় ইংরেজিতে থাকবে।')}</p></div>
        <div class="card"><h3>${L('Recent sign-ins', 'সাম্প্রতিক লগইন')}</h3><ul class="list-clean">${(me.logins || []).slice(0, 5).map(l => `<li><span class="small"><b>${l.kind === 'failed' ? L('Failed attempt', 'ব্যর্থ চেষ্টা') : l.kind === 'register' ? L('Account created', 'অ্যাকাউন্ট তৈরি') : L('Signed in', 'লগ ইন')}</b> · ${esc(l.browser)} ${L('on', '—')} ${esc(l.os)}</span><span class="tiny muted">${new Date(l.at).toLocaleString()}</span></li>`).join('')}</ul><p class="tiny muted">${L('If you see a sign-in you don\'t recognise, change your password.', 'অপরিচিত কোনো লগইন দেখলে পাসওয়ার্ড বদলে ফেলুন।')}</p></div>
        <div class="card"><h3>${L('Your data', 'আপনার ডেটা')}</h3><p class="small muted">${store.s.attempts.length} ${L('test results', 'টেস্টের ফলাফল')} · ${store.s.writing.length} ${L('essays', 'রচনা')} · ${store.s.speaking.length} ${L('recordings', 'রেকর্ডিং')} · ${(store.s.certs || []).length} ${L('certificates', 'সার্টিফিকেট')}</p>
          <div class="row"><button class="btn btn-ghost" data-exp>${icon('download', 16)} ${L('Export backup', 'ব্যাকআপ ডাউনলোড')}</button><label class="btn btn-ghost">${icon('upload', 16)} ${L('Import backup', 'ব্যাকআপ ইমপোর্ট')}<input type="file" accept="application/json" data-imp hidden></label><button class="btn btn-danger" data-reset>${icon('trash', 16)} ${L('Reset my progress', 'আমার অগ্রগতি মুছুন')}</button></div></div>
        <a class="card hover row" href="#/certificate" style="color:inherit;flex-wrap:nowrap"><div class="mod-icon mod-W">${icon('trophy', 22)}</div><div><b>${L('Get your certificate', 'সার্টিফিকেট নিন')}</b><div class="small muted">${L('Create a printable certificate of your practice achievement.', 'আপনার অনুশীলন অর্জনের প্রিন্টযোগ্য সার্টিফিকেট তৈরি করুন।')}</div></div></a></div></div></div>`;
    const f = $('[data-prof]', v);
    f.onsubmit = e => {
      e.preventDefault(); const d = Object.fromEntries(new FormData(f)); const errs = {};
      if (!d.name.trim()) errs.name = L('Please enter your name.', 'নাম লিখুন।');
      if (!d.email && !d.phone) errs.email = L('Keep an email or a phone number.', 'ইমেইল বা ফোন নম্বর রাখুন।');
      if (d.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) errs.email = L('Please enter a valid email address.', 'সঠিক ইমেইল দিন।');
      ['email', 'phone', 'roll'].forEach(k => { const o = d[k] && OB.auth.find(d[k]); if (o && o.id !== me.id) errs[k] = L('Already used by another account.', 'অন্য একটি অ্যাকাউন্টে ব্যবহৃত।'); });
      fieldErr(f, errs); if (Object.keys(errs).length) return;
      Object.assign(me, { name: d.name.trim(), roll: d.roll.trim(), email: d.email.trim().toLowerCase(), phone: d.phone.trim(), target: +d.target, type: d.type, institution: d.institution.trim(), country: d.country.trim(), examDate: d.examDate, dailyGoal: Math.min(20, Math.max(1, +d.goal || 3)) });
      store.save(true); toast(L('Profile saved.', 'প্রোফাইল সেভ হয়েছে।'), 'ok'); OB.shell(); OB.render();
    };
    $('[data-pw]', v).onsubmit = async e => { e.preventDefault(); const d = Object.fromEntries(new FormData(e.target)); try { await OB.auth.changePassword(me, d.old, d.np); e.target.reset(); $('[data-pwerr]', v).textContent = ''; toast(L('Password changed.', 'পাসওয়ার্ড বদলানো হয়েছে।'), 'ok'); } catch (ex) { $('[data-pwerr]', v).textContent = ex.message; } };
    $('[data-logout]', v).onclick = () => { OB.auth.logout(); OB.shell(); toast(L('You have logged out.', 'আপনি লগ আউট করেছেন।')); OB.go('#/'); };
    const seg = (sel, key, cur) => $$(sel + ' button', v).forEach(b => { b.classList.toggle('on', b.dataset.v === (cur || '')); b.onclick = () => { store.s.settings[key] = b.dataset.v || null; store.save(true); OB.applyTheme(); OB.shell(); OB.render(); }; });
    seg('[data-th]', 'theme', st.theme); seg('[data-lg]', 'lang', st.lang);
    $('[data-exp]', v).onclick = () => OB.saveFile(`openband-backup-${today()}.json`, store.exportAll(), 'application/json');
    $('[data-imp]', v).onchange = e => { const file = e.target.files[0]; if (!file) return; file.text().then(txt => { try { store.importAll(txt); toast(L('Backup restored.', 'ব্যাকআপ ফিরিয়ে আনা হয়েছে।'), 'ok'); OB.render(); } catch (err) { toast(L('That file is not a valid OpenBand backup.', 'এটি সঠিক OpenBand ব্যাকআপ ফাইল নয়।'), 'bad'); } }); };
    $('[data-reset]', v).onclick = async () => { if (await confirmBox(L('Reset your progress?', 'অগ্রগতি মুছবেন?'), L('This deletes your results, drafts, essays and saved words. Your account stays. This cannot be undone.', 'আপনার ফলাফল, খসড়া, রচনা ও সেভ করা শব্দ মুছে যাবে। অ্যাকাউন্ট থাকবে। এটি ফেরানো যাবে না।'), L('Reset', 'মুছুন'), true)) { store.reset(); OB.render(); toast(L('Progress reset.', 'অগ্রগতি মুছে ফেলা হয়েছে।')); } };
  }

  /* ---------- CERTIFICATE ---------- */
  const certId = s => { let h = 2166136261; for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; } return 'OB-' + today().replace(/-/g, '') + '-' + h.toString(36).toUpperCase().slice(0, 6).padStart(6, '0'); };
  function wrapText(x, text, cx, y, maxW, lh) { const words = text.split(' '); let line = '', lines = []; words.forEach(w => { const t = line ? line + ' ' + w : w; if (x.measureText(t).width > maxW && line) { lines.push(line); line = w; } else line = t; }); lines.push(line); lines.forEach((l, i) => x.fillText(l, cx, y + i * lh)); return lines.length; }
  function rr(x, X, Y, W, H, r) { x.beginPath(); x.moveTo(X + r, Y); x.arcTo(X + W, Y, X + W, Y + H, r); x.arcTo(X + W, Y + H, X, Y + H, r); x.arcTo(X, Y + H, X, Y, r); x.arcTo(X, Y, X + W, Y, r); x.closePath(); }
  const loadImg = src => new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });
  OB.drawCertificate = async function (c, d) {
    const W = 2000, H = 1414; c.width = W; c.height = H; const x = c.getContext('2d'); const SERIF = 'Georgia, "Times New Roman", serif', SANS = '"Segoe UI", "Helvetica Neue", Arial, sans-serif';
    x.fillStyle = '#FCFBF7'; x.fillRect(0, 0, W, H);
    let g = x.createRadialGradient(W * .88, H * .08, 40, W * .88, H * .08, 900); g.addColorStop(0, 'rgba(155,123,255,.16)'); g.addColorStop(1, 'rgba(155,123,255,0)'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    g = x.createRadialGradient(W * .08, H * .95, 40, W * .08, H * .95, 800); g.addColorStop(0, 'rgba(114,214,178,.18)'); g.addColorStop(1, 'rgba(114,214,178,0)'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.save(); x.globalAlpha = .045; x.fillStyle = '#3157D5'; for (let i = 0; i < 3; i++) { rr(x, 1480 + i * 120, 760 - i * 150, 70, 320 + i * 150, 35); x.fill(); } x.restore();
    const bg = x.createLinearGradient(0, 0, W, H); bg.addColorStop(0, '#14213D'); bg.addColorStop(.5, '#3157D5'); bg.addColorStop(1, '#14213D');
    x.lineWidth = 26; x.strokeStyle = bg; x.strokeRect(36, 36, W - 72, H - 72);
    x.lineWidth = 2.5; x.strokeStyle = '#C9A44C'; x.strokeRect(74, 74, W - 148, H - 148);
    [[74, 74], [W - 74, 74], [74, H - 74], [W - 74, H - 74]].forEach(([a, b]) => { x.save(); x.translate(a, b); x.rotate(Math.PI / 4); x.fillStyle = '#C9A44C'; x.fillRect(-11, -11, 22, 22); x.restore(); });
    // header
    x.save(); x.translate(140, 120); const lg = x.createLinearGradient(0, 0, 92, 92); lg.addColorStop(0, '#3157D5'); lg.addColorStop(1, '#9B7BFF'); x.fillStyle = lg; rr(x, 0, 0, 92, 92, 26); x.fill();
    x.fillStyle = 'rgba(255,255,255,.7)'; rr(x, 21, 50, 12, 21, 6); x.fill(); x.fillStyle = 'rgba(255,255,255,.9)'; rr(x, 40, 37, 12, 34, 6); x.fill(); x.fillStyle = '#72D6B2'; rr(x, 59, 21, 12, 50, 6); x.fill(); x.restore();
    x.fillStyle = '#14213D'; x.font = `800 46px ${SANS}`; x.textAlign = 'left'; x.fillText('OpenBand', 252, 168); x.fillStyle = '#5B6683'; x.font = `500 22px ${SANS}`; x.fillText('Free IELTS Preparation', 254, 200);
    x.textAlign = 'right'; x.fillStyle = '#5B6683'; x.font = `600 20px ${SANS}`; x.fillText('CERTIFICATE NO.', W - 140, 150); x.fillStyle = '#14213D'; x.font = `700 26px ${SANS}`; x.fillText(d.id, W - 140, 186);
    // title
    x.textAlign = 'center'; x.fillStyle = '#14213D'; x.font = `700 112px ${SERIF}`; try { x.letterSpacing = '14px'; } catch (e) { } x.fillText('CERTIFICATE', W / 2, 360); try { x.letterSpacing = '6px'; } catch (e) { }
    x.fillStyle = '#B08A2E'; x.font = `700 30px ${SANS}`; x.fillText(d.type === 'mock' ? 'OF IELTS MOCK TEST ACHIEVEMENT' : 'OF IELTS PRACTICE ACHIEVEMENT', W / 2, 418); try { x.letterSpacing = '0px'; } catch (e) { }
    x.fillStyle = '#5B6683'; x.font = `italic 34px ${SERIF}`; x.fillText('This is to certify that', W / 2, 500);
    let fs = 98; x.font = `700 ${fs}px ${SERIF}`; while (x.measureText(d.name).width > 1400 && fs > 50) { fs -= 4; x.font = `700 ${fs}px ${SERIF}`; }
    const ng = x.createLinearGradient(W / 2 - 500, 0, W / 2 + 500, 0); ng.addColorStop(0, '#14213D'); ng.addColorStop(.5, '#3157D5'); ng.addColorStop(1, '#14213D'); x.fillStyle = ng; x.fillText(d.name, W / 2, 605);
    const ul = x.createLinearGradient(W / 2 - 520, 0, W / 2 + 520, 0); ul.addColorStop(0, 'rgba(201,164,76,0)'); ul.addColorStop(.5, '#C9A44C'); ul.addColorStop(1, 'rgba(201,164,76,0)'); x.fillStyle = ul; x.fillRect(W / 2 - 520, 638, 1040, 3);
    x.fillStyle = '#3B4560'; x.font = `400 30px ${SANS}`;
    const body = d.type === 'mock' ? `has successfully completed a full-length IELTS ${d.track === 'general' ? 'General Training' : 'Academic'} mock test on OpenBand on ${d.dateText}, achieving the following estimated band scores:` : `has shown dedication to IELTS preparation on OpenBand, completing the practice activities below and reaching the estimated bands shown, as of ${d.dateText}:`;
    wrapText(x, body, W / 2, 705, 1420, 44);
    // score boxes
    const boxes = d.type === 'mock' ? [['LISTENING', d.bands.L], ['READING', d.bands.R], ['WRITING', d.bands.W], ['SPEAKING', d.bands.S], ['OVERALL', d.bands.O, true]] : [['TESTS DONE', d.stats.tests, false, true], ['ESSAYS', d.stats.essays, false, true], ['RECORDINGS', d.stats.recs, false, true], ['ACTIVE DAYS', d.stats.days, false, true], ['BEST BAND', d.stats.best, true]];
    const bw = 236, gap = 28, total = boxes.length * bw + (boxes.length - 1) * gap; let bx = (W - total) / 2; const by = 810;
    boxes.forEach(([lab, val, hi, raw]) => {
      x.save(); x.shadowColor = 'rgba(20,33,61,.12)'; x.shadowBlur = 24; x.shadowOffsetY = 8;
      if (hi) { const hg = x.createLinearGradient(bx, by, bx + bw, by + 170); hg.addColorStop(0, '#3157D5'); hg.addColorStop(1, '#7B5CF6'); x.fillStyle = hg; } else x.fillStyle = '#FFFFFF';
      rr(x, bx, by, bw, 170, 22); x.fill(); x.restore();
      if (!hi) { x.lineWidth = 2; x.strokeStyle = '#E2E6F2'; rr(x, bx, by, bw, 170, 22); x.stroke(); }
      x.fillStyle = hi ? 'rgba(255,255,255,.85)' : '#5B6683'; x.font = `700 20px ${SANS}`; try { x.letterSpacing = '3px'; } catch (e) { } x.fillText(lab, bx + bw / 2, by + 48); try { x.letterSpacing = '0px'; } catch (e) { }
      x.fillStyle = hi ? '#FFFFFF' : '#14213D'; x.font = `800 72px ${SANS}`; x.fillText(val == null ? '—' : raw ? String(val) : bandLabel(val), bx + bw / 2, by + 135);
      bx += bw + gap;
    });
    // footer: issue info
    x.textAlign = 'left'; x.fillStyle = '#5B6683'; x.font = `600 20px ${SANS}`; x.fillText('DATE OF ISSUE', 180, 1118); x.fillStyle = '#14213D'; x.font = `700 30px ${SANS}`; x.fillText(d.dateText, 180, 1158);
    x.fillStyle = '#5B6683'; x.font = `600 20px ${SANS}`; x.fillText(d.type === 'mock' ? 'TEST TYPE' : 'PREPARING FOR', 180, 1212); x.fillStyle = '#14213D'; x.font = `700 28px ${SANS}`; x.fillText(d.track === 'general' ? 'IELTS General Training' : 'IELTS Academic', 180, 1250);
    // seal
    const sx = W / 2, sy = 1170; x.save(); const sg = x.createRadialGradient(sx - 30, sy - 30, 10, sx, sy, 105); sg.addColorStop(0, '#E9CF86'); sg.addColorStop(1, '#B08A2E'); x.fillStyle = sg; x.beginPath(); for (let i = 0; i < 48; i++) { const a = i / 48 * Math.PI * 2, r = i % 2 ? 100 : 108; x.lineTo(sx + r * Math.cos(a), sy + r * Math.sin(a)); } x.closePath(); x.fill();
    x.strokeStyle = 'rgba(255,255,255,.75)'; x.lineWidth = 3; x.beginPath(); x.arc(sx, sy, 84, 0, Math.PI * 2); x.stroke(); x.lineWidth = 1.5; x.beginPath(); x.arc(sx, sy, 76, 0, Math.PI * 2); x.stroke();
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = `800 22px ${SANS}`; x.fillText('OPENBAND', sx, sy - 16); x.font = `900 40px ${SANS}`; x.fillText('★', sx, sy + 24); x.font = `700 14px ${SANS}`; x.fillText('FREE PRACTICE', sx, sy + 50); x.restore();
    // developer signature with photo
    const px = 1690, py = 1080; const img = await loadImg(window.DEV && window.DEV.photo);
    if (img) { x.save(); x.beginPath(); x.arc(px, py, 66, 0, Math.PI * 2); x.closePath(); x.clip(); x.drawImage(img, px - 66, py - 66, 132, 132); x.restore(); x.lineWidth = 5; x.strokeStyle = '#C9A44C'; x.beginPath(); x.arc(px, py, 68, 0, Math.PI * 2); x.stroke(); }
    x.textAlign = 'center'; x.fillStyle = '#14213D'; x.font = `italic 46px "Segoe Script", "Brush Script MT", "Lucida Handwriting", cursive`; x.fillText('MD Rejon', px, 1205);
    x.fillStyle = '#C9D0E3'; x.fillRect(px - 160, 1222, 320, 2);
    x.fillStyle = '#14213D'; x.font = `800 24px ${SANS}`; x.fillText('MD REJON', px, 1258); x.fillStyle = '#5B6683'; x.font = `500 19px ${SANS}`; x.fillText('Founder & Developer, OpenBand', px, 1286);
    x.fillStyle = '#8A93AD'; x.font = `500 17px ${SANS}`; x.fillText('This is a practice certificate issued by OpenBand. Scores are estimates from practice tests and are not official IELTS results.', W / 2, 1300); x.fillText('OpenBand is an independent free platform, not affiliated with IELTS, the British Council, IDP or Cambridge.', W / 2, 1324);
    return c;
  };
  OB.route('/certificate', () => {
    const v = OB.page('Certificate'); const me = OB.me(); const s = store.s;
    const mocks = s.attempts.filter(a => a.module === 'M' && a.mock);
    const done = s.attempts.length; const min = s.settings.certMinTests || 3;
    const st = OB.stats(); const best = Math.max(...s.attempts.filter(a => typeof a.band === 'number').map(a => a.band), -1);
    v.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('trophy', 16)} ${L('Certificate', 'সার্টিফিকেট')}</span><h1 style="font-size:2.2rem">${L('Create your certificate', 'আপনার সার্টিফিকেট তৈরি করুন')}</h1><p>${L('Celebrate your progress with a printable OpenBand practice certificate. Scores come from your real results on this platform and are labelled as estimates.', 'আপনার অগ্রগতির জন্য একটি প্রিন্টযোগ্য OpenBand অনুশীলন সার্টিফিকেট নিন। স্কোর আসে এই প্ল্যাটফর্মে আপনার আসল ফলাফল থেকে, আর সেগুলো আনুমানিক হিসেবে লেখা থাকে।')}</p></div></div>
    <div class="wrap" style="padding-bottom:40px"><div class="grid" style="grid-template-columns:minmax(0,340px) minmax(0,1fr);align-items:start" data-cols>
      <div class="card"><form data-cf>
        <div class="field"><label class="lbl">${L('Name on certificate', 'সার্টিফিকেটে নাম')}</label><input class="input" name="name" value="${esc(me ? me.name : (s.profile && s.profile.name) || '')}" maxlength="48" ${me ? 'readonly' : ''}>${me ? `<div class="tiny muted" style="margin-top:4px">${L('From your profile.', 'আপনার প্রোফাইল থেকে।')} <a href="#/account">${L('Edit', 'বদলান')}</a></div>` : ''}</div>
        <div class="field"><label class="lbl">${L('Certificate type', 'সার্টিফিকেটের ধরন')}</label>
          ${mocks.map((a, i) => `<label class="opt" style="margin-bottom:6px"><input type="radio" name="src" value="m${i}" ${i === 0 ? 'checked' : ''}><span class="small"><b>${L('Mock test', 'মক টেস্ট')}</b> · ${esc(a.mock.track === 'general' ? 'GT' : 'Academic')} · ${fmtDate(a.date)}<br>${L('Overall', 'সামগ্রিক')} ${bandLabel(a.speaking != null ? overallBand([a.mock.res.L.band, a.mock.res.R.band, a.mock.wb, a.speaking]) : a.band)}</span></label>`).join('')}
          <label class="opt"><input type="radio" name="src" value="practice" ${mocks.length ? '' : 'checked'} ${done >= min ? '' : 'disabled'}><span class="small"><b>${L('Practice achievement', 'অনুশীলন অর্জন')}</b><br>${done} ${L('activities completed', 'টি অনুশীলন সম্পন্ন')}${done < min ? ` · ${L(`needs ${min}`, `${min}টি দরকার`)}` : ''}</span></label></div>
        <div class="err" data-err></div>
        <button class="btn btn-primary btn-block" type="submit">${icon('trophy', 16)} ${L('Generate certificate', 'সার্টিফিকেট তৈরি করুন')}</button>
        ${!mocks.length && done < min ? `<div class="estimate-note" style="margin-top:14px">${icon('info')} <div>${L(`Complete a full mock test, or at least ${min} practice tests, to unlock your certificate.`, `সার্টিফিকেট পেতে একটি পূর্ণ মক টেস্ট দিন, অথবা অন্তত ${min}টি প্র্যাকটিস টেস্ট সম্পন্ন করুন।`)} <a href="#/mock">${L('Start a mock test', 'মক টেস্ট শুরু করুন')}</a></div></div>` : ''}</form></div>
      <div class="card"><div class="cert-preview cert-print" data-prev><div class="empty"><div class="ico">${icon('trophy', 28)}</div>${L('Your certificate preview will appear here.', 'এখানে আপনার সার্টিফিকেটের প্রিভিউ দেখাবে।')}</div></div>
        <div class="row" style="margin-top:14px;display:none" data-actions><button class="btn btn-primary" data-png>${icon('download', 16)} ${L('Download PNG', 'PNG ডাউনলোড')}</button>${window.self === window.top ? `<button class="btn btn-ghost" data-print>${L('Print / Save as PDF', 'প্রিন্ট / PDF সেভ')}</button>` : ''}</div></div></div></div>`;
    if (innerWidth < 900) $('[data-cols]', v).style.gridTemplateColumns = '1fr';
    let canvas = null, fname = 'certificate.png';
    $('[data-cf]', v).onsubmit = async e => {
      e.preventDefault(); const fd = Object.fromEntries(new FormData(e.target)); const err = $('[data-err]', v);
      const name = (fd.name || '').trim(); if (name.length < 2) return err.textContent = L('Please enter your name.', 'নাম লিখুন।'); if (!fd.src) return err.textContent = L('Choose a certificate type.', 'সার্টিফিকেটের ধরন বেছে নিন।'); err.textContent = '';
      const dateText = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }); let d;
      if (fd.src === 'practice') d = { type: 'practice', name, dateText, track: (me && me.type) || 'academic', stats: { tests: s.attempts.length, essays: s.writing.length, recs: s.speaking.length, days: Object.keys(s.activity).length, best: best >= 0 ? best : null }, key: 'practice:' + s.attempts.length };
      else { const a = mocks[+fd.src.slice(1)]; const r = a.mock.res; d = { type: 'mock', name, dateText, track: a.mock.track, bands: { L: r.L.band, R: r.R.band, W: a.mock.wb, S: a.speaking ?? null, O: a.speaking != null ? overallBand([r.L.band, r.R.band, a.mock.wb, a.speaking]) : a.band }, key: a.id }; }
      d.id = certId(d.key + name + (me ? me.id : ''));
      canvas = document.createElement('canvas'); await OB.drawCertificate(canvas, d);
      const url = canvas.toDataURL('image/png');
      $('[data-prev]', v).innerHTML = `<img src="${url}" alt="Certificate for ${esc(name)}" style="width:100%;border-radius:10px;box-shadow:var(--shadow)">`;
      $('[data-actions]', v).style.display = 'flex'; fname = `OpenBand-Certificate-${name.replace(/[^\w]+/g, '-')}.png`;
      s.certs = s.certs || []; if (!s.certs.some(c => c.id === d.id)) { s.certs.unshift({ id: d.id, type: d.type, name, date: new Date().toISOString(), overall: d.type === 'mock' ? d.bands.O : d.stats.best }); store.save(true); }
      toast(L('Certificate ready!', 'সার্টিফিকেট তৈরি!'), 'ok');
    };
    on(v, 'click', '[data-png]', () => canvas && canvas.toBlob(b => OB.saveFile(fname, b, 'image/png'), 'image/png'));
    on(v, 'click', '[data-print]', () => window.print());
    if (mocks.length || done >= min) setTimeout(() => $('[data-cf] button[type=submit]', v).click(), 50);
  });

  /* ---------- HOW TO USE (Bangla + English) ---------- */
  const GUIDE = {
    bn: { title: 'OpenBand কীভাবে ব্যবহার করবেন', intro: 'এই গাইডে ধাপে ধাপে দেখানো হয়েছে কীভাবে অনুশীলন করবেন, কীভাবে পূর্ণ মক পরীক্ষা দেবেন আর কীভাবে আপনার অগ্রগতি দেখবেন। সবকিছু সম্পূর্ণ ফ্রি।',
      sections: [
        ['user', 'শুরু করুন — অ্যাকাউন্ট', ['অ্যাকাউন্ট ছাড়াও অনুশীলন করা যায়। তবে নিজের নামে অগ্রগতি রাখতে আর সার্টিফিকেট পেতে উপরের ডান কোণের ⋮ মেনু থেকে “অ্যাকাউন্ট” → “অ্যাকাউন্ট খুলুন” চাপুন।', 'নাম, রোল/স্টুডেন্ট আইডি, ইমেইল বা ফোন, পাসওয়ার্ড, লক্ষ্য ব্যান্ড আর টেস্টের ধরন (Academic বা General Training) দিন।', 'পরে ইমেইল, ফোন বা রোল আইডি — যেকোনো একটি আর পাসওয়ার্ড দিয়ে লগ ইন করবেন।', 'ভাষা বদলাতে উপরের “বাংলা / EN” বোতাম ব্যবহার করুন। প্রশ্ন ও উত্তর সবসময় ইংরেজিতে থাকবে, যেমন আসল পরীক্ষায় থাকে।']],
        ['dash', 'ড্যাশবোর্ড বুঝুন', ['ড্যাশবোর্ডে প্রতিটি মডিউলের আনুমানিক ব্যান্ড, সামগ্রিক ব্যান্ড, পড়ার ধারাবাহিকতা (streak) আর দৈনিক লক্ষ্য দেখা যায়।', '“পরবর্তী প্রস্তাবনা” বলে দেয় কোন মডিউলে এখন অনুশীলন দরকার।', 'অসমাপ্ত টেস্ট বা লেখা “যেখানে থেমেছিলেন” অংশে থাকে — সেখান থেকে চালিয়ে যান।', 'প্রোফাইলে পরীক্ষার তারিখ দিলে কাউন্টডাউন দেখাবে।']],
        ['L', 'লিসেনিং টেস্ট', ['মেনু থেকে “লিসেনিং” → পূর্ণ টেস্ট অথবা একটি সেকশন বেছে নিন।', '“প্র্যাকটিস মোড” মানে সময়ের সীমা নেই, অডিও থামানো ও আবার শোনা যায়, ট্রান্সক্রিপ্টও দেখা যায়। “সময় ধরে টেস্ট” আসল পরীক্ষার মতো — রেকর্ডিং একবারই বাজে।', 'অডিও চালুর আগে প্রশ্নগুলো পড়ে নিন, তারপর ▶ বোতাম চাপুন। হেডফোন ব্যবহার করুন।', 'উত্তর লিখুন বা বেছে নিন। নিচের নম্বর বোতাম দিয়ে যেকোনো প্রশ্নে যাওয়া যায়; নীল রং মানে উত্তর দেওয়া হয়েছে।', 'শেষে “রিভিউ ও জমা দিন” → উত্তর না দেওয়া প্রশ্নগুলো দেখে নিন → “উত্তর জমা দিন”। সাথে সাথে স্কোর, আনুমানিক ব্যান্ড আর প্রতিটি উত্তরের ব্যাখ্যা পাবেন।']],
        ['R', 'রিডিং টেস্ট', ['বাঁ দিকে প্যাসেজ, ডান দিকে প্রশ্ন। মাঝের দাগ টেনে দুই পাশ ছোট-বড় করা যায়।', 'প্যাসেজের কোনো অংশ মাউস বা আঙুল দিয়ে সিলেক্ট করলে “হাইলাইট” বা “নোট যোগ” অপশন আসবে।', 'মোবাইলে উপরে “প্যাসেজ” আর “প্রশ্ন” ট্যাব দিয়ে আসা-যাওয়া করুন।', 'কঠিন প্রশ্নে “চিহ্নিত করুন” চাপুন, পরে ফিরে আসুন। Academic টেস্ট ৬০ মিনিট, ৪০টি প্রশ্ন।', 'মনে রাখবেন: FALSE মানে প্যাসেজে উল্টো কথা আছে, NOT GIVEN মানে প্যাসেজে এ বিষয়ে কিছুই নেই।']],
        ['W', 'রাইটিং', ['“রাইটিং” থেকে Academic/General আর টাস্ক ১ বা ২ বেছে নিন। টাস্ক ১-এ চার্ট/ম্যাপ/ডায়াগ্রাম থাকে, টাস্ক ২ রচনা।', 'ডান পাশের এডিটরে লিখুন। শব্দ গণনা সাথে সাথে দেখায় (টাস্ক ১: ১৫০+, টাস্ক ২: ২৫০+)। লেখা নিজে থেকে সেভ হয়।', '“টাইমার” চালু করলে আসল পরীক্ষার মতো সময় (২০/৪০ মিনিট) ধরে লিখতে পারবেন।', '“ফিডব্যাকের জন্য জমা দিন” চাপলে চারটি মানদণ্ডে আনুমানিক ব্যান্ড, ভুল, শব্দের পরামর্শ আর উন্নতির পরিকল্পনা পাবেন। এটি স্বয়ংক্রিয় বিশ্লেষণ, AI বা অফিসিয়াল নয়।', 'নিচের “নিজে মূল্যায়ন” অংশে নিজের লেখা নিজে যাচাই করুন এবং নমুনা উত্তরের সাথে মিলিয়ে দেখুন।']],
        ['S', 'স্পিকিং', ['প্রথমবার রেকর্ড করার সময় ব্রাউজার মাইক্রোফোনের অনুমতি চাইবে — “Allow” দিন।', 'পার্ট ১: পরীক্ষকের প্রশ্ন শুনুন (🔊), “উত্তর রেকর্ড করুন” চাপুন, ২০–৩০ সেকেন্ড বলুন, তারপর থামান।', 'পার্ট ২: কিউ কার্ড পড়ুন, ১ মিনিট প্রস্তুতি নিন (নোট লিখুন), তারপর ২ মিনিট বলুন — রেকর্ডিং নিজে থেকে চলবে।', 'পার্ট ৩: আলোচনার প্রশ্নে মতামত, কারণ আর উদাহরণ দিয়ে উত্তর দিন।', 'রেকর্ডিং শুনে “নিজে মূল্যায়নের গাইড” দিয়ে চারটি মানদণ্ডে নিজের ব্যান্ড বের করুন। ব্রাউজার রেকর্ডিং দিয়ে অফিসিয়াল স্কোর নির্ধারণ করা যায় না।']],
        ['M', 'পূর্ণ মক টেস্ট কীভাবে দেবেন', ['মেনু থেকে “মক টেস্ট” → Academic বা General Training বেছে নিন।', '“এক্সাম মোড (সময় ধরে)” বেছে নিলে আসল পরীক্ষার মতো হবে: লিসেনিং (৩০ মিনিট) → রিডিং (৬০ মিনিট) → রাইটিং টাস্ক ১ (২০ মিনিট) → টাস্ক ২ (৪০ মিনিট)।', 'প্রতিটি অংশ শেষে পরের অংশের আগে বিরতি নিতে পারবেন। “বিরতি” চাপলে উত্তর সেভ থাকে, পরে চালিয়ে যাবেন।', 'সময় শেষ হলে উত্তর নিজে থেকে জমা হয়ে যায়।', 'শেষে ফলাফল পাতায় প্রতিটি মডিউলের ব্যান্ড, সামগ্রিক ব্যান্ড আর সব উত্তরের রিভিউ দেখবেন। স্পিকিং আলাদা সেশনে দিন, তারপর ফলাফল পাতায় স্পিকিং ব্যান্ড যোগ করুন।']],
        ['V', 'শব্দভান্ডার ও ব্যাকরণ', ['“শিখুন” → প্রতিদিন ৫টি নতুন শব্দ (বাংলা অর্থসহ), ফ্ল্যাশকার্ড আর কুইজ।', '★ চাপলে শব্দ “প্রিয়” তালিকায় সেভ হয়; 🔊 চাপলে উচ্চারণ শুনবেন।', 'ব্যাকরণের প্রতিটি পাঠে ছোট ব্যাখ্যা আর অনুশীলন আছে — উত্তর দিলেই সঠিক/ভুল দেখায়।', 'প্যারাফ্রেজিং, বাক্য উন্নয়ন, সংযোজক শব্দ ও কলোকেশন অনুশীলন রাইটিং আর স্পিকিংয়ে বেশি স্কোর পেতে সাহায্য করে।']],
        ['calc', 'ব্যান্ড ক্যালকুলেটর', ['লিসেনিং আর রিডিংয়ের সঠিক উত্তরের সংখ্যা (০–৪০) দিন, রাইটিং আর স্পিকিং ব্যান্ড বেছে নিন।', 'সামগ্রিক ব্যান্ড হলো চারটির গড়, কাছের অর্ধ-ব্যান্ডে রাউন্ড করা (যেমন ৬.২৫ → ৬.৫)। পুরো হিসাব পাতায় দেখানো হয়।']],
        ['trophy', 'সার্টিফিকেট', ['⋮ মেনু → “সার্টিফিকেট”।', 'একটি পূর্ণ মক টেস্ট অথবা কয়েকটি প্র্যাকটিস টেস্ট দেওয়ার পর সার্টিফিকেট তৈরি করা যায়।', 'নাম আর ধরন বেছে “সার্টিফিকেট তৈরি করুন” চাপুন, তারপর PNG ডাউনলোড বা প্রিন্ট করুন। এটি অনুশীলনের সার্টিফিকেট, অফিসিয়াল IELTS ফলাফল নয়।']],
        ['shield', 'জরুরি কথা', ['সব স্কোর আনুমানিক — আসল পরীক্ষায় সামান্য কম-বেশি হতে পারে।', 'আপনার ডেটা এই ব্রাউজারে সেভ থাকে। ব্রাউজারের ডেটা মুছলে অগ্রগতি মুছে যেতে পারে — তাই মাঝে মাঝে “অ্যাকাউন্ট” → “ব্যাকআপ ডাউনলোড” করে রাখুন।', 'সেরা অভিজ্ঞতার জন্য Chrome বা Edge ব্যবহার করুন।']]
      ],
      plan: ['৪ সপ্তাহের পড়ার পরিকল্পনা', [['সপ্তাহ ১', 'প্রতিটি মডিউলের একটি করে সেকশন দিন, দুর্বল জায়গা খুঁজুন। প্রতিদিন ৫টি শব্দ।'], ['সপ্তাহ ২', 'দুর্বল মডিউলে বেশি জোর দিন। ২টি রাইটিং টাস্ক লিখে ফিডব্যাক দেখুন।'], ['সপ্তাহ ৩', 'সময় ধরে পূর্ণ রিডিং ও লিসেনিং টেস্ট। স্পিকিং পার্ট ২-এ প্রতিদিন ১টি কিউ কার্ড।'], ['সপ্তাহ ৪', 'একটি পূর্ণ মক টেস্ট এক্সাম মোডে দিন, ভুলগুলো রিভিউ করুন, সার্টিফিকেট নিন।']]] },
    en: { title: 'How to use OpenBand', intro: 'A step-by-step guide to practising, taking a full mock exam and tracking your progress. Everything is free.',
      sections: [
        ['user', 'Getting started — your account', ['You can practise without an account. To save progress under your name and earn certificates, open the ⋮ menu (top right) → Account → Create account.', 'Enter your name, roll/student ID, email or phone, a password, your target band and test type (Academic or General Training).', 'Next time, log in with your email, phone or roll ID and your password.', 'Switch the interface between English and বাংলা with the language button. Questions and answers always stay in English, as in the real test.']],
        ['dash', 'Understand your dashboard', ['See your estimated band for each module, your overall band, your study streak and your daily goal.', '"Recommended next" tells you which module needs the most work now.', 'Unfinished tests and drafts appear under "Continue where you left off".', 'Add your exam date in your profile to see a countdown.']],
        ['L', 'Listening tests', ['Go to Listening and choose a full test or a single section.', 'Practice mode has no time limit: pause, replay and read the transcript. Timed mode is like the real exam: each recording plays once.', 'Read the questions first, then press ▶. Use headphones.', 'Type or choose your answers. Jump to any question with the numbered buttons at the bottom; filled buttons are answered.', 'Press "Review & submit", check unanswered questions, then "Submit answers" to see your score, estimated band and an explanation for every answer.']],
        ['R', 'Reading tests', ['The passage is on the left and questions on the right. Drag the divider to resize.', 'Select text in the passage to highlight it or add a note.', 'On mobile, switch with the Passage / Questions tabs.', 'Flag hard questions and come back later. The Academic test is 60 minutes, 40 questions.', 'FALSE means the passage says the opposite; NOT GIVEN means it says nothing about it.']],
        ['W', 'Writing', ['Choose Academic or General, then Task 1 (charts, maps, letters) or Task 2 (essays).', 'Write in the editor. The word count updates live (150+ / 250+) and your draft saves automatically.', 'Turn on the timer to practise under exam timing (20 / 40 minutes).', '"Submit for feedback" gives an estimated band for the 4 criteria, errors, vocabulary suggestions and an improvement plan. This is automated analysis, not AI and not official.', 'Use the self-assessment and compare with the sample answer.']],
        ['S', 'Speaking', ['Allow microphone access when your browser asks.', 'Part 1: hear the question (🔊), press "Record answer", speak for 20–30 seconds, then stop.', 'Part 2: read the cue card, prepare for 1 minute, then speak for up to 2 minutes — recording starts automatically.', 'Part 3: answer discussion questions with an opinion, a reason and an example.', 'Listen back and use the self-assessment guide. A browser recording cannot give an official band.']],
        ['M', 'Taking a full mock test', ['Open Mock Test and choose Academic or General Training.', 'Exam mode follows the real order: Listening (30 min) → Reading (60 min) → Writing Task 1 (20 min) → Task 2 (40 min).', 'You can rest between sections. "Pause" saves your answers so you can continue later.', 'When time runs out, answers are submitted automatically.', 'The result page shows module bands, your overall band and a full review. Take Speaking as a separate session and add your band on the result page.']],
        ['V', 'Vocabulary & grammar', ['Learn 5 new words a day (with Bangla meanings), then use flashcards and quizzes.', 'Tap ★ to save a word and 🔊 to hear it.', 'Each grammar lesson has a short explanation and exercises with instant checking.', 'Paraphrasing, sentence improvement, connectors and collocations raise your Writing and Speaking scores.']],
        ['calc', 'Band calculator', ['Enter your Listening and Reading raw scores (0–40) and choose Writing and Speaking bands.', 'The overall band is the average, rounded to the nearest half band (e.g. 6.25 → 6.5). The page shows the full calculation.']],
        ['trophy', 'Certificate', ['Open ⋮ menu → Certificate.', 'Unlock it by completing a full mock test or a few practice tests.', 'Choose a type, generate it, then download the PNG or print it. It is a practice certificate, not an official IELTS result.']],
        ['shield', 'Good to know', ['All scores are estimates; real exam results can differ.', 'Your data is saved in this browser. Clearing browser data can remove it, so export a backup from Account now and then.', 'Chrome or Edge give the best experience.']]
      ],
      plan: ['4-week study plan', [['Week 1', 'Try one section of every module to find your weak areas. Learn 5 words a day.'], ['Week 2', 'Focus on your weakest module. Write 2 tasks and study the feedback.'], ['Week 3', 'Timed full Reading and Listening tests. One Part 2 cue card every day.'], ['Week 4', 'Take a full mock test in exam mode, review mistakes and get your certificate.']]] }
  };
  OB.route('/guide', () => {
    const v = OB.page('How to use'); let lang = bn() ? 'bn' : 'en';
    const draw = () => {
      const G = GUIDE[lang];
      v.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('bulb', 16)} ${lang === 'bn' ? 'গাইড' : 'Guide'}</span><h1 style="font-size:2.2rem" data-notr>${esc(G.title)}</h1><p data-notr>${esc(G.intro)}</p><div class="seg" data-gl><button data-v="bn">বাংলা</button><button data-v="en">English</button></div></div></div>
      <div class="wrap" style="padding-bottom:40px" data-notr ${lang === 'bn' ? 'lang="bn"' : ''}><div class="guide-toc">${G.sections.map((s, i) => `<a href="#g${i}" data-jump="g${i}">${icon(s[0], 15)} ${esc(s[1])}</a>`).join('')}</div>
        <div class="grid g2" style="margin-top:18px">${G.sections.map((s, i) => `<div class="card guide-card" id="g${i}"><div class="row" style="flex-wrap:nowrap;gap:12px;margin-bottom:10px"><div class="mod-icon ${{ L: 'mod-L', R: 'mod-R', W: 'mod-W', S: 'mod-S', M: 'mod-M', V: 'mod-V' }[s[0]] || 'mod-M'}" style="width:42px;height:42px">${icon(s[0], 20)}</div><h3 style="margin:0">${esc(s[1])}</h3></div><ol class="guide-steps">${s[2].map(x => `<li>${esc(x)}</li>`).join('')}</ol></div>`).join('')}</div>
        <div class="card" style="margin-top:18px"><h3>${icon('target', 18)} ${esc(G.plan[0])}</h3><div class="grid g4">${G.plan[1].map(([w, d]) => `<div class="plan-week"><b>${esc(w)}</b><p class="small muted" style="margin:6px 0 0">${esc(d)}</p></div>`).join('')}</div></div>
        <div class="row" style="justify-content:center;margin-top:22px"><a class="btn btn-primary btn-lg" href="#/library">${lang === 'bn' ? 'অনুশীলন শুরু করুন' : 'Start practising'}</a><a class="btn btn-ghost btn-lg" href="#/mock">${lang === 'bn' ? 'পূর্ণ মক টেস্ট দিন' : 'Take a full mock test'}</a></div></div>`;
      $$('[data-gl] button', v).forEach(b => { b.classList.toggle('on', b.dataset.v === lang); b.onclick = () => { lang = b.dataset.v; draw(); }; });
      on(v, 'click', '[data-jump]', (e, a) => { e.preventDefault(); const t = document.getElementById(a.dataset.jump); t && t.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
    };
    draw();
  });
})();
