/* OpenBand — app shell and main pages */
(function () {
  const { $, $$, esc, on, icon, store, toast, modal, confirmBox, t, bandLabel, overallBand, fmtTime, fmtDate, today, LOGO } = OB;
  const NAV = [['/', 'Home', 'home'], ['/dashboard', 'Dashboard', 'dash'], ['/listening', 'Listening', 'L'], ['/reading', 'Reading', 'R'], ['/writing', 'Writing', 'W'], ['/speaking', 'Speaking', 'S'], ['/mock', 'Mock Test', 'M'], ['/learn', 'Learn', 'V'], ['/library', 'Library', 'lib'], ['/calculator', 'Calculator', 'calc']];
  const MOD = { L: ['Listening', 'mod-L', '#/listening'], R: ['Reading', 'mod-R', '#/reading'], W: ['Writing', 'mod-W', '#/writing'], S: ['Speaking', 'mod-S', '#/speaking'] };

  /* ---------- theme ---------- */
  OB.applyTheme = () => { const th = store.s.settings.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); document.documentElement.dataset.theme = th; };

  /* ---------- shell ---------- */
  OB.shell = () => {
    const me = OB.me(); const bnOn = store.s.settings.lang === 'bn'; const dark = document.documentElement.dataset.theme === 'dark';
    const ini = me ? me.name.split(/\s+/).map(x => x[0]).slice(0, 2).join('').toUpperCase() : '';
    document.body.innerHTML = `<a href="#view" class="sr">Skip to content</a>
      ${store.s.settings.announcement ? `<div class="free-strip" style="font-size:.88rem;padding:9px" data-notr>${esc(store.s.settings.announcement)}</div>` : ''}
      <header class="topbar"><div class="wrap"><a class="brand" href="#/">${LOGO(36)}<span>OpenBand<small>${t('Free IELTS Preparation')}</small></span></a>
      <nav class="nav" data-nav aria-label="Main">${NAV.slice(1).map(([h, l]) => `<a href="#${h}" data-h="${h}">${t(l)}</a>`).join('')}</nav>
      <div class="top-actions"><button class="lang-btn" data-lang title="Interface language">${bnOn ? 'EN' : 'বাংলা'}</button>
        ${me ? `<a class="avatar-btn" href="#/account" title="${esc(me.name)}" data-notr>${esc(ini)}</a>` : `<a class="btn btn-sm btn-primary hide-sm" href="#/account?tab=register">${t('Sign up free')}</a>`}
        <div class="menu-wrap"><button class="icon-btn" data-more aria-label="${t('Menu')}" aria-haspopup="true" aria-expanded="false"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg></button>
          <div class="menu" data-menu role="menu">
            ${me ? `<div class="menu-head"><div class="avatar-btn" data-notr>${esc(ini)}</div><div><b data-notr>${esc(me.name)}</b><div class="tiny muted" data-notr>${esc(me.email || me.phone || '')}</div></div></div>` : ''}
            <a href="#/guide" role="menuitem">${icon('bulb', 17)} ${bnOn ? 'কীভাবে ব্যবহার করবেন' : 'How to use'}</a>
            <a href="#/account" role="menuitem">${icon('user', 17)} ${me ? t('My profile') : t('Log in') + ' / ' + t('Sign up free')}</a>
            <a href="#/certificate" role="menuitem">${icon('trophy', 17)} ${t('Certificate')}</a>
            <a href="#/dashboard" role="menuitem">${icon('dash', 17)} ${t('My progress')}</a>
            <div class="menu-sep"></div>
            <button data-themebtn role="menuitem">${icon(dark ? 'sun' : 'moon', 17)} ${dark ? t('Light mode') : t('Dark mode')}</button>
            <button data-lang2 role="menuitem">${icon('globe', 17)} ${t('Language')}: ${bnOn ? 'বাংলা' : 'English'}</button>
            <a href="#/account" role="menuitem">${icon('shield', 17)} ${t('Settings')}</a>
            <a href="#/about" role="menuitem">${icon('heart', 17)} ${t('About the developer')}</a>
            ${me ? `<div class="menu-sep"></div><button data-logout role="menuitem">${icon('logout', 17)} ${t('Log out')}</button>` : ''}
          </div></div>
        <button class="icon-btn burger" data-burger aria-label="Open menu">${icon('menu', 18)}</button></div></div></header>
      <div class="drawer" data-drawer><div class="scrim" data-dclose></div><div class="panel"><div class="row between" style="margin-bottom:12px"><span class="brand">${LOGO(30)} OpenBand</span><button class="icon-btn" data-dclose aria-label="Close menu">${icon('x', 18)}</button></div>
        ${[...NAV, ['/guide', bnOn ? 'কীভাবে ব্যবহার করবেন' : 'How to use', 'bulb'], ['/certificate', 'Certificate', 'trophy'], ['/about', 'About', 'info'], ['/account', me ? 'My profile' : 'Account', 'user']].map(([h, l, ic]) => `<a href="#${h}" data-h="${h}">${icon(ic, 18)} ${t(l)}</a>`).join('')}</div></div>
      <main id="view" tabindex="-1"></main>
      <footer class="site"><div class="wrap"><div class="foot-grid">
        <div><a class="brand" href="#/" style="color:#fff!important">${LOGO(34)}<span>OpenBand<small style="color:#8E9BC4">${t('Free IELTS Preparation')}</small></span></a><p class="small" style="margin-top:14px;max-width:320px" data-notr>${esc(bnOn && store.s.settings.siteTagline === 'Prepare Better. Practise More. Pay Nothing.' ? 'ভালো প্রস্তুতি। বেশি অনুশীলন। কোনো খরচ নেই।' : store.s.settings.siteTagline)}</p><span class="badge-free" style="color:#72D6B2">${icon('check', 14)} ${t('100% free · No payment ever')}</span>
          ${store.s.settings.contactEmail || store.s.settings.contactPhone ? `<p class="small" style="margin-top:12px" data-notr>${esc(store.s.settings.contactEmail || '')}${store.s.settings.contactEmail && store.s.settings.contactPhone ? ' · ' : ''}${esc(store.s.settings.contactPhone || '')}</p>` : ''}</div>
        <div><h4>${t('Practise')}</h4><ul><li><a href="#/listening">${t('Listening')}</a></li><li><a href="#/reading">${t('Reading')}</a></li><li><a href="#/writing">${t('Writing')}</a></li><li><a href="#/speaking">${t('Speaking')}</a></li><li><a href="#/mock">${t('Full mock test')}</a></li></ul></div>
        <div><h4>${t('Learn')}</h4><ul><li><a href="#/learn">${t('Vocabulary')}</a></li><li><a href="#/learn?tab=grammar">${t('Grammar')}</a></li><li><a href="#/calculator">${t('Band calculator')}</a></li><li><a href="#/library">${t('Test library')}</a></li><li><a href="#/guide">${bnOn ? 'কীভাবে ব্যবহার করবেন' : 'How to use'}</a></li></ul></div>
        <div><h4>${t('Platform')}</h4><ul><li><a href="#/about">${t('About & mission')}</a></li><li><a href="#/dashboard">${t('My progress')}</a></li><li><a href="#/certificate">${t('Certificate')}</a></li><li><a href="#/account">${t('Account & data')}</a></li></ul></div></div>
        <div class="foot-bottom"><span>${t('OpenBand is an independent practice platform and is not affiliated with IELTS, the British Council, IDP or Cambridge. All scores are estimates.')}</span><span class="dev-credit" data-devcredit><img src="${window.DEV.photo}" alt="" width="26" height="26">${t('Developed by MD REJON')}</span></div></div></footer>`;
    const tog = () => { store.s.settings.theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; store.save(); OB.applyTheme(); OB.shell(); OB.render(); };
    const lang = () => { store.s.settings.lang = store.s.settings.lang === 'bn' ? 'en' : 'bn'; store.save(true); OB.shell(); OB.applyLang(); OB.render(); };
    $('[data-themebtn]').onclick = tog; $('[data-lang]').onclick = lang; $('[data-lang2]').onclick = lang;
    const lo = $('[data-logout]'); if (lo) lo.onclick = () => { OB.auth.logout(); OB.shell(); toast(store.s.settings.lang === 'bn' ? 'আপনি লগ আউট করেছেন।' : 'You have logged out.'); OB.go('#/'); };
    const mb = $('[data-more]'), menu = $('[data-menu]');
    mb.onclick = e => { e.stopPropagation(); const o = menu.classList.toggle('open'); mb.setAttribute('aria-expanded', o); };
    document.addEventListener('click', e => { if (!e.target.closest('.menu-wrap')) { menu.classList.remove('open'); mb.setAttribute('aria-expanded', 'false'); } });
    on(menu, 'click', 'a', () => menu.classList.remove('open'));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') menu.classList.remove('open'); });
    const dr = $('[data-drawer]'); $('[data-burger]').onclick = () => dr.classList.add('open'); on(dr, 'click', '[data-dclose], a', () => dr.classList.remove('open'));
    const tl = $('[data-tips]'); if (tl) tl.onclick = e => { e.preventDefault(); OB.go('#/'); setTimeout(() => { const t = document.getElementById('tips'); t && t.scrollIntoView({ behavior: 'smooth' }); }, 80); };
    if (!OB.persistent && !OB._warned) { OB._warned = true; setTimeout(() => toast(store.s.settings.lang === 'bn' ? 'প্রিভিউ মোড: এখানে অগ্রগতি সেভ হবে না। সেভ করতে ফাইলটি Chrome-এ খুলুন।' : 'Preview mode: progress is not saved here. Open the file in Chrome to save your progress.'), 600); }
    let taps = 0, tt; $('[data-devcredit]').onclick = () => { taps++; clearTimeout(tt); tt = setTimeout(() => taps = 0, 2500); if (taps >= 5) { taps = 0; OB.go('#/rejon-control'); } };
  };
  OB.page = (title) => {
    const old = $('#view'); const v = old.cloneNode(false); old.replaceWith(v); v.className = 'fade-in'; try { window.scrollTo({ top: 0, left: 0, behavior: 'instant' }); } catch (e) { window.scrollTo(0, 0); }
    const path = '/' + ((OB.loc().replace(/^#\/?/, '').split(/[?/]/)[0]) || '');
    $$('[data-h]').forEach(a => a.classList.toggle('on', a.dataset.h === path || (path === '/' && a.dataset.h === '/')));
    document.title = (title ? title + ' · ' : '') + 'OpenBand — Free IELTS Preparation';
    store.s.lastVisit = OB.loc(); return v;
  };
  OB.notFound = () => { const v = OB.page('Not found'); v.innerHTML = `<div class="wrap section"><div class="empty"><div class="ico">${icon('info', 28)}</div><h2>Page not found</h2><p>The page you were looking for doesn't exist.</p><a class="btn btn-primary" href="#/">Go home</a></div></div>`; };
  OB.renderError = e => { const v = OB.page('Error'); v.innerHTML = `<div class="wrap section"><div class="empty"><div class="ico">${icon('info', 28)}</div><h2>Something went wrong</h2><p class="muted">${esc(e.message)}</p><a class="btn btn-primary" href="#/">Go home</a></div></div>`; };

  /* ---------- stats helpers ---------- */
  OB.stats = () => {
    const A = store.s.attempts; const by = m => A.filter(a => a.module === m && typeof a.band === 'number');
    const est = m => { const l = by(m).slice(0, 3); return l.length ? overallBand(l.map(a => a.band)) : null; };
    const bands = { L: est('L'), R: est('R'), W: est('W'), S: est('S') };
    const lib = OB.libraryItems();
    const uniq = m => new Set(A.filter(a => a.module === m).map(a => a.testId + ':' + (a.parts || []).join('-'))).size;
    const totalOf = m => lib.filter(i => i.module === m).length || 1;
    const prog = { L: Math.min(100, Math.round(uniq('L') / totalOf('L') * 100)), R: Math.min(100, Math.round(uniq('R') / totalOf('R') * 100)), W: Math.min(100, Math.round(new Set(store.s.writing.map(w => w.taskId)).size / OB.allWriting().length * 100)), S: Math.min(100, Math.round(store.s.speaking.length / 20 * 100)) };
    const act = store.s.activity; let streak = 0; const d = new Date(); if (!act[today()]) d.setDate(d.getDate() - 1);
    while (act[d.toISOString().slice(0, 10)]) { streak++; d.setDate(d.getDate() - 1); }
    const overall = overallBand(Object.values(bands).filter(b => b != null));
    return { bands, prog, streak, overall, overallProg: Math.round((prog.L + prog.R + prog.W + prog.S) / 4), todayCount: act[today()] || 0 };
  };
  const last7 = () => { const out = []; for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); const k = d.toISOString().slice(0, 10); out.push({ k, on: !!store.s.activity[k], l: d.toLocaleDateString(OB.locale(), { weekday: 'narrow' }) }); } return out; };
  function recommend(s) {
    const order = ['L', 'R', 'W', 'S'].sort((a, b) => (s.bands[a] ?? -1) - (s.bands[b] ?? -1) || s.prog[a] - s.prog[b]);
    const m = order[0]; const lib = OB.libraryItems().filter(i => i.module === m); const done = new Set(store.s.attempts.map(a => a.testId));
    const it = lib.find(i => !done.has(i.testId)) || lib[0];
    const bn = store.s.settings.lang === 'bn'; const why = s.bands[m] == null ? (bn ? `আপনি এখনো ${t(MOD[m][0])} চেষ্টা করেননি।` : `You haven't tried ${MOD[m][0]} yet.`) : (bn ? `${t(MOD[m][0])}-এ এখন আপনার আনুমানিক ব্যান্ড সবচেয়ে কম (${bandLabel(s.bands[m])})।` : `${MOD[m][0]} is currently your lowest estimated band (${bandLabel(s.bands[m])}).`);
    return { m, it, why };
  }
  function trendSVG() {
    const A = store.s.attempts.filter(a => typeof a.band === 'number' && 'LRWS'.includes(a.module)).slice(0, 12).reverse();
    if (A.length < 2) return `<div class="empty small" style="padding:26px">Complete two or more tests to see your band trend.</div>`;
    const W = 560, H = 190, L = 34, B = 26; const x = i => L + (W - L - 16) * i / (A.length - 1); const y = b => H - B - (H - B - 14) * (b - 3) / 6;
    const col = { L: '#3157D5', R: '#1FA37A', W: '#FF8A76', S: '#7B5CF6' };
    return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Band trend">${[3, 4.5, 6, 7.5, 9].map(b => `<line x1="${L}" x2="${W - 10}" y1="${y(b)}" y2="${y(b)}" style="stroke:var(--line)"/><text x="${L - 6}" y="${y(b) + 4}" font-size="10" text-anchor="end" style="fill:var(--muted)">${b}</text>`).join('')}
      <polyline fill="none" stroke="url(#tg)" stroke-width="3" points="${A.map((a, i) => `${x(i)},${y(a.band)}`).join(' ')}"/><defs><linearGradient id="tg"><stop offset="0" stop-color="#3157D5"/><stop offset="1" stop-color="#9B7BFF"/></linearGradient></defs>
      ${A.map((a, i) => `<circle cx="${x(i)}" cy="${y(a.band)}" r="5" fill="${col[a.module]}"><title>${esc(a.title)}: ${a.band}</title></circle>`).join('')}</svg>
      <div class="row small muted" style="gap:14px;margin-top:4px">${Object.entries(col).map(([k, c]) => `<span class="row" style="gap:5px"><i style="width:10px;height:10px;border-radius:50%;background:${c};display:inline-block"></i>${MOD[k][0]}</span>`).join('')}</div>`;
  }
  function continueList() {
    const items = [];
    Object.entries(store.s.progress).filter(([k]) => !k.endsWith(':mock')).forEach(([k, p]) => { const [id, parts] = k.split(':'); const tt = OB.getTest(id); if (!tt) return; const single = parts.split('-').length === 1 && tt.parts.length > 1; items.push({ t: p.title + (single ? ' · ' + tt.parts[+parts].title : ''), sub: `${Object.keys(p.answers).length} answers saved · ${p.mode}`, href: `#/test/${id}${single ? '?part=' + parts : ''}`, u: p.updated || 0 }); });
    Object.entries(store.s.drafts).forEach(([id, d]) => { const w = OB.getWriting(id); if (w && d.text && d.text.trim()) items.push({ t: 'Writing: ' + w.title, sub: `${(d.text.match(/\S+/g) || []).length} words drafted`, href: '#/writing/' + id, u: d.updated || 0 }); });
    if (store.s.mock && store.s.mock.step !== 'done') items.push({ t: 'Full mock test (' + store.s.mock.track + ')', sub: 'In progress', href: '#/mock', u: store.s.mock.updated || 0 });
    return items.sort((a, b) => b.u - a.u);
  }

  /* ---------- HOME ---------- */
  OB.route('/', () => {
    const v = OB.page(); const s = OB.stats(); const lib = OB.libraryItems();
    const latest = [...lib].sort((a, b) => (b.added || '').localeCompare(a.added || '')).slice(0, 6);
    const tip = window.TIPS;
    v.innerHTML = `
    <section class="hero"><div class="wrap hero-grid"><div>
      <div class="free-ribbon"><span class="dot"></span> ${t('All Features. All Practice Tests. 100% Free.')}</div>
      <h1>IELTS preparation that's <span class="hl">100% free</span>, for everyone.</h1>
      <p class="lead"><span>${t('Prepare Better. Practise More. Pay Nothing.')}</span> <span>Full mock tests, all four modules, instant marking, writing feedback and speaking practice — with no subscriptions, no locked tests and no hidden payments.</span></p>
      <div class="row" style="margin-top:24px"><a class="btn btn-lg btn-white" href="#/library">${icon('play', 16)} ${t('Start Practising')}</a><a class="btn btn-lg btn-outline-white" href="#/mock">${icon('M', 18)} ${t('Take a Full Mock Test')}</a></div>
      <div class="hero-stats"><div><b>${lib.length}+</b><span>practice activities</span></div><div><b>4</b><span>IELTS modules</span></div><div><b>৳0 / $0</b><span>forever</span></div></div></div>
      <div class="hero-visual" aria-hidden="true">
        <div class="float-card" style="left:6%;top:4%;width:260px"><div class="row between"><b>Estimated band</b><span class="chip mint">+1.0</span></div><div style="font-size:2.6rem;font-weight:800;line-height:1.1;margin-top:6px;background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent">7.0</div><div class="bar" style="margin-top:8px"><i style="width:78%"></i></div></div>
        <div class="float-card" style="right:2%;top:30%;width:250px"><div class="row" style="gap:10px"><div class="mod-icon mod-L" style="width:38px;height:38px">${icon('L', 18)}</div><div><b class="small">Listening · Section 2</b><div class="tiny muted">Map labelling · 10 Q</div></div></div><div class="eq" style="margin-top:10px"><i></i><i></i><i></i><i></i></div></div>
        <div class="float-card" style="left:14%;bottom:2%;width:280px"><div class="row" style="gap:10px"><div class="mod-icon mod-W" style="width:38px;height:38px">${icon('W', 18)}</div><div><b class="small">Writing Task 2</b><div class="tiny muted">276 words · autosaved</div></div></div><div class="row small" style="margin-top:8px;gap:6px"><span class="chip blue">TR 7</span><span class="chip mint">CC 7</span><span class="chip coral">LR 6.5</span><span class="chip">GRA 6.5</span></div></div>
      </div></div></section>
    <div class="free-strip">${icon('gift', 18)} <span>${t('All Features. All Practice Tests. 100% Free.')}</span> <span>No premium plan. No paywall. No card required.</span></div>

    <section class="section"><div class="wrap"><div class="center" style="margin-bottom:30px"><span class="eyebrow">Four modules</span><h2>Everything you need for test day</h2><p class="muted" style="max-width:620px;margin:0 auto">Practise each IELTS skill with realistic question types, instant marking and clear explanations.</p></div>
      <div class="grid g4">${[['L', 'Listening', '4 sections · audio player · form, map, MCQ, matching and note completion.', '#/listening'], ['R', 'Reading', 'Split-screen passages · highlight & notes · TFNG, headings, summary and more.', '#/reading'], ['W', 'Writing', 'Timed editor with word counter, charts, sample answers and feedback.', '#/writing'], ['S', 'Speaking', 'Examiner questions, cue cards with timers, recording and playback.', '#/speaking']].map(([k, n, d, h]) => `<a class="card hover" href="${h}" style="color:inherit"><div class="mod-icon mod-${k}">${icon(k, 24)}</div><h3 style="margin:14px 0 6px">${t(n)}</h3><p class="small muted" style="margin:0 0 12px">${d}</p><span class="small" style="font-weight:700;color:var(--blue)">Start practising ${icon('arrow', 14)}</span></a>`).join('')}</div></div></section>

    <section class="section" style="padding-top:0"><div class="wrap"><div class="card" style="padding:30px;background:linear-gradient(135deg,var(--card),var(--lav))"><div class="grid g2" style="align-items:center"><div><span class="eyebrow">Choose your test</span><h2>Academic or General Training?</h2><p class="muted">Listening and Speaking are the same for both. Reading and Writing differ — pick your version and we'll show the right practice.</p></div>
      <div class="grid g2"><a class="card hover" href="#/library?track=academic" style="color:inherit"><span class="chip blue">For university</span><h3 style="margin:10px 0 4px">IELTS Academic</h3><p class="small muted" style="margin:0">Academic passages, graphs, charts, maps and process diagrams.</p></a><a class="card hover" href="#/library?track=general" style="color:inherit"><span class="chip mint">For work & migration</span><h3 style="margin:10px 0 4px">General Training</h3><p class="small muted" style="margin:0">Everyday texts, workplace documents and letter writing.</p></a></div></div></div></div></section>

    <section class="section" style="padding-top:0"><div class="wrap grid g2" style="align-items:stretch">
      <div class="card"><div class="card-title"><h3>${icon('target', 18)} Daily practice</h3><span class="chip gold">${new Date().toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}</span></div>
        <ul class="list-clean">${[[`Learn today's 5 words`, '#/learn?tab=daily', 'V'], ['Listening Section 1 (form completion)', '#/test/L1?part=0', 'L'], ['Reading Passage 1 (True/False/Not Given)', '#/test/RA1?part=0', 'R'], ['Speaking Part 1: 4 questions', '#/speaking?tab=p1', 'S']].map(([l, h, m]) => `<li><span class="row" style="gap:10px"><span class="mod-icon mod-${m}" style="width:32px;height:32px;border-radius:10px">${icon(m, 15)}</span>${l}</span><a class="btn btn-sm btn-ghost" href="${h}">Go</a></li>`).join('')}</ul></div>
      <div class="card"><div class="card-title"><h3>${icon('V', 18)} Word of the day</h3><a class="small" href="#/learn">Vocabulary centre →</a></div>${(() => { const w = OB.dailyWords(1)[0]; return `<div style="font-size:2rem;font-weight:800;letter-spacing:-.02em">${esc(w.w)} <span class="chip">${esc(w.pos)}</span></div><p style="margin:6px 0">${esc(w.m)}</p><p class="small" style="color:var(--blue)" lang="bn">বাংলা: ${esc(w.bn)}</p><p class="small muted" style="font-style:italic">“${esc(w.ex)}”</p><div class="row"><a class="btn btn-sm btn-primary" href="#/learn?tab=flash">Flashcards</a><a class="btn btn-sm btn-ghost" href="#/learn?tab=quiz">Take the vocabulary quiz</a></div>`; })()}</div></div></section>

    <section class="section" style="padding-top:0"><div class="wrap"><div class="row between" style="margin-bottom:18px"><div><span class="eyebrow">Latest practice tests</span><h2 style="margin:4px 0 0">Recently added</h2></div><a class="btn btn-ghost" href="#/library">View full library ${icon('arrow', 14)}</a></div>
      <div class="grid g3">${latest.map(OB.testCardHTML).join('')}</div></div></section>

    <section class="section" style="padding-top:0" id="tips"><div class="wrap"><div class="center" style="margin-bottom:24px"><span class="eyebrow">Tips & study resources</span><h2>Practical advice for every module</h2></div>
      <div class="grid g4">${tip.map(x => { const b = store.s.settings.lang === 'bn' && OB.TIPS_BN[x.t]; return `<div class="card tip-card"><span class="chip ${x.m === 'L' ? 'blue' : x.m === 'R' ? 'mint' : x.m === 'W' ? 'coral' : ''}">${t(MOD[x.m][0])}</span><h3 style="margin:10px 0 6px;font-size:1rem" data-notr>${esc(b ? b[0] : x.t)}</h3><p class="small muted" style="margin:0" data-notr>${esc(b ? b[1] : x.d)}</p></div>`; }).join('')}</div>
      <div class="row" style="justify-content:center;margin-top:18px"><a class="btn btn-ghost" href="#/learn?tab=grammar">Grammar lessons</a><a class="btn btn-ghost" href="#/learn?tab=connect">Essay connectors</a><a class="btn btn-ghost" href="#/calculator">Band score calculator</a></div></div></section>

    <section class="section" style="padding-top:0"><div class="wrap"><div class="card" style="padding:28px"><div class="grid g2" style="align-items:center"><div><span class="eyebrow">Track your progress</span><h2>See your band improve</h2><p class="muted">Every test you take is saved in your browser — no account needed. Your dashboard shows estimated bands for each module, your study streak and what to practise next.</p><a class="btn btn-primary" href="#/dashboard">Open my dashboard ${icon('arrow', 14)}</a></div>
      <div class="grid g2">${['L', 'R', 'W', 'S'].map(m => `<div class="card" style="padding:16px"><div class="row between"><b class="small">${MOD[m][0]}</b><span class="band-pill">${bandLabel(s.bands[m])}</span></div><div class="bar ${m === 'R' ? 'mint' : m === 'W' ? 'coral' : m === 'S' ? 'violet' : ''}" style="margin-top:10px"><i style="width:${s.prog[m]}%"></i></div><div class="tiny muted" style="margin-top:5px">${s.prog[m]}% explored</div></div>`).join('')}</div></div></div></div></section>

    <section class="section" style="padding-top:0"><div class="wrap"><div class="dev-strip"><img src="${window.DEV.photo}" alt="MD REJON"><div><span class="eyebrow" style="color:#9FE8FF">${t('Meet the developer')}</span><h3 style="color:#fff;margin:4px 0 6px;font-size:1.4rem">MD REJON <span style="font-weight:500;color:#AAB6DD;font-size:1rem">· ${t('Founder & Developer')}</span></h3><p style="color:#C9D3F2;margin:0" data-notr>${store.s.settings.lang === 'bn' ? '“IELTS প্রস্তুতিকে সবার জন্য সহজলভ্য করতেই এই প্ল্যাটফর্ম। আমাদের লক্ষ্য — টাকার বাধা ছাড়াই শিক্ষার্থীরা যেন অনুশীলন করে, উন্নতি করে আর প্রস্তুত হয়।”' : '“This platform was created to make IELTS preparation more accessible — so students can practise, improve and prepare without financial barriers.”'}</p></div><a class="btn btn-outline-white" href="#/about">${t('About')}</a></div></div></section>

    <section class="section" style="padding-top:0"><div class="wrap" style="max-width:860px"><div class="center" style="margin-bottom:22px"><span class="eyebrow">FAQ</span><h2>Frequently asked questions</h2></div>
      <div class="faq">${(store.s.settings.lang === 'bn' ? OB.FAQ_BN : window.FAQ).map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}</div></div></section>`;
  });

  /* ---------- DASHBOARD ---------- */
  OB.route('/dashboard', () => {
    const v = OB.page('Dashboard'); const s = OB.stats(); const p = OB.me(); const bnOn = store.s.settings.lang === 'bn'; const rec = recommend(s); const cont = continueList(); const goal = (p && p.dailyGoal) || store.s.settings.dailyGoal || 3;
    const recent = store.s.attempts.slice(0, 6);
    v.innerHTML = `<div class="wrap fade-in" style="padding:28px 22px 40px">
      <div class="dash-hero"><div class="row between" style="position:relative;z-index:1"><div><div class="small" style="opacity:.8">${new Date().toLocaleDateString(OB.locale(), { weekday: 'long', day: 'numeric', month: 'long' })}</div><h1 style="font-size:2rem;color:#fff;margin:4px 0">${t('Welcome back')}${p ? ', ' + esc(p.name.split(' ')[0]) : ''} 👋</h1>
        <p style="opacity:.85;margin:0" data-notr>${s.overallProg ? (bnOn ? `আপনি প্ল্যাটফর্মের ${s.overallProg}% অনুশীলন করেছেন। চালিয়ে যান!` : `You've explored ${s.overallProg}% of the platform. Keep going!`) : (bnOn ? 'যেকোনো মডিউল দিয়ে শুরু করুন — সব ফ্রি, আর অগ্রগতি নিজে থেকেই সেভ হয়।' : 'Start with any module — everything is free and your progress saves automatically.')}</p></div>
        <div class="row">${p ? '' : `<a class="btn btn-white" href="#/account?tab=register">${t('Create free account')}</a>`}<a class="btn btn-outline-white" href="#/mock">${icon('M', 16)} Full mock test</a></div></div></div>
      <div class="grid g4" style="margin-top:18px">
        <div class="card stat"><div class="ring" style="--p:${s.overall ? s.overall / 9 * 100 : 0};width:76px;height:76px"><div style="width:58px;height:58px"><b style="font-size:1.2rem">${bandLabel(s.overall)}</b></div></div><div><span class="muted small">${t('Estimated band')}</span><b>${s.overall != null ? 'Overall' : 'No data yet'}</b><span class="tiny faint">from recent tests</span></div></div>
        <div class="card stat"><div class="mod-icon" style="background:var(--grad-warm)">${icon('flame', 22)}</div><div><span class="muted small">${t('Study streak')}</span><b>${s.streak} ${t('days')}</b><div class="streak" style="margin-top:6px">${last7().map(d => `<i class="${d.on ? 'on' : ''}" title="${d.k}">${d.l}</i>`).join('')}</div></div></div>
        <div class="card stat"><div class="mod-icon mod-R">${icon('target', 22)}</div><div style="flex:1"><span class="muted small">${t('Daily goal')}</span><b>${Math.min(s.todayCount, goal)} / ${goal} activities</b><div class="bar mint" style="margin-top:8px"><i style="width:${Math.min(100, s.todayCount / goal * 100)}%"></i></div></div></div>
        <div class="card stat"><div class="mod-icon mod-M">${icon('trophy', 22)}</div><div><span class="muted small">Tests completed</span><b>${store.s.attempts.length}</b><span class="tiny faint">${store.s.writing.length} essays · ${store.s.speaking.length} recordings</span></div></div></div>
      <div class="grid" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);margin-top:18px" data-cols>
        <div class="stack">
          <div class="card"><div class="card-title"><h3>Module progress</h3><span class="small muted">Overall ${s.overallProg}%</span></div>
            <div class="grid g2">${['L', 'R', 'W', 'S'].map(m => `<a href="${MOD[m][2]}" class="row" style="color:inherit;flex-wrap:nowrap;gap:14px;padding:10px;border-radius:14px;border:1px solid var(--line)"><div class="mod-icon ${MOD[m][1]}">${icon(m, 22)}</div><div style="flex:1"><div class="row between"><b>${t(MOD[m][0])}</b><span class="band-pill" style="height:26px;min-width:40px;font-size:.85rem">${bandLabel(s.bands[m])}</span></div><div class="bar ${m === 'R' ? 'mint' : m === 'W' ? 'coral' : m === 'S' ? 'violet' : ''}" style="margin-top:8px"><i style="width:${s.prog[m]}%"></i></div><div class="tiny muted" style="margin-top:4px">${s.prog[m]}% explored</div></div></a>`).join('')}</div></div>
          <div class="card"><div class="card-title"><h3>Band trend</h3><span class="tiny muted">Estimates · last 12 results</span></div><div class="chart">${trendSVG()}</div></div>
          <div class="card"><div class="card-title"><h3>${t('Recent tests')}</h3><a class="small" href="#/history">View all</a></div>${recent.length ? `<ul class="list-clean">${recent.map(a => `<li><span class="row" style="gap:10px;flex-wrap:nowrap"><span class="mod-icon ${(MOD[a.module] || ['', 'mod-M'])[1]}" style="width:34px;height:34px;border-radius:10px">${icon(MOD[a.module] ? a.module : 'M', 16)}</span><span><b class="small">${esc(a.title)}</b><br><span class="tiny muted">${fmtDate(a.date)}${a.total && a.module !== 'W' ? ` · ${a.raw}/${a.total}` : ''}</span></span></span><span class="row" style="gap:8px"><span class="band-pill">${bandLabel(a.band)}</span><a class="btn btn-sm btn-ghost" href="${attemptHref(a)}">Review</a></span></li>`).join('')}</ul>` : `<div class="empty"><div class="ico">${icon('clock', 26)}</div>No tests yet. Your results will appear here.<br><a class="btn btn-primary" style="margin-top:12px" href="#/library">${t('Start Practising')}</a></div>`}</div>
        </div>
        <div class="stack">
          ${(store.s.notices || []).length ? `<div class="card notice-card"><div class="card-title"><h3>${icon('info', 18)} ${t('Notice board')}</h3></div>${store.s.notices.slice(0, 3).map(n => `<div class="notice" data-notr><b>${n.pinned ? '📌 ' : ''}${esc(n.title)}</b><p class="small" style="margin:4px 0 2px">${esc(n.body)}</p><span class="tiny muted">${fmtDate(n.date)}</span></div>`).join('')}</div>` : ''}
          ${p && p.examDate ? (() => { const days = Math.ceil((new Date(p.examDate) - new Date(today())) / 864e5); return `<div class="card countdown"><div><span class="small muted">${t('Exam countdown')}</span><div class="big-num">${days >= 0 ? days : 0}</div><span class="small">${days >= 0 ? t('days to go') : (bnOn ? 'পরীক্ষার তারিখ পেরিয়ে গেছে' : 'Exam date has passed')}</span></div><div class="tiny muted" style="text-align:right">${fmtDate(p.examDate)}<br>${bnOn ? 'লক্ষ্য' : 'Target'} <b>${bandLabel(p.target)}</b></div></div>`; })() : p ? `<a class="card hover row" href="#/account" style="color:inherit;flex-wrap:nowrap"><div class="mod-icon mod-V">${icon('clock', 20)}</div><div><b>${t('Set your exam date')}</b><div class="small muted">${bnOn ? 'প্রোফাইলে তারিখ দিলে কাউন্টডাউন দেখাবে।' : 'Add it in your profile to see a countdown.'}</div></div></a>` : `<div class="card" style="background:linear-gradient(135deg,var(--card),var(--lav))"><b>${t('Create a free account to save your progress under your name and get a certificate.')}</b><div class="row" style="margin-top:12px"><a class="btn btn-sm btn-primary" href="#/account?tab=register">${t('Sign up free')}</a><a class="btn btn-sm btn-ghost" href="#/account?tab=login">${t('Log in')}</a></div></div>`}
          <div class="card" style="border:2px solid var(--lav)"><span class="eyebrow">${icon('zap', 14)} ${t('Recommended next')}</span><h3 style="margin:8px 0 4px">${esc(rec.it ? rec.it.title : MOD[rec.m][0])}</h3><p class="small muted" data-notr>${esc(rec.why)}</p><a class="btn btn-primary btn-block" href="${rec.it ? rec.it.href : MOD[rec.m][2]}">${t('Start Practice')} ${icon('arrow', 14)}</a></div>
          <div class="card"><div class="card-title"><h3>${t('Continue where you left off')}</h3></div>${cont.length ? `<ul class="list-clean">${cont.slice(0, 5).map(c => `<li><span><b class="small">${esc(c.t)}</b><br><span class="tiny muted">${esc(c.sub)}</span></span><a class="btn btn-sm btn-primary" href="${c.href}">${t('Continue')}</a></li>`).join('')}</ul>` : '<p class="small muted">Nothing in progress. Unfinished tests and drafts are saved automatically and will appear here.</p>'}</div>
          <div class="card"><div class="card-title"><h3>Quick access</h3></div><div class="grid g2" style="gap:10px">${[['L', 'Listening', '#/listening'], ['R', 'Reading', '#/reading'], ['W', 'Writing', '#/writing'], ['S', 'Speaking', '#/speaking'], ['V', 'Vocabulary', '#/learn'], ['calc', 'Calculator', '#/calculator']].map(([ic, l, h]) => `<a class="btn btn-ghost" href="${h}" style="justify-content:flex-start">${icon(ic, 16)} ${t(l)}</a>`).join('')}</div></div>
          <a class="card hover row" href="#/certificate" style="color:inherit;flex-wrap:nowrap"><div class="mod-icon mod-W">${icon('trophy', 22)}</div><div><b>${t('Get your certificate')}</b><div class="small muted">${bnOn ? 'আপনার অগ্রগতির প্রিন্টযোগ্য সার্টিফিকেট।' : 'A printable certificate of your progress.'}</div></div></a>
          <div class="card"><h3>${t('Saved words')}</h3><p class="small muted" data-notr>${store.s.favWords.length ? store.s.favWords.slice(0, 12).map(esc).join(', ') : (bnOn ? 'শেখার কেন্দ্রে যেকোনো শব্দের ★ চাপলে এখানে সেভ হবে।' : 'Tap ★ on any word in the Learn centre to save it here.')}</p><a class="small" href="#/learn?tab=flash">Review with flashcards →</a></div>
        </div></div></div>`;
    if (innerWidth < 900) $('[data-cols]', v).style.gridTemplateColumns = '1fr';
  });
  const attemptHref = a => a.module === 'W' && a.subId ? '#/writing-review/' + a.subId : a.module === 'M' ? '#/mock-result/' + a.id : a.module === 'S' ? '#/speaking?tab=recs' : '#/result/' + a.id;
  OB.route('/history', () => {
    const v = OB.page('History'); const A = store.s.attempts;
    v.innerHTML = `<div class="page-head"><div class="wrap"><div class="crumbs"><a href="#/dashboard">Dashboard</a> / History</div><h1 style="font-size:2rem">Test history</h1></div></div><div class="wrap" style="padding-bottom:40px"><div class="card">${A.length ? `<div style="overflow:auto"><table class="tbl"><thead><tr><th>Date</th><th>Test</th><th>Mode</th><th>Score</th><th>Band (est.)</th><th></th></tr></thead><tbody>${A.map(a => `<tr><td>${fmtDate(a.date)}</td><td>${esc(a.title)}</td><td>${esc(a.mode || '')}</td><td>${a.total && a.module !== 'W' ? `${a.raw}/${a.total}` : a.module === 'W' ? `${a.raw} words` : '–'}</td><td><span class="band-pill">${bandLabel(a.band)}</span></td><td><a href="${attemptHref(a)}">Review</a></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">No history yet.</div>'}</div></div>`;
  });

  /* ---------- library ---------- */
  OB.libraryItems = () => {
    const items = [];
    OB.allTests().forEach(tt => {
      const L = tt.module === 'L'; const cat = L ? 'Listening Tests' : tt.track === 'general' ? 'General Reading' : 'Academic Reading';
      items.push({ id: tt.id, testId: tt.id, module: tt.module, cat, title: tt.title, level: tt.level, track: L ? 'both' : tt.track, minutes: tt.minutes, q: OB.testCount(tt), added: tt.added, plays: tt.plays || 0, href: '#/test/' + tt.id, full: true });
      if (tt.parts.length > 1) tt.parts.forEach((p, i) => items.push({ id: tt.id + '-' + i, testId: tt.id, module: tt.module, cat, title: `${tt.title.split(' — ')[0]} · ${p.title}${p.heading && !p.html ? ': ' + p.heading : ''}`, level: tt.level, track: L ? 'both' : tt.track, minutes: Math.max(5, Math.round(tt.minutes / tt.parts.length)), q: OB.partNums(p).length, added: tt.added, plays: Math.round((tt.plays || 0) / 2), href: `#/test/${tt.id}?part=${i}` }));
    });
    OB.allWriting().forEach(w => items.push({ id: w.id, testId: w.id, module: 'W', cat: 'Writing Task ' + w.task, title: w.title, sub: w.kind, level: w.level, track: w.track, minutes: w.task === 1 ? 20 : 40, q: 1, qLabel: (w.task === 1 ? '150' : '250') + '+ words', added: w.added || '2026-10-12', plays: w.plays || 300 + w.title.length * 7, href: '#/writing/' + w.id }));
    OB.allP1().forEach((p, i) => items.push({ id: 'p1-' + i, testId: 'p1', module: 'S', cat: 'Speaking Part 1', title: 'Part 1: ' + p.topic, level: 'Beginner', track: 'both', minutes: 5, q: p.qs.length, added: '2026-09-28', plays: 400 + i * 23, href: '#/speaking?tab=p1' }));
    OB.allCards().forEach((c, i) => { items.push({ id: 'p2-' + c.id, testId: 'p2', module: 'S', cat: 'Speaking Part 2', title: c.title, level: 'Intermediate', track: 'both', minutes: 4, q: 1, qLabel: 'Cue card', added: '2026-10-' + String(10 + i).padStart(2, '0'), plays: 250 + i * 31, href: '#/speaking?tab=p2&card=' + c.id }); if (c.p3) items.push({ id: 'p3-' + c.id, testId: 'p3', module: 'S', cat: 'Speaking Part 3', title: 'Discussion: ' + c.title.replace(/^Describe (a|an) /, '').replace(/\.$/, ''), level: 'Advanced', track: 'both', minutes: 5, q: c.p3.length, added: '2026-10-' + String(10 + i).padStart(2, '0'), plays: 120 + i * 17, href: '#/speaking?tab=p3&card=' + c.id }); });
    items.push({ id: 'mock-ac', testId: 'mock', module: 'M', cat: 'Full Mock Tests', title: 'Full IELTS Academic Mock Test', level: 'Advanced', track: 'academic', minutes: 165, q: 82, qLabel: '80 Q + 2 tasks', added: '2026-11-10', plays: 3100, href: '#/mock?track=academic' });
    items.push({ id: 'mock-gt', testId: 'mock', module: 'M', cat: 'Full Mock Tests', title: 'Full IELTS General Training Mock Test', level: 'Intermediate', track: 'general', minutes: 150, q: 72, qLabel: '70 Q + 2 tasks', added: '2026-11-10', plays: 1650, href: '#/mock?track=general' });
    return items;
  };
  OB.testCardHTML = i => { const m = i.module; const done = store.s.attempts.some(a => a.testId === i.testId && (!i.href.includes('part=') || (a.parts || []).join() === i.href.split('part=')[1])); return `<div class="card hover test-card"><div class="row between"><span class="chip ${m === 'L' ? 'blue' : m === 'R' ? 'mint' : m === 'W' ? 'coral' : m === 'M' ? 'gold' : ''}">${esc(i.cat)}</span><span class="chip">${esc(i.level)}</span></div><h3 style="margin:4px 0 0;font-size:1.05rem">${esc(i.title)}</h3>${i.sub ? `<div class="small muted">${esc(i.sub)}</div>` : ''}<div class="meta"><span>${icon('clock', 14)} ${i.minutes} min</span><span>${icon('layers', 14)} ${i.qLabel || i.q + ' questions'}</span><span>${i.track === 'both' ? 'Academic & GT' : i.track === 'general' ? 'General Training' : 'Academic'}</span>${done ? `<span style="color:var(--ok)">${icon('check', 14)} Done</span>` : ''}</div><div style="margin-top:auto"><a class="btn btn-sm btn-primary" href="${i.href}">${t('Start Practice')} ${icon('arrow', 14)}</a></div></div>`; };

  OB.route('/library', () => {
    const v = OB.page('Test library'); const q = OB.query(); const all = OB.libraryItems();
    const CATS = ['All', 'Listening Tests', 'Academic Reading', 'General Reading', 'Writing Task 1', 'Writing Task 2', 'Speaking Part 1', 'Speaking Part 2', 'Speaking Part 3', 'Full Mock Tests'];
    const F = ['Beginner', 'Intermediate', 'Advanced', 'Academic', 'General Training', 'Recently Added', 'Most Practised'];
    let cat = q.cat || 'All', flt = new Set(q.track === 'academic' ? ['Academic'] : q.track === 'general' ? ['General Training'] : []), s = '';
    v.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('lib', 16)} Practice test library</span><h1 style="font-size:2.2rem">${all.length} free practice activities</h1><p>Search and filter every test, task and cue card. Nothing is locked.</p>
      <div class="row"><input class="input" style="max-width:340px" placeholder="${t('Search tests')}…" data-s aria-label="Search tests"><select class="select" style="max-width:240px" data-cat aria-label="Category">${CATS.map(c => `<option ${c === cat ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
      <div class="filters" style="margin-top:12px" data-f>${F.map(f => `<button class="filter" data-v="${f}">${f}</button>`).join('')}</div></div></div>
      <div class="wrap" style="padding-bottom:40px"><div class="small muted" data-count style="margin-bottom:12px"></div><div class="grid g3" data-g></div></div>`;
    const draw = () => {
      $$('[data-f] .filter', v).forEach(b => b.classList.toggle('on', flt.has(b.dataset.v)));
      let l = all.filter(i => (cat === 'All' || i.cat === cat) && (!s || (i.title + ' ' + i.cat + ' ' + (i.sub || '')).toLowerCase().includes(s)));
      const lv = ['Beginner', 'Intermediate', 'Advanced'].filter(x => flt.has(x)); if (lv.length) l = l.filter(i => lv.includes(i.level));
      if (flt.has('Academic') && !flt.has('General Training')) l = l.filter(i => i.track !== 'general'); if (flt.has('General Training') && !flt.has('Academic')) l = l.filter(i => i.track !== 'academic');
      if (flt.has('Recently Added')) l = [...l].sort((a, b) => (b.added || '').localeCompare(a.added || '')); if (flt.has('Most Practised')) l = [...l].sort((a, b) => b.plays - a.plays);
      $('[data-count]', v).textContent = `${l.length} result${l.length === 1 ? '' : 's'}`;
      $('[data-g]', v).innerHTML = l.map(OB.testCardHTML).join('') || `<div class="empty" style="grid-column:1/-1"><div class="ico">${icon('lib', 28)}</div>No tests match these filters.<br><button class="btn btn-ghost" style="margin-top:10px" data-reset>Clear filters</button></div>`;
    };
    $('[data-s]', v).oninput = e => { s = e.target.value.toLowerCase(); draw(); }; $('[data-cat]', v).onchange = e => { cat = e.target.value; draw(); };
    on(v, 'click', '[data-f] .filter', (e, b) => { flt.has(b.dataset.v) ? flt.delete(b.dataset.v) : flt.add(b.dataset.v); draw(); });
    on(v, 'click', '[data-reset]', () => { flt.clear(); cat = 'All'; s = ''; $('[data-s]', v).value = ''; $('[data-cat]', v).value = 'All'; draw(); });
    draw();
  });

  /* ---------- module landing pages (Listening / Reading) ---------- */
  function modulePage(m) {
    const L = m === 'L'; const v = OB.page(L ? 'Listening' : 'Reading'); const tests = OB.allTests().filter(x => x.module === m);
    v.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon(m, 16)} ${L ? 'Listening' : 'Reading'}</span><h1 style="font-size:2.2rem">IELTS ${L ? 'Listening' : 'Reading'} practice</h1>
      <p>${L ? 'Four-section tests with a built-in audio player, every major question type, a countdown timer in exam mode, instant marking with explanations and full transcripts.' : 'Academic and General Training tests in a professional split-screen layout with highlighting, notes, question navigation, a countdown timer and instant marking with explanations.'}</p>
      <div class="row"><span class="chip">${L ? 'Form · notes · map labelling · MCQ · matching · table' : 'TFNG · YNNG · headings · matching · summary · table · flow-chart · short answer'}</span></div></div></div>
      <div class="wrap" style="padding-bottom:40px">${tests.map(tt => `<div class="card" style="margin-bottom:18px"><div class="row between"><div><h2 style="margin:0;font-size:1.35rem">${esc(tt.title)}</h2><div class="row small muted" style="margin-top:6px"><span class="chip ${L ? 'blue' : tt.track === 'general' ? 'mint' : 'blue'}">${L ? 'Academic & General' : tt.track === 'general' ? 'General Training' : 'Academic'}</span><span>${icon('clock', 14)} ${tt.minutes} min</span><span>${OB.testCount(tt)} questions</span><span>${esc(tt.level)}</span></div></div><a class="btn btn-primary" href="#/test/${tt.id}">${icon('play', 14)} Full test</a></div>
        <div class="grid ${tt.parts.length > 2 ? 'g4' : 'g2'}" style="margin-top:16px">${tt.parts.map((p, i) => `<a class="card hover" href="#/test/${tt.id}?part=${i}" style="color:inherit;padding:16px"><b>${esc(p.title)}</b><div class="small muted" style="margin:4px 0 8px">${esc(p.heading && !p.html ? p.heading : (p.context || p.heading || '')).slice(0, 80)}</div><span class="chip">${OB.partNums(p).length} Q · ${[...new Set(p.groups.map(g => ({ gap: 'completion', table: 'table', flow: 'flow-chart', mcq: 'MCQ', tfng: 'T/F/NG', ynng: 'Y/N/NG', match: g.image ? 'map' : 'matching' }[g.type])))].join(', ')}</span></a>`).join('')}</div></div>`).join('')}
      <div class="card tip-card"><h3>${icon('bulb', 18)} Strategy</h3><div class="grid g2 small">${window.TIPS.filter(x => x.m === m).map(x => `<div><b>${esc(x.t)}</b><p class="muted" style="margin:4px 0 0">${esc(x.d)}</p></div>`).join('')}</div></div></div>`;
  }
  OB.route('/listening', () => modulePage('L')); OB.route('/reading', () => modulePage('R'));

  /* ---------- calculator ---------- */
  OB.route('/calculator', () => {
    const v = OB.page('Band calculator'); const opts = [9, 8.5, 8, 7.5, 7, 6.5, 6, 5.5, 5, 4.5, 4, 3.5, 3, 2.5, 2, 1];
    v.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('calc', 16)} Band score calculator</span><h1 style="font-size:2.2rem">IELTS band score calculator</h1><p>Convert raw Listening and Reading scores to estimated bands, add Writing and Speaking, and calculate your overall band.</p></div></div>
    <div class="wrap" style="padding-bottom:40px"><div class="grid g2" style="align-items:start"><div class="card"><form data-calc>
      <div class="grid g2"><div class="field"><label class="lbl" for="cl">Listening raw score (0–40)</label><input class="input" id="cl" type="number" min="0" max="40" name="l" placeholder="e.g. 31"><div class="small muted" data-lb></div></div>
      <div class="field"><label class="lbl" for="cr">Reading raw score (0–40)</label><input class="input" id="cr" type="number" min="0" max="40" name="r" placeholder="e.g. 28"><div class="small muted" data-rb></div></div></div>
      <div class="field"><label class="lbl">Reading test type</label><div class="seg" data-rt><button type="button" class="on" data-v="academic">Academic</button><button type="button" data-v="general">General Training</button></div></div>
      <div class="grid g2"><div class="field"><label class="lbl" for="cw">Writing band (estimated)</label><select class="select" id="cw" name="w"><option value="">Select…</option>${opts.map(o => `<option>${bandLabel(o)}</option>`).join('')}</select></div>
      <div class="field"><label class="lbl" for="cs">Speaking band (estimated)</label><select class="select" id="cs" name="s"><option value="">Select…</option>${opts.map(o => `<option>${bandLabel(o)}</option>`).join('')}</select></div></div>
      <div class="err" data-err></div></form>
      <div class="result-hero" style="margin-top:8px"><div><div class="small" style="opacity:.8">Overall band (estimate)</div><div class="bigband" data-ov>–</div></div><div class="small" style="flex:1;opacity:.9" data-ex>Enter all four scores to calculate the overall band.</div></div></div>
      <div class="card"><h3>How the overall band is calculated</h3><p class="small">Your overall band is the <b>average of the four module bands</b>, rounded to the nearest half band. If the average ends in <b>.25</b>, it rounds <b>up</b> to the next half band; if it ends in <b>.75</b>, it rounds <b>up</b> to the next whole band.</p>
        <p class="small muted">Examples: 6.5 + 6.5 + 5.0 + 7.0 = 25 ÷ 4 = 6.25 → <b>6.5</b>. &nbsp;4.0 + 3.5 + 4.0 + 4.0 = 15.5 ÷ 4 = 3.875 → <b>4.0</b>. &nbsp;6.5 + 6.5 + 6.0 + 6.0 = 25 ÷ 4 = 6.25 → <b>6.5</b>.</p>
        <div class="estimate-note">${icon('info')} Raw-score conversions vary slightly between test versions. These tables are based on widely published IELTS guidance and give estimates only. Admins can adjust them in Admin → Settings.</div>
        <div class="seg" style="margin:14px 0 8px" data-tt><button class="on" data-v="listening">Listening</button><button data-v="academic">Academic Reading</button><button data-v="general">GT Reading</button></div><div data-table></div></div></div></div>`;
    let rt = 'academic'; const f = $('[data-calc]', v);
    const calc = () => {
      const d = Object.fromEntries(new FormData(f)); const err = $('[data-err]', v); err.textContent = '';
      const num = (x, n) => { if (x === '') return null; const k = +x; if (!Number.isInteger(k) || k < 0 || k > 40) { err.textContent = `${n} raw score must be a whole number from 0 to 40.`; return undefined; } return k; };
      const l = num(d.l, 'Listening'), r = num(d.r, 'Reading');
      const lb = l != null && l !== undefined ? OB.rawToBand(l, 'listening') : null, rb = r != null && r !== undefined ? OB.rawToBand(r, rt) : null;
      $('[data-lb]', v).textContent = lb != null ? `→ Band ${bandLabel(lb)}` : ''; $('[data-rb]', v).textContent = rb != null ? `→ Band ${bandLabel(rb)}` : '';
      const w = d.w ? +d.w : null, s = d.s ? +d.s : null; const all = [lb, rb, w, s];
      if (all.every(x => x != null)) { const avg = all.reduce((a, b) => a + b, 0) / 4; const ov = overallBand(all); $('[data-ov]', v).textContent = bandLabel(ov); $('[data-ex]', v).innerHTML = `(${all.map(bandLabel).join(' + ')}) ÷ 4 = <b>${avg.toFixed(3).replace(/0+$/, '').replace(/\.$/, '')}</b> → rounded to <b>${bandLabel(ov)}</b>`; }
      else { $('[data-ov]', v).textContent = '–'; $('[data-ex]', v).textContent = `Enter all four scores to calculate the overall band (${all.filter(x => x != null).length}/4 entered).`; }
    };
    f.oninput = calc; f.onchange = calc;
    on(v, 'click', '[data-rt] button', (e, b) => { rt = b.dataset.v; $$('[data-rt] button', v).forEach(x => x.classList.toggle('on', x === b)); calc(); });
    const table = k => { const tb = OB.tableFor(k); $('[data-table]', v).innerHTML = `<table class="tbl"><thead><tr><th>Raw score</th><th>Band</th></tr></thead><tbody>${tb.filter(r => r[1] >= 2.5).map((r, i, a) => `<tr><td>${r[0]}${i === 0 ? (r[0] < 40 ? '–40' : '') : '–' + (a[i - 1][0] - 1)}</td><td><b>${bandLabel(r[1])}</b></td></tr>`).join('')}</tbody></table>`; };
    on(v, 'click', '[data-tt] button', (e, b) => { $$('[data-tt] button', v).forEach(x => x.classList.toggle('on', x === b)); table(b.dataset.v); }); table('listening');
  });

  /* ---------- MOCK TEST ---------- */
  const MOCK = { academic: { L: 'L1', R: 'RA1', W1: 'WA1-line', W2: 'WA2-opinion' }, general: { L: 'L1', R: 'RG1', W1: 'WG1-formal', W2: 'WG2-social' } };
  const STEPS = ['L', 'R', 'W1', 'W2'];
  const STEP_INFO = { L: ['Listening', 'About 30 minutes · 4 sections · 40 questions'], R: ['Reading', '60 minutes · 3 passages'], W1: ['Writing Task 1', '20 minutes · 150+ words'], W2: ['Writing Task 2', '40 minutes · 250+ words'] };
  OB.route('/mock', () => {
    const v = OB.page('Mock test'); const q = OB.query(); const m = store.s.mock;
    if (m && m.step !== 'done') return mockProgress(v, m);
    if (store.s.settings.requireLogin && !OB.me()) return OB.requireLoginGate(v, store.s.settings.lang === 'bn' ? 'মক টেস্ট' : 'mock tests');
    let track = q.track || (OB.me() && OB.me().type) || 'academic', mode = 'timed';
    v.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('M', 16)} Full mock test</span><h1 style="font-size:2.2rem">Full-length IELTS mock exam</h1><p>Listening, Reading and Writing in a realistic exam sequence with countdown timers, automatic marking and a full result summary. Speaking is a separate interactive session. Free, as always.</p></div></div>
    <div class="wrap" style="padding-bottom:40px"><div class="grid g2" style="align-items:start">
      <div class="card"><h3>1. Choose your test</h3><div class="grid g2" data-track>${[['academic', 'IELTS Academic', 'Academic Reading & Writing'], ['general', 'General Training', 'GT Reading & letter writing']].map(([k, a, b]) => `<button class="card hover" style="text-align:left;cursor:pointer" data-v="${k}"><b>${a}</b><div class="small muted">${b}</div></button>`).join('')}</div>
        <h3 style="margin-top:20px">2. Choose a mode</h3><div class="seg" data-mode><button data-v="timed" class="on">Exam mode (timed)</button><button data-v="practice">Practice mode (no time limit)</button></div>
        <p class="small muted" style="margin-top:10px" data-mdesc></p>
        <button class="btn btn-primary btn-lg" data-start style="margin-top:12px">${icon('play', 16)} Begin mock test</button></div>
      <div class="card"><h3>Exam structure</h3><ul class="list-clean">${STEPS.map(s => `<li><span><b>${STEP_INFO[s][0]}</b><br><span class="small muted">${STEP_INFO[s][1]}</span></span><span class="mod-icon mod-${s[0]}" style="width:36px;height:36px;border-radius:10px">${icon(s[0], 16)}</span></li>`).join('')}<li><span><b>Speaking</b><br><span class="small muted">Separate interactive session · 11–14 minutes</span></span><a class="btn btn-sm btn-ghost" href="#/speaking?tab=mock">Open</a></li></ul>
        <div class="estimate-note" style="margin-top:12px">${icon('info')} You can pause between sections and your answers are saved in this browser. Results are estimates, not official IELTS scores.</div></div></div>
      ${store.s.attempts.filter(a => a.module === 'M').length ? `<div class="card" style="margin-top:18px"><h3>Previous mock tests</h3><ul class="list-clean">${store.s.attempts.filter(a => a.module === 'M').map(a => `<li><span><b>${esc(a.title)}</b><br><span class="small muted">${fmtDate(a.date)}</span></span><span class="row"><span class="band-pill">${bandLabel(a.band)}</span><a class="btn btn-sm btn-ghost" href="#/mock-result/${a.id}">Results</a></span></li>`).join('')}</ul></div>` : ''}</div>`;
    const draw = () => { $$('[data-track] [data-v]', v).forEach(b => b.style.borderColor = b.dataset.v === track ? 'var(--blue)' : ''); $$('[data-mode] button', v).forEach(b => b.classList.toggle('on', b.dataset.v === mode)); $('[data-mdesc]', v).textContent = mode === 'timed' ? 'Strict timers: each recording plays once, and sections submit automatically when time runs out.' : 'No time limits. Recordings can be paused and replayed. Good for a first attempt.'; };
    on(v, 'click', '[data-track] [data-v]', (e, b) => { track = b.dataset.v; draw(); }); on(v, 'click', '[data-mode] button', (e, b) => { mode = b.dataset.v; draw(); }); draw();
    $('[data-start]', v).onclick = () => { store.s.mock = { id: OB.uid(), track, mode, step: 'L', res: {}, started: Date.now(), updated: Date.now() }; store.save(true); runStep(); };
  });
  function mockProgress(v, m) {
    const idx = STEPS.indexOf(m.step);
    v.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('M', 16)} Mock test in progress</span><h1 style="font-size:2rem">${m.track === 'academic' ? 'IELTS Academic' : 'General Training'} mock test</h1><p>${m.mode === 'timed' ? 'Exam mode' : 'Practice mode'} · started ${fmtDate(m.started)}</p></div></div>
      <div class="wrap" style="padding-bottom:40px"><div class="card"><div class="grid g4">${STEPS.map((s, i) => `<div class="card" style="padding:16px;${i === idx ? 'border:2px solid var(--blue)' : ''}"><div class="row between"><b>${STEP_INFO[s][0]}</b>${i < idx ? `<span style="color:var(--ok)">${icon('check', 18)}</span>` : i === idx ? '<span class="chip blue">Next</span>' : ''}</div><div class="small muted">${STEP_INFO[s][1]}</div>${m.res[s] && m.res[s].band != null ? `<div style="margin-top:6px"><span class="band-pill">${bandLabel(m.res[s].band)}</span></div>` : ''}</div>`).join('')}</div>
        <div class="row" style="margin-top:20px"><button class="btn btn-primary btn-lg" data-go>${icon('play', 16)} ${idx > 0 || store.s.progress[mockKey(m)] ? 'Continue with' : 'Start'} ${STEP_INFO[m.step][0]}</button><button class="btn btn-ghost" data-quit>Abandon mock test</button></div></div></div>`;
    $('[data-go]', v).onclick = runStep;
    $('[data-quit]', v).onclick = async () => { if (await confirmBox('Abandon this mock test?', 'Your answers for this mock test will be discarded.', 'Abandon', true)) { Object.keys(store.s.progress).filter(k => k.endsWith(':mock')).forEach(k => delete store.s.progress[k]); store.s.mock = null; store.save(true); OB.render(); } };
  }
  const mockKey = m => { const id = MOCK[m.track][m.step]; const tt = OB.getTest(id); return tt ? `${id}:${tt.parts.map((_, i) => i).join('-')}:mock` : ''; };
  function runStep() {
    const m = store.s.mock; const id = MOCK[m.track][m.step];
    const after = res => { m.res[m.step] = res; const i = STEPS.indexOf(m.step); m.updated = Date.now(); if (i < STEPS.length - 1) { m.step = STEPS[i + 1]; store.save(true); OB.go('#/mock'); OB.render(); toast(`${STEP_INFO[STEPS[i]][0]} complete. Take a breath — next: ${STEP_INFO[m.step][0]}.`, 'ok'); } else finishMock(); };
    if (m.step === 'L' || m.step === 'R') {
      const tt = OB.getTest(id);
      OB.runTest(tt, { mode: m.mode === 'timed' ? 'mock' : 'practice', minutes: m.step === 'L' ? 30 : 60, label: `Mock test · ${STEP_INFO[m.step][0]}`, onFinish: (res, st) => after({ raw: res.raw, total: res.total, band: res.band, perPart: res.perPart, answers: st.answers, testId: id }), onExit: () => { } , exitTo: '#/mock' });
      if (m.mode !== 'timed') { /* practice mode uses separate progress key */ }
    } else {
      const w = OB.getWriting(id);
      OB.runWriting(w, { mock: true, timed: m.mode === 'timed', minutes: m.step === 'W1' ? 20 : 40, label: `Mock test · ${STEP_INFO[m.step][0]}`, onPause: () => { OB.go('#/mock'); OB.render(); toast('Mock test paused — your draft is saved.'); }, onSubmit: (text) => { const r = OB.analyzeWriting(text, w); after({ text, band: r.overall, crit: r.crit, words: r.wc, taskId: id }); } });
    }
  }
  function finishMock() {
    const m = store.s.mock; const r = m.res;
    const wb = (r.W1.band != null && r.W2.band != null) ? Math.round((r.W1.band + 2 * r.W2.band) / 3 * 2) / 2 : (r.W2.band ?? r.W1.band);
    const overall = overallBand([r.L.band, r.R.band, wb].filter(x => x != null));
    m.step = 'done';
    const a = store.addAttempt({ testId: 'mock', module: 'M', title: `Full mock test · ${m.track === 'academic' ? 'Academic' : 'General Training'}`, band: overall, mode: m.mode, mock: { track: m.track, res: r, wb } });
    store.s.mock = null; store.save(true); OB.go('#/mock-result/' + a.id);
  }
  OB.route('/mock-result/:id', ({ id }) => {
    const a = store.s.attempts.find(x => x.id === id); if (!a || !a.mock) return OB.notFound();
    const v = OB.page('Mock result'); const r = a.mock.res; const sp = a.speaking;
    const overall4 = sp != null ? overallBand([r.L.band, r.R.band, a.mock.wb, sp]) : null;
    v.innerHTML = `<div class="page-head"><div class="wrap"><div class="crumbs"><a href="#/mock">Mock test</a> / Results</div><h1 style="font-size:2rem">${esc(a.title)}</h1><p>${fmtDate(a.date)} · ${a.mode === 'timed' ? 'Exam mode' : 'Practice mode'}</p></div></div>
    <div class="wrap fade-in" style="padding-bottom:40px"><div class="result-hero"><div><div class="small" style="opacity:.8">${overall4 != null ? 'Estimated overall band' : 'Estimated band (L + R + W)'}</div><div class="bigband">${bandLabel(overall4 ?? a.band)}</div></div><div style="flex:1;min-width:240px" class="small"><div style="opacity:.9">${overall4 != null ? 'Includes your self-assessed Speaking band.' : 'Add a Speaking band below for a full four-module estimate.'} All scores are estimates for practice, not official IELTS results.</div></div><a class="btn btn-white" href="#/mock">New mock test</a></div>
      <div class="grid g4" style="margin:20px 0">${[['L', 'Listening', r.L.band, `${r.L.raw}/${r.L.total} correct`], ['R', 'Reading', r.R.band, `${r.R.raw}/${r.R.total} correct${r.R.total !== 40 ? ' (scaled)' : ''}`], ['W', 'Writing', a.mock.wb, `Task 1: ${bandLabel(r.W1.band)} · Task 2: ${bandLabel(r.W2.band)} (automated estimate)`], ['S', 'Speaking', sp, sp != null ? 'Self-assessed' : 'Separate session']].map(([k, n, b, d]) => `<div class="card"><div class="row between"><div class="mod-icon mod-${k}" style="width:40px;height:40px">${icon(k, 18)}</div><span class="band-pill" style="font-size:1.1rem;height:38px">${bandLabel(b)}</span></div><h3 style="margin:12px 0 2px">${n}</h3><div class="small muted">${esc(d)}</div></div>`).join('')}</div>
      <div class="card" style="margin-bottom:18px"><div class="row between"><div><h3 style="margin:0">Add your Speaking band</h3><p class="small muted" style="margin:4px 0 0">Take the separate speaking session, then enter your self-assessed band here.</p></div><div class="row"><a class="btn btn-ghost" href="#/speaking?tab=mock">Speaking mock</a><select class="select" style="width:auto" data-sp><option value="">Band…</option>${[9, 8.5, 8, 7.5, 7, 6.5, 6, 5.5, 5, 4.5, 4].map(o => `<option ${sp === o ? 'selected' : ''}>${bandLabel(o)}</option>`).join('')}</select></div></div></div>
      <div class="seg" data-tab style="margin-bottom:14px"><button class="on" data-v="L">Listening review</button><button data-v="R">Reading review</button><button data-v="W">Writing feedback</button></div><div data-pane></div></div>`;
    $('[data-sp]', v).onchange = e => { a.speaking = e.target.value ? +e.target.value : null; store.save(true); OB.render(); };
    const pane = $('[data-pane]', v);
    const show = k => {
      $$('[data-tab] button', v).forEach(b => b.classList.toggle('on', b.dataset.v === k));
      if (k === 'W') { pane.innerHTML = ['W1', 'W2'].map(s => { const w = OB.getWriting(r[s].taskId); return `<div class="card" style="margin-bottom:18px"><h3>${STEP_INFO[s][0]}: ${esc(w ? w.title : '')}</h3><details style="margin-bottom:12px"><summary style="cursor:pointer;font-weight:700">Your answer (${r[s].words} words)</summary><div style="white-space:pre-line;font-family:var(--serif);margin-top:8px">${esc(r[s].text)}</div></details>${w ? OB.writingFeedbackHTML({ text: r[s].text, kind: w.kind, task: w.task, track: w.track }, w) : ''}</div>`; }).join(''); return; }
      const tt = OB.getTest(r[k].testId); pane.innerHTML = tt ? tt.parts.map(p => `<div style="margin-bottom:22px"><h3>${esc(p.title)}${p.heading ? ' — ' + esc(p.heading) : ''}</h3>${OB.renderGroups(p.groups, r[k].answers, true)}</div>`).join('') : '';
    };
    on(v, 'click', '[data-tab] button', (e, b) => show(b.dataset.v)); show('L');
  });

  /* ---------- about ---------- */
  OB.route('/about', () => {
    const v = OB.page('About');
    v.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('heart', 16)} About OpenBand</span><h1 style="font-size:2.2rem">Free IELTS preparation for everyone</h1></div></div>
    <div class="wrap" style="padding-bottom:40px;max-width:900px"><div class="card" style="padding:30px"><h2>Our mission</h2><p style="font-size:1.08rem">This platform was created to make IELTS preparation more accessible. Our goal is to help students practise, improve and prepare without financial barriers.</p>
      <p class="muted">Many IELTS websites lock their most useful features behind subscriptions. OpenBand takes a different approach: every module, every mock test and every learning tool is free. We built it with students in Bangladesh especially in mind, and for learners everywhere.</p>
      <div class="grid g3" style="margin:22px 0">${[['gift', 'Free forever', 'No subscriptions, no premium locks, no payment pages.'], ['check', 'Honest scores', 'Every score is clearly labelled as an estimate.'], ['shield', 'Private by default', 'Your progress and recordings stay in your browser.']].map(([i, a, b]) => `<div><div class="mod-icon mod-L" style="width:42px;height:42px">${icon(i, 20)}</div><h3 style="margin:10px 0 4px">${a}</h3><p class="small muted">${b}</p></div>`).join('')}</div>
      <h3>Independence</h3><p class="small muted">OpenBand is an independent practice platform. It is not affiliated with, endorsed by or connected to IELTS, the British Council, IDP Education or Cambridge University Press & Assessment. All practice material is original.</p>
      </div>
      <div class="dev-card"><img src="${window.DEV.photo}" alt="MD REJON, founder and developer of OpenBand"><div><span class="eyebrow">${t('About the developer')}</span><h2 style="margin:6px 0 4px">MD REJON</h2><div class="chip blue">${t('Founder & Developer')} · OpenBand</div>
        <p style="margin-top:14px" data-notr>${store.s.settings.lang === 'bn' ? 'OpenBand-এর পরিকল্পনা, ডিজাইন ও ডেভেলপমেন্ট করেছেন MD REJON। লক্ষ্য একটাই — বাংলাদেশসহ সব দেশের শিক্ষার্থী যেন কোনো খরচ ছাড়াই মানসম্মত IELTS অনুশীলন করতে পারে।' : 'OpenBand was conceived, designed and developed by MD REJON with one goal: that students in Bangladesh and everywhere can access quality IELTS practice without paying anything.'}</p>
        ${store.s.settings.contactEmail || store.s.settings.contactPhone ? `<p class="small" data-notr>${icon('info', 14)} ${esc(store.s.settings.contactEmail || '')} ${esc(store.s.settings.contactPhone || '')}</p>` : ''}</div></div></div>`;
  });

})();
