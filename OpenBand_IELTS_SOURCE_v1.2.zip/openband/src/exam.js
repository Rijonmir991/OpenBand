/* OpenBand — test engine for Listening & Reading (practice, timed and mock modes) */
(function () {
  const { $, $$, esc, on, icon, store, toast, modal, confirmBox, isCorrect, rawToBand, bandLabel, fmtTime, ScriptPlayer, FilePlayer, Countdown, TTS, idb } = OB;

  /* ---------- content registry (built-in + admin-created) ---------- */
  OB.allTests = () => [...window.LISTENING, ...window.READING, ...store.s.custom.tests];
  OB.getTest = id => OB.allTests().find(t => t.id === id);

  /* ---------- keys & numbering ---------- */
  function groupNums(g) {
    if (g.items) return g.items.map(i => i.n);
    return Object.keys(g.key || {}).map(Number);
  }
  OB.partNums = p => p.groups.flatMap(groupNums).sort((a, b) => a - b);
  OB.testCount = (t, parts) => (parts || t.parts.map((_, i) => i)).reduce((s, i) => s + OB.partNums(t.parts[i]).length, 0);
  function keyMap(groups) {
    const m = {};
    for (const g of groups) {
      if (g.items) g.items.forEach(i => m[i.n] = { a: i.a, why: i.why, choice: true, opts: g.opts || i.opts });
      else Object.keys(g.key).forEach(n => m[n] = { a: g.key[n], why: (g.why || {})[n] });
    }
    return m;
  }
  function correct(k, v) {
    if (!k) return false;
    if (k.choice) return String(v || '').trim().toUpperCase() === String(k.a).toUpperCase();
    return isCorrect(v, k.a);
  }
  function answerText(k) {
    if (k.choice) return k.a;
    const a = Array.isArray(k.a) ? k.a : [k.a];
    return a.map(x => x.replace(/[()]/g, '')).slice(0, 3).join(' / ');
  }
  OB.keyMap = keyMap; OB.isRight = correct;

  /* ---------- question rendering ---------- */
  function gapHTML(n, ans, rv, km) {
    const v = ans[n] || ''; let cls = '', after = '';
    if (rv) { const ok = correct(km[n], v); cls = ok ? 'right' : 'wrong'; if (!ok) after = `<span class="tiny" style="color:var(--ok);font-weight:800">→ ${esc(answerText(km[n]))}</span>`; }
    return `<span class="gap ${cls}" id="q-${n}"><span class="qn">${n}</span><input data-q="${n}" value="${esc(v)}" autocomplete="off" spellcheck="false" aria-label="Question ${n}" ${rv ? 'readonly' : ''}>${after}</span>`;
  }
  const fill = (s, ans, rv, km) => String(s).replace(/\[\[(\d+)\]\]/g, (_, n) => gapHTML(+n, ans, rv, km));
  function whyList(nums, km, ans, rv) {
    if (!rv) return '';
    return `<div class="stack" style="margin-top:14px">${nums.map(n => { const ok = correct(km[n], ans[n]); return `<div class="fb ${ok ? 'ok' : 'no'}"><span class="k">${n}. ${ok ? 'Correct' : (ans[n] ? 'Incorrect' : 'Not answered')}</span> — answer: <b>${esc(answerText(km[n]))}</b>${km[n].why ? `<div class="muted small" style="margin-top:3px">${esc(km[n].why)}</div>` : ''}</div>`; }).join('')}</div>`;
  }
  function renderGroup(g, ans, rv, km) {
    const ins = `<div class="ins">${esc(g.ins || '')}${g.limit ? ` <b>${esc(g.limit)}</b>` : ''}</div>`;
    const ttl = g.title ? `<h3 style="margin:4px 0 12px">${esc(g.title)}</h3>` : '';
    let body = '';
    if (g.type === 'gap') {
      if (g.layout === 'form') body = `<div class="form-box">${g.title ? `<div class="form-head">${esc(g.title)}</div>` : ''}${g.lines.map(l => { const [a, b] = l.split('|'); return `<div class="fr"><div>${esc(a)}</div><div>${fill(b, ans, rv, km)}</div></div>`; }).join('')}</div>`;
      else if (g.layout === 'notes') body = `${ttl}<div class="notes-box">${(() => { let h = '', open = false; g.lines.forEach(l => { if (l[0] === '#') { if (open) h += '</ul>'; h += `<div class="nh">${esc(l.slice(1))}</div><ul>`; open = true; } else { if (!open) { h += '<ul>'; open = true; } h += `<li>${fill(esc(l), ans, rv, km)}</li>`; } }); return h + (open ? '</ul>' : ''); })()}</div>`;
      else if (g.layout === 'summary') body = `${ttl}<div style="line-height:2.3">${g.lines.map(l => `<p>${fill(esc(l), ans, rv, km)}</p>`).join('')}</div>`;
      else if (g.layout === 'short') body = g.lines.map(l => { const m = l.match(/^(.*?)\s*\[\[(\d+)\]\]\s*$/); return `<div class="qitem">${m ? `<div style="margin-bottom:6px">${esc(m[1])}</div>${gapHTML(+m[2], ans, rv, km)}` : fill(esc(l), ans, rv, km)}</div>`; }).join('');
      else body = `${ttl}${g.lines.map(l => `<div class="qitem" style="line-height:2.2">${fill(esc(l), ans, rv, km)}</div>`).join('')}`;
      if (g.layout === 'form') body = body; // title already in head
      return `<div class="qgroup">${ins}${g.layout === 'form' ? '' : ''}${body}${whyList(groupNums(g), km, ans, rv)}</div>`;
    }
    if (g.type === 'table') {
      body = `${ttl}<div style="overflow:auto"><table class="tbl"><thead><tr>${g.head.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${g.rows.map(r => `<tr>${r.map(c => `<td style="line-height:2.2">${fill(esc(c), ans, rv, km)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
      return `<div class="qgroup">${ins}${body}${whyList(groupNums(g), km, ans, rv)}</div>`;
    }
    if (g.type === 'flow') {
      body = `${ttl}<div class="flow">${g.steps.map((s, i) => `${i ? '<div class="arrow"></div>' : ''}<div class="step" style="line-height:2.2">${fill(esc(s), ans, rv, km)}</div>`).join('')}</div>`;
      return `<div class="qgroup">${ins}${body}${whyList(groupNums(g), km, ans, rv)}</div>`;
    }
    if (g.type === 'mcq' || g.type === 'tfng' || g.type === 'ynng') {
      const fixed = g.type === 'tfng' ? ['TRUE', 'FALSE', 'NOT GIVEN'] : g.type === 'ynng' ? ['YES', 'NO', 'NOT GIVEN'] : null;
      body = g.items.map(it => {
        const opts = fixed ? fixed.map(o => ({ k: o, t: o })) : it.opts.map((o, i) => ({ k: 'ABCDEFG'[i], t: o }));
        const v = ans[it.n] || ''; const ok = rv && correct(km[it.n], v);
        return `<div class="qitem" id="q-${it.n}"><div><span class="qn">${it.n}</span>${esc(it.q)}</div>
          <div class="opts" ${fixed ? 'style="grid-template-columns:repeat(3,minmax(0,1fr))"' : ''}>${opts.map(o => {
          let c = v === o.k ? 'sel' : ''; if (rv) { if (o.k === it.a) c = 'right'; else if (v === o.k) c = 'wrong'; else c = ''; }
          return `<label class="opt ${c}"><input type="radio" name="q${it.n}" data-q="${it.n}" value="${o.k}" ${v === o.k ? 'checked' : ''} ${rv ? 'disabled' : ''}><span>${fixed ? `<b>${o.k}</b>` : `<b>${o.k}</b>&nbsp; ${esc(o.t)}`}</span></label>`;
        }).join('')}</div>
          ${rv ? `<div class="fb ${ok ? 'ok' : 'no'}"><span class="k">${ok ? 'Correct' : (v ? 'Incorrect' : 'Not answered')}</span> — answer: <b>${esc(it.a)}</b><div class="muted small">${esc(it.why || '')}</div></div>` : ''}</div>`;
      }).join('');
      return `<div class="qgroup">${ins}${body}</div>`;
    }
    if (g.type === 'match') {
      const list = g.opts.some(o => o.t) ? `<div class="opt-list">${g.listTitle ? `<div style="font-weight:800;margin-bottom:4px">${esc(g.listTitle)}</div>` : ''}${g.opts.map(o => `<div><b>${esc(o.k)}</b>${esc(o.t)}</div>`).join('')}</div>` : '';
      const img = g.image ? `<div class="chart-box" style="margin-bottom:14px;max-width:560px">${g.image}</div>` : '';
      body = g.items.map(it => {
        const v = ans[it.n] || ''; const ok = rv && correct(km[it.n], v);
        return `<div class="qitem row" id="q-${it.n}" style="flex-wrap:nowrap;align-items:flex-start"><span class="qn">${it.n}</span><div style="flex:1">${esc(it.q)}${rv ? `<div class="fb ${ok ? 'ok' : 'no'}" style="margin-top:6px"><span class="k">${ok ? 'Correct' : (v ? 'Incorrect' : 'Not answered')}</span> — answer: <b>${esc(it.a)}</b><div class="muted small">${esc(it.why || '')}</div></div>` : ''}</div>
          <select class="inline-sel ${rv ? (ok ? 'right' : 'wrong') : ''}" data-q="${it.n}" aria-label="Question ${it.n}" ${rv ? 'disabled' : ''}><option value="">—</option>${g.opts.map(o => `<option value="${esc(o.k)}" ${v === o.k ? 'selected' : ''}>${esc(o.k)}</option>`).join('')}</select></div>`;
      }).join('');
      return `<div class="qgroup">${ins}${img}${list}${body}</div>`;
    }
    return '';
  }
  OB.renderGroups = (groups, ans, rv) => { const km = keyMap(groups); return groups.map(g => renderGroup(g, ans, rv, km)).join(''); };

  /* ---------- passage rendering ---------- */
  function passageHTML(p) {
    if (p.html) return `<div class="passage">${p.html}</div>`;
    return `<div class="passage"><h2>${esc(p.heading || '')}</h2>${(p.paras || []).map((t, i) => `<p>${p.lettered ? `<span class="pl">${'ABCDEFGHIJ'[i]}</span>` : ''}${esc(t)}</p>`).join('')}</div>`;
  }

  /* ---------- audio player UI ---------- */
  function mountPlayer(box, part, { locked = false, onDone } = {}) {
    let player, playedOnce = false;
    const setup = async () => {
      let url = null;
      if (part.audioKey) { try { const b = await idb.get(part.audioKey); if (b) url = URL.createObjectURL(b); } catch (e) { } }
      const lockNote = locked ? '<span class="tiny" style="color:#AAB6DD">Exam mode: the recording plays once, with no rewinding.</span>' : '';
      box.innerHTML = `<div class="player"><button class="pbtn" data-pp aria-label="Play">${icon('play', 22)}</button>
        <div class="track"><div class="row between" style="margin-bottom:6px"><b style="font-size:.92rem">${esc(part.title)} audio</b><div class="eq paused"><i></i><i></i><i></i><i></i></div></div>
        <div class="pbar ${locked ? 'locked' : ''}" data-bar><i style="width:0%"></i></div><div class="ptime"><span data-el>00:00</span><span data-tot>--:--</span></div>${lockNote}</div>
        ${locked ? '' : `<select data-rate aria-label="Playback speed"><option value=".8">0.8×</option><option value="1" selected>1×</option><option value="1.15">1.15×</option></select>`}</div>
        ${!url && !TTS.ok ? `<div class="estimate-note" style="margin-top:10px">${icon('info')} Your browser does not support speech playback. Use “Show transcript” in practice mode, or try Chrome / Edge.</div>` : ''}`;
      const pp = $('[data-pp]', box), bar = $('[data-bar] i', box), el = $('[data-el]', box), tot = $('[data-tot]', box), eq = $('.eq', box);
      const tick = (e, t) => { bar.style.width = (t ? e / t * 100 : 0) + '%'; el.textContent = fmtTime(e); tot.textContent = fmtTime(t); };
      const onEnd = () => { pp.innerHTML = icon('play', 22); eq.classList.add('paused'); playedOnce = true; if (locked) pp.disabled = true; onDone && onDone(); };
      if (url) player = new FilePlayer(url, { onTick: tick, onEnd });
      else player = new ScriptPlayer(part.script || [], { onTick: tick, onEnd, onLine: i => { const tr = $$('.transcript p', document); tr.forEach((p, k) => p.classList.toggle('now', k === i)); } });
      tick(0, player.totalTime());
      pp.onclick = () => {
        if (player.playing) { if (locked) return toast('In exam mode the recording cannot be paused.'); player.pause(); pp.innerHTML = icon('play', 22); eq.classList.add('paused'); }
        else { if (locked && playedOnce) return; if (player.play() === false) return toast('Speech playback is not available in this browser.', 'bad'); pp.innerHTML = icon(locked ? 'play' : 'pause', 22); eq.classList.remove('paused'); if (locked) pp.disabled = true; }
      };
      if (!locked) {
        $('[data-bar]', box).onclick = e => { const r = e.currentTarget.getBoundingClientRect(); const f = (e.clientX - r.left) / r.width; if (player.seekFrac) player.seekFrac(f); else player.seek(Math.floor(f * player.lines.length)); };
        $('[data-rate]', box).onchange = e => player.setRate(+e.target.value);
      }
    };
    setup();
    return { destroy: () => player && player.destroy(), get player() { return player; } };
  }
  OB.mountPlayer = mountPlayer;

  function transcriptHTML(part) {
    if (!part.script) return '';
    return `<div class="transcript">${part.script.map(l => `<p>${l.s ? `<span class="spk">${esc(l.s)}:</span> ` : '<i class="muted">'}${esc(l.t)}${l.s ? '' : '</i>'}</p>`).join('')}</div>`;
  }

  /* ---------- selection highlighter for passages ---------- */
  function enableHighlighter(root, onChange) {
    let pop = null;
    const kill = () => { pop && pop.remove(); pop = null; };
    const show = (x, y, buttons) => { kill(); pop = document.createElement('div'); pop.className = 'sel-pop'; pop.style.left = Math.max(8, x - 80) + 'px'; pop.style.top = Math.max(8, y - 48) + 'px'; buttons.forEach(([label, fn]) => { const b = document.createElement('button'); b.textContent = label; b.onmousedown = e => e.preventDefault(); b.onclick = () => { fn(); kill(); }; pop.appendChild(b); }); document.body.appendChild(pop); };
    const wrap = (note) => {
      const sel = getSelection(); if (!sel.rangeCount) return; const r = sel.getRangeAt(0);
      if (!root.contains(r.commonAncestorContainer) || r.collapsed) return;
      const m = document.createElement('mark'); m.className = 'hl' + (note ? ' note' : ''); if (note) m.dataset.note = note, m.title = note;
      try { r.surroundContents(m); } catch (e) { m.appendChild(r.extractContents()); r.insertNode(m); }
      sel.removeAllRanges(); onChange();
    };
    const up = e => {
      setTimeout(() => {
        const sel = getSelection(); if (!sel.rangeCount || sel.isCollapsed) return;
        const r = sel.getRangeAt(0); if (!root.contains(r.commonAncestorContainer)) return;
        const b = r.getBoundingClientRect();
        show(b.left + b.width / 2, b.top, [['Highlight', () => wrap()], ['Add note', () => { const sel = getSelection(); const saved = sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null; const m = OB.modal(`<h3>Add a note</h3><textarea class="textarea" rows="3" data-note placeholder="Your note…"></textarea><div class="row end" style="margin-top:12px"><button class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-primary" data-ok>Save note</button></div>`); m.el.querySelector('[data-ok]').onclick = () => { const t = m.el.querySelector('[data-note]').value.trim(); m.close(); if (t && saved) { sel.removeAllRanges(); sel.addRange(saved); wrap(t); } }; }]]);
      }, 10);
    };
    root.addEventListener('mouseup', up); root.addEventListener('touchend', up);
    root.addEventListener('click', e => {
      const m = e.target.closest('mark.hl'); if (!m) return;
      const b = m.getBoundingClientRect();
      show(b.left + b.width / 2, b.top, [...(m.dataset.note ? [['Note: ' + m.dataset.note.slice(0, 40), () => { }]] : []), ['Remove', () => { m.replaceWith(...m.childNodes); onChange(); }]]);
    });
    document.addEventListener('mousedown', e => { if (pop && !pop.contains(e.target)) kill(); });
    return kill;
  }

  /* ---------- the runner ---------- */
  // opts: {parts:[idx], mode:'practice'|'timed'|'mock', minutes, onFinish(result), onExit, label}
  OB.runTest = function (test, opts = {}) {
    const parts = opts.parts || test.parts.map((_, i) => i);
    const mode = opts.mode || 'practice'; const timed = mode !== 'practice';
    const isL = test.module === 'L';
    const key = `${test.id}:${parts.join('-')}:${mode}`;
    const saved = store.s.progress[key];
    const st = saved ? JSON.parse(JSON.stringify(saved)) : { answers: {}, flags: [], cur: 0, elapsed: 0, hl: {} };
    st.title = test.title; st.testId = test.id; st.parts = parts; st.mode = mode; st.module = test.module; st.updated = Date.now();
    const persist = () => { st.updated = Date.now(); store.s.progress[key] = st; store.save(); };
    const minutes = opts.minutes || (parts.length === test.parts.length ? test.minutes : Math.max(5, Math.round(test.minutes * parts.length / test.parts.length)));
    const allNums = parts.flatMap(i => OB.partNums(test.parts[i]));
    let players = [], timer = null, killHL = null;

    const root = document.createElement('div'); root.className = 'exam'; root.setAttribute('role', 'application');
    document.body.appendChild(root); document.body.style.overflow = 'hidden';
    const close = () => { players.forEach(p => p.destroy()); timer && timer.stop(); killHL && killHL(); TTS.stop(); root.remove(); document.body.style.overflow = ''; };
    OB.onLeave(close);

    root.innerHTML = `<div class="exam-top">${OB.LOGO(30)}<div class="ttl">${esc(opts.label || test.title)}<small data-sub></small></div>
      <div class="timer" data-timer aria-live="off">${icon('clock', 18)} <span>${timed ? fmtTime(minutes * 60) : '00:00'}</span></div>
      <button class="btn btn-sm btn-outline-white" data-exit>${mode === 'mock' ? 'Pause' : 'Save & exit'}</button></div>
      <div class="mobile-tabs" ${isL ? 'style="display:none!important"' : ''}><button data-mt="p" class="on">Passage</button><button data-mt="q">Questions</button></div>
      <div class="exam-body" data-body></div>
      <div class="exam-foot"><button class="btn btn-sm btn-ghost" data-prev aria-label="Previous part">${icon('left', 16)}</button><div class="qnav" data-qnav></div><button class="btn btn-sm btn-ghost" data-next aria-label="Next part">${icon('right', 16)}</button><button class="btn btn-sm btn-primary" data-submit>Review & submit</button></div>`;
    const body = $('[data-body]', root), qnav = $('[data-qnav]', root);

    function drawNav() {
      qnav.innerHTML = parts.map((pi, k) => `<span class="part-lbl">${esc(test.parts[pi].title.replace('Section', 'S').replace('Passage', 'P'))}</span>` + OB.partNums(test.parts[pi]).map(n => `<button data-go="${n}" data-part="${k}" class="${st.answers[n] ? 'done' : ''} ${st.flags.includes(n) ? 'flag' : ''}" title="Question ${n}${st.flags.includes(n) ? ' (flagged)' : ''}">${n}</button>`).join('')).join('');
    }
    function drawPart() {
      players.forEach(p => p.destroy()); players = []; killHL && killHL(); killHL = null;
      const pi = parts[st.cur], part = test.parts[pi];
      $('[data-sub]', root).textContent = `${part.title}${part.heading && !part.html ? ' · ' + part.heading : ''} — Questions ${OB.partNums(part)[0]}–${OB.partNums(part).slice(-1)[0]}`;
      const qs = `<div class="row between" style="margin-bottom:12px"><span class="chip blue">${esc(part.title)}</span><button class="btn btn-sm btn-ghost" data-flag>${icon('flag', 15)} Flag current</button></div>${OB.renderGroups(part.groups, st.answers, false)}
        <div class="row between" style="margin:18px 0 30px"><button class="btn btn-ghost" data-prev ${st.cur === 0 ? 'disabled' : ''}>${icon('left', 16)} Previous</button>${st.cur < parts.length - 1 ? `<button class="btn btn-primary" data-next>Next ${esc(test.parts[parts[st.cur + 1]].title)} ${icon('right', 16)}</button>` : `<button class="btn btn-primary" data-submit>Review & submit</button>`}</div>`;
      if (isL) {
        body.innerHTML = `<div class="pane" style="flex:1"><div style="max-width:880px;margin:0 auto"><p class="muted small" style="margin:0 0 10px">${esc(part.context || '')}</p><div data-player></div>
          ${mode === 'practice' ? `<details style="margin:12px 0"><summary class="small" style="cursor:pointer;font-weight:700">Show transcript (practice mode)</summary><div style="margin-top:10px">${transcriptHTML(part)}</div></details>` : '<div style="height:16px"></div>'}${qs}</div></div>`;
        const pl = mountPlayer($('[data-player]', body), part, { locked: timed }); players.push(pl);
      } else {
        body.innerHTML = `<div class="split show-p" data-split style="--left:${st.split || 50}%"><div class="pane passage-pane" data-passage>${part.note ? `<div class="chip gold" style="margin-bottom:12px">${esc(part.note)}</div>` : ''}<div class="tiny faint" style="margin-bottom:8px">Tip: select text to highlight it or add a note.</div>${st.hl[pi] || passageHTML(part)}</div><div class="gutter" data-gutter role="separator" aria-label="Resize panels"></div><div class="pane q-pane">${qs}</div></div>`;
        const pas = $('[data-passage] .passage', body);
        killHL = enableHighlighter(pas, () => { st.hl[pi] = pas.outerHTML; persist(); });
        const g = $('[data-gutter]', body), split = $('[data-split]', body);
        g.onpointerdown = e => { g.classList.add('drag'); g.setPointerCapture(e.pointerId); const r = split.getBoundingClientRect(); g.onpointermove = ev => { const p = Math.min(75, Math.max(25, (ev.clientX - r.left) / r.width * 100)); split.style.setProperty('--left', p + '%'); st.split = p; }; g.onpointerup = () => { g.classList.remove('drag'); g.onpointermove = null; persist(); }; };
        $$('[data-mt]', root).forEach(b => b.classList.toggle('on', b.dataset.mt === 'p'));
      }
      drawNav();
    }
    // inputs
    const onInput = (e, el) => {
      const n = +el.dataset.q; const v = el.value;
      if (el.type === 'radio') { $$(`input[name="q${n}"]`, root).forEach(r => r.closest('.opt').classList.toggle('sel', r.checked)); }
      if (v) st.answers[n] = v; else delete st.answers[n];
      st.lastQ = n; persist(); const b = $(`[data-go="${n}"]`, qnav); b && b.classList.toggle('done', !!v);
    };
    on(root, 'input', '[data-q]', onInput); on(root, 'change', '[data-q]', onInput);
    on(root, 'focusin', '[data-q]', (e, el) => { st.lastQ = +el.dataset.q; $$('.cur', qnav).forEach(b => b.classList.remove('cur')); const b = $(`[data-go="${el.dataset.q}"]`, qnav); b && b.classList.add('cur'); });
    on(root, 'click', '[data-go]', (e, b) => {
      const k = +b.dataset.part; const go = () => { const t = $('#q-' + b.dataset.go, root); if (t) { t.scrollIntoView({ behavior: 'smooth', block: 'center' }); const inp = $('[data-q]', t) || (t.matches('[data-q]') ? t : null); inp && inp.focus({ preventScroll: true }); const sp = $('[data-split]', root); if (sp) { sp.classList.remove('show-p'); sp.classList.add('show-q'); $$('[data-mt]', root).forEach(x => x.classList.toggle('on', x.dataset.mt === 'q')); } } };
      if (k !== st.cur) { st.cur = k; persist(); drawPart(); setTimeout(go, 60); } else go();
    });
    on(root, 'click', '[data-prev]', () => { if (st.cur > 0) { st.cur--; persist(); drawPart(); body.scrollTop = 0; } });
    on(root, 'click', '[data-next]', () => { if (st.cur < parts.length - 1) { st.cur++; persist(); drawPart(); } });
    on(root, 'click', '[data-flag]', () => { const n = st.lastQ || OB.partNums(test.parts[parts[st.cur]])[0]; const i = st.flags.indexOf(n); i >= 0 ? st.flags.splice(i, 1) : st.flags.push(n); persist(); drawNav(); toast(i >= 0 ? `Question ${n} unflagged` : `Question ${n} flagged for review`); });
    on(root, 'click', '[data-mt]', (e, b) => { const sp = $('[data-split]', root); if (!sp) return; sp.classList.toggle('show-p', b.dataset.mt === 'p'); sp.classList.toggle('show-q', b.dataset.mt === 'q'); $$('[data-mt]', root).forEach(x => x.classList.toggle('on', x === b)); });
    on(root, 'click', '[data-exit]', async () => {
      if (mode === 'mock') { opts.onExit ? opts.onExit(st) : null; persist(); close(); OB.go('#/mock'); toast('Mock test paused — your answers are saved.'); return; }
      persist(); close(); toast('Progress saved. You can continue from your dashboard.', 'ok'); OB.go(opts.exitTo || (isL ? '#/listening' : '#/reading'));
    });
    on(root, 'click', '[data-submit]', () => reviewModal());

    function reviewModal() {
      const un = allNums.filter(n => !st.answers[n]);
      const m = modal(`<h3>Review before submitting</h3><p class="muted">You have answered <b>${allNums.length - un.length}</b> of <b>${allNums.length}</b> questions.</p>
        ${un.length ? `<div class="estimate-note" style="margin-bottom:12px">${icon('info')} <div>Unanswered: ${un.map(n => `<a href="#" data-jump="${n}">${n}</a>`).join(', ')}</div></div>` : '<div class="badge-free" style="margin-bottom:12px">All questions answered</div>'}
        ${st.flags.length ? `<p class="small">Flagged: ${st.flags.sort((a, b) => a - b).map(n => `<a href="#" data-jump="${n}">${n}</a>`).join(', ')}</p>` : ''}
        <p class="small muted">After submitting you cannot change your answers.</p>
        <div class="row end"><button class="btn btn-ghost" data-close>Go back</button><button class="btn btn-primary" data-final>Submit answers</button></div>`);
      on(m.el, 'click', '[data-jump]', (e, a) => { e.preventDefault(); m.close(); const b = $(`[data-go="${a.dataset.jump}"]`, qnav); b && b.click(); });
      $('[data-final]', m.el).onclick = () => { m.close(); finish(); };
    }
    function finish(auto) {
      timer && timer.stop();
      const res = OB.scoreTest(test, parts, st.answers);
      res.mode = mode; res.elapsed = Math.round(st.elapsed);
      delete store.s.progress[key]; store.save();
      if (opts.onFinish) { close(); opts.onFinish(res, st); return; }
      const att = store.addAttempt({ testId: test.id, module: test.module, title: opts.label || test.title, raw: res.raw, total: res.total, band: res.band, kind: res.kind, mode, parts, answers: st.answers, perPart: res.perPart, elapsed: res.elapsed });
      close(); if (auto) toast('Time is up — your answers were submitted automatically.');
      OB.go('#/result/' + att.id);
    }
    // timer
    const tEl = $('[data-timer]', root);
    if (timed) {
      timer = new Countdown(minutes * 60, { startElapsed: st.elapsed, onTick: (left, el) => { st.elapsed = el; $('span', tEl).textContent = fmtTime(left); tEl.classList.toggle('low', left < 300); if (Math.round(el) % 5 === 0) persist(); }, onEnd: () => finish(true) });
      timer.start();
    } else {
      timer = new Countdown(1e9, { startElapsed: st.elapsed, onTick: (left, el) => { st.elapsed = el; $('span', tEl).textContent = fmtTime(el); if (Math.round(el) % 5 === 0) persist(); } }); timer.start();
    }
    drawPart();
    if (saved) toast('Restored your saved answers.', 'ok');
    return { close };
  };

  OB.scoreTest = function (test, parts, answers) {
    let raw = 0, total = 0; const perPart = [];
    parts.forEach(pi => { const p = test.parts[pi]; const km = keyMap(p.groups); const nums = OB.partNums(p); let r = 0; nums.forEach(n => { if (correct(km[n], answers[n])) r++; }); raw += r; total += nums.length; perPart.push({ title: p.title, raw: r, total: nums.length }); });
    const kind = test.module === 'L' ? 'listening' : (test.track === 'general' ? 'general' : 'academic');
    return { raw, total, perPart, kind, band: rawToBand(raw, kind, total) };
  };

  /* ---------- results page ---------- */
  OB.route('/result/:id', ({ id }) => {
    const a = store.s.attempts.find(x => x.id === id); if (!a) return OB.notFound();
    const test = OB.getTest(a.testId); const app = OB.page();
    const pct = Math.round(a.raw / a.total * 100);
    app.innerHTML = `<div class="page-head"><div class="wrap"><div class="crumbs"><a href="#/dashboard">Dashboard</a> / Result</div><h1 style="font-size:2rem">${esc(a.title)}</h1></div></div>
    <div class="wrap fade-in" style="padding-bottom:40px">
      <div class="result-hero"><div><div class="small" style="opacity:.8">Estimated band</div><div class="bigband">${bandLabel(a.band)}</div></div>
        <div style="flex:1;min-width:220px"><div style="font-size:1.25rem;font-weight:800">${a.raw} / ${a.total} correct (${pct}%)</div>
        <div style="opacity:.85" class="small">${a.mode === 'practice' ? 'Practice mode' : 'Timed mode'} · ${fmtTime(a.elapsed || 0)} spent · ${OB.fmtDate(a.date)}</div>
        <div class="small" style="opacity:.85;margin-top:8px">${a.total !== 40 ? `Band estimated by scaling ${a.total} questions to a 40-question test — treat it as a rough guide.` : 'Estimated from a standard raw-score conversion table.'} Not an official IELTS score.</div></div>
        <div class="row"><a class="btn btn-white" href="#/test/${esc(a.testId)}">${icon('refresh', 16)} Try again</a><a class="btn btn-outline-white" href="#/dashboard">Dashboard</a></div></div>
      <div class="grid g3" style="margin:22px 0">${(a.perPart || []).map(p => `<div class="card"><div class="row between"><b>${esc(p.title)}</b><span class="chip blue">${p.raw}/${p.total}</span></div><div class="bar mint" style="margin-top:10px"><i style="width:${p.raw / p.total * 100}%"></i></div></div>`).join('')}</div>
      <div class="row between" style="margin:26px 0 12px"><h2 style="margin:0">Answer review</h2><div class="seg" data-filter><button class="on" data-f="all">All</button><button data-f="wrong">Mistakes only</button></div></div>
      <div data-review></div></div>`;
    if (!test) { $('[data-review]', app).innerHTML = '<div class="empty">This test is no longer available.</div>'; return; }
    const draw = (only) => {
      $('[data-review]', app).innerHTML = a.parts.map(pi => { const p = test.parts[pi]; return `<div style="margin-bottom:26px"><h3>${esc(p.title)}${p.heading ? ' — ' + esc(p.heading) : ''}</h3>
        ${test.module === 'L' ? `<details style="margin-bottom:12px"><summary style="cursor:pointer;font-weight:700">Transcript</summary><div style="margin-top:10px">${transcriptHTML(p)}</div></details>` : `<details style="margin-bottom:12px"><summary style="cursor:pointer;font-weight:700">Show passage</summary><div class="card" style="margin-top:10px">${passageHTML(p)}</div></details>`}
        ${OB.renderGroups(p.groups, a.answers, true)}</div>`; }).join('');
      if (only) { $$('.fb.ok', app).forEach(f => { const q = f.closest('.qitem'); if (q) q.style.display = 'none'; else f.style.display = 'none'; }); }
    };
    draw(false);
    on(app, 'click', '[data-f]', (e, b) => { $$('[data-f]', app).forEach(x => x.classList.toggle('on', x === b)); draw(b.dataset.f === 'wrong'); });
  });

  /* ---------- pre-test screen ---------- */
  OB.route('/test/:id', ({ id }) => {
    const test = OB.getTest(id); if (!test) return OB.notFound();
    const q = OB.query(); const single = q.part != null ? [+q.part] : null; const app = OB.page();
    if (store.s.settings.requireLogin && !OB.me()) return OB.requireLoginGate(app, store.s.settings.lang === 'bn' ? 'টেস্ট' : 'practice tests');
    const isL = test.module === 'L';
    const parts = single || test.parts.map((_, i) => i);
    const n = OB.testCount(test, parts); const mins = single ? Math.max(5, Math.round(test.minutes / test.parts.length)) : test.minutes;
    const resumable = Object.keys(store.s.progress).filter(k => k.startsWith(`${test.id}:${parts.join('-')}:`) && !k.endsWith(':mock'));
    app.innerHTML = `<div class="page-head"><div class="wrap"><div class="crumbs"><a href="#/library">Library</a> / <a href="#/${isL ? 'listening' : 'reading'}">${isL ? 'Listening' : 'Reading'}</a></div>
      <h1 style="font-size:2rem">${esc(test.title)}${single ? ' · ' + esc(test.parts[single[0]].title) : ''}</h1>
      <div class="row"><span class="chip ${isL ? 'blue' : 'mint'}">${isL ? 'Listening' : (test.track === 'general' ? 'General Training Reading' : 'Academic Reading')}</span><span class="chip">${esc(test.level)}</span><span class="chip">${icon('clock', 13)} ${mins} min</span><span class="chip">${n} questions</span></div></div></div>
    <div class="wrap" style="padding-bottom:40px"><div class="grid g2" style="align-items:start">
      <div class="card"><h3>Choose a mode</h3>
        <label class="opt sel" style="margin-bottom:8px"><input type="radio" name="mode" value="practice" checked><span><b>Practice mode</b><br><span class="small muted">No time limit. ${isL ? 'Pause, rewind and view the transcript.' : 'Take your time.'} Answers are saved automatically.</span></span></label>
        <label class="opt"><input type="radio" name="mode" value="timed"><span><b>Timed test</b><br><span class="small muted">${mins}-minute countdown${isL ? '; each recording plays once' : ''}. Auto-submits when time runs out.</span></span></label>
        <div class="row" style="margin-top:16px"><button class="btn btn-primary btn-lg" data-start>${icon('play', 16)} Start</button>${resumable.length ? `<button class="btn btn-ghost btn-lg" data-resume="${esc(resumable[0])}">Continue saved attempt</button>` : ''}</div></div>
      <div class="card"><h3>Before you start</h3><ul class="small" style="padding-left:18px;margin:0">
        ${isL ? '<li>Use headphones and turn up your volume. Audio is generated by your browser\'s voice engine.</li><li>Read the questions before pressing play.</li><li>Answers are not case-sensitive, but spelling counts.</li>' : '<li>The passage is on the left and questions on the right. Drag the divider to resize.</li><li>Select passage text to highlight it or attach a note.</li><li>Use the numbered buttons at the bottom to jump between questions.</li>'}
        <li>Flag questions to come back to them. You will see unanswered questions before you submit.</li></ul>
        <div class="hr"></div><h3 class="small" style="text-transform:uppercase;letter-spacing:.06em;color:var(--muted)">Sections</h3>
        <ul class="list-clean">${parts.map(pi => `<li><span>${esc(test.parts[pi].title)}${test.parts[pi].heading ? ` <span class="muted small">· ${esc(test.parts[pi].heading)}</span>` : ''}</span><span class="chip">${OB.partNums(test.parts[pi]).length} Q</span></li>`).join('')}</ul></div></div></div>`;
    on(app, 'change', 'input[name=mode]', () => $$('.opt', app).forEach(o => o.classList.toggle('sel', $('input', o).checked)));
    $('[data-start]', app).onclick = () => { const mode = $('input[name=mode]:checked', app).value; OB.runTest(test, { parts, mode, minutes: mins, label: test.title + (single ? ' · ' + test.parts[single[0]].title : '') }); };
    const r = $('[data-resume]', app); if (r) r.onclick = () => { const mode = r.dataset.resume.split(':')[2]; OB.runTest(test, { parts, mode, minutes: mins, label: test.title + (single ? ' · ' + test.parts[single[0]].title : '') }); };
  });
})();
