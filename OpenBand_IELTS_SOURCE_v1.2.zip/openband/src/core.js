/* OpenBand IELTS — core: utilities, storage, router, i18n, icons, scoring, audio */
'use strict';
const OB = window.OB = {};

/* ---------- DOM helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const today = () => new Date().toISOString().slice(0, 10);
const fmtTime = s => { s = Math.max(0, Math.round(s)); const m = Math.floor(s / 60), x = s % 60; return `${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}`; };
const fmtDate = iso => new Date(iso).toLocaleDateString(OB.locale ? OB.locale() : undefined, { day: 'numeric', month: 'short', year: 'numeric' });
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const pick = a => a[Math.floor(Math.random() * a.length)];
function on(root, ev, sel, fn) { root.addEventListener(ev, e => { const t = e.target.closest(sel); if (t && root.contains(t)) fn(e, t); }); }
Object.assign(OB, { $, $$, esc, uid, clamp, today, fmtTime, fmtDate, shuffle, pick, on });

/* ---------- Icons (stroke icons, 24px grid) ---------- */
const ICON_PATHS = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  dash: '<rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/>',
  L: '<path d="M3 14v-2a9 9 0 0118 0v2"/><rect x="2" y="14" width="5" height="7" rx="2"/><rect x="17" y="14" width="5" height="7" rx="2"/>',
  R: '<path d="M2 4h7a3 3 0 013 3v13a2 2 0 00-2-2H2z"/><path d="M22 4h-7a3 3 0 00-3 3v13a2 2 0 012-2h8z"/>',
  W: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>',
  S: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v1a7 7 0 0014 0v-1"/><path d="M12 18v4"/>',
  M: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M9 3v2h6V3"/><path d="M8 11h8M8 15h5"/>',
  V: '<path d="M12 3l1.9 4.6L19 8.2l-3.8 3.4 1 5-4.2-2.6L7.8 16.6l1-5L5 8.2l5.1-.6z"/>',
  calc: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h.01M12 19h4"/>',
  lib: '<path d="M4 19V5a2 2 0 012-2h13v16H6a2 2 0 00-2 2zm0 0a2 2 0 002 2h13"/><path d="M9 7h6"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
  shield: '<path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>', x: '<path d="M18 6L6 18M6 6l12 12"/>',
  play: '<path d="M7 4l13 8-13 8z" fill="currentColor"/>', pause: '<rect x="6" y="4" width="4" height="16" rx="1" fill="currentColor"/><rect x="14" y="4" width="4" height="16" rx="1" fill="currentColor"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', check: '<path d="M20 6L9 17l-5-5"/>',
  flag: '<path d="M4 22V4M4 4h12l-2 4 2 4H4"/>', star: '<path d="M12 3l2.8 5.9 6.2.8-4.6 4.3 1.2 6.2L12 17.2 6.4 20.2l1.2-6.2L3 9.7l6.2-.8z"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>', left: '<path d="M15 18l-6-6 6-6"/>', right: '<path d="M9 18l6-6-6-6"/>',
  trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0z"/><path d="M17 5h3v2a3 3 0 01-3 3M7 5H4v2a3 3 0 003 3"/>',
  flame: '<path d="M12 22c4 0 7-3 7-7 0-5-5-7-5-12-3 2-4 5-4 7-1-1-2-2-2-4-2 2-3 5-3 9 0 4 3 7 7 7z"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>', download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>', upload: '<path d="M12 21V9M7 14l5-5 5 5M4 3h16"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 15h10l1-15"/>', edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>', plus: '<path d="M12 5v14M5 12h14"/>',
  vol: '<path d="M11 5L6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 010 7M18.5 5.5a9 9 0 010 13"/>', refresh: '<path d="M21 12a9 9 0 11-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/>', heart: '<path d="M20.8 4.6a5.5 5.5 0 00-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 00-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 000-7.8z"/>',
  bulb: '<path d="M9 18h6M10 22h4M12 2a7 7 0 00-4 12.7V17h8v-2.3A7 7 0 0012 2z"/>', chart: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/>', eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/>', logout: '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/>',
  layers: '<path d="M12 2l10 6-10 6L2 8z"/><path d="M2 16l10 6 10-6"/>', zap: '<path d="M13 2L3 14h8l-1 8 10-12h-8z"/>', gift: '<rect x="3" y="8" width="18" height="4"/><path d="M5 12v9h14v-9M12 8v13M12 8S10 3 7.5 4 9 8 12 8zm0 0s2-5 4.5-4S15 8 12 8z"/>'
};
const icon = (n, s = 20, extra = '') => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${ICON_PATHS[n] || ''}</svg>`;
const LOGO = (s = 36) => `<svg class="logo" width="${s}" height="${s}" viewBox="0 0 40 40" aria-hidden="true"><defs><linearGradient id="lg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3157D5"/><stop offset="1" stop-color="#9B7BFF"/></linearGradient></defs><rect width="40" height="40" rx="12" fill="url(#lg1)"/><rect x="9" y="22" width="5" height="9" rx="2.5" fill="#fff" opacity=".65"/><rect x="17.5" y="16" width="5" height="15" rx="2.5" fill="#fff" opacity=".85"/><rect x="26" y="9" width="5" height="22" rx="2.5" fill="#72D6B2"/></svg>`;
OB.icon = icon; OB.LOGO = LOGO;

/* ---------- Storage ----------
   Two layers in localStorage:
   • GLOBAL  ("openband:global")      — site settings, admin content, student accounts, notices, session
   • DATA    ("openband:data:<uid>")  — one per student (or "guest"): results, drafts, essays, words…
   Everything goes through OB.store, so an online database can replace it later (see README). */
const GKEY = 'openband:global', DKEY = id => 'openband:data:' + (id || 'guest'), OLDKEY = 'openband:v1';
const SHARED = ['settings', 'custom', 'admin', 'users', 'session', 'notices'];
const DATA_DEFAULT = () => ({ profile: null, attempts: [], activity: {}, progress: {}, drafts: {}, writing: [], speaking: [], favWords: [], wordsSeen: {}, grammarDone: {}, mock: null, lastVisit: null, certs: [] });
const SETTINGS_DEFAULT = () => ({ theme: null, lang: 'en', dailyGoal: 3, siteTagline: 'Prepare Better. Practise More. Pay Nothing.', announcement: '', contactEmail: '', contactPhone: '', certMinTests: 3, requireLogin: false, allowRegister: true });
const GLOBAL_DEFAULT = () => ({ settings: SETTINGS_DEFAULT(), custom: { tests: [], writing: [], speaking: [], vocab: [], grammar: [] }, admin: null, users: [], session: null, notices: [] });
/* Storage that also works where the browser blocks it (sandboxed previews): falls back to memory. */
const mkStore = name => { try { const s = window[name]; s.setItem('__ob', '1'); s.removeItem('__ob'); return s; } catch (e) { const m = {}; return { getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; }, key: i => Object.keys(m)[i], get length() { return Object.keys(m).length; }, _mem: true }; } };
const LS = mkStore('localStorage'), SS = mkStore('sessionStorage');
OB.LS = LS; OB.SS = SS; OB.persistent = !LS._mem;
const lsKeys = () => { const out = []; for (let i = 0; i < LS.length; i++) out.push(LS.key(i)); return out; };
const readJSON = k => { try { return JSON.parse(LS.getItem(k) || 'null'); } catch (e) { return null; } };
const writeJSON = (k, v) => { try { LS.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };
let G = readJSON(GKEY);
if (!G) { // first run, or migrate the earlier single-user format
  G = GLOBAL_DEFAULT(); const old = readJSON(OLDKEY);
  if (old) { Object.assign(G.settings, old.settings || {}); Object.assign(G.custom, old.custom || {}); const d = Object.assign(DATA_DEFAULT(), old); SHARED.forEach(k => delete d[k]); writeJSON(DKEY(null), d); }
}
G = Object.assign(GLOBAL_DEFAULT(), G); G.settings = Object.assign(SETTINGS_DEFAULT(), G.settings); G.custom = Object.assign(GLOBAL_DEFAULT().custom, G.custom);
if (G.admin && !G.admin.it) G.admin = null; // old passcode format no longer used
const sessionUser = () => { const id = G.session && G.session.uid; const u = id && G.users.find(x => x.id === id); return u && u.status !== 'blocked' ? u : null; };
if (G.session && !sessionUser()) G.session = null;
function loadData(uid) { const d = Object.assign(DATA_DEFAULT(), readJSON(DKEY(uid)) || {}); SHARED.forEach(k => d[k] = G[k]); return d; }
let STATE = loadData(G.session && G.session.uid);
let saveT = null;
const store = {
  get s() { return STATE; },
  get g() { return G; },
  save(now) {
    clearTimeout(saveT);
    const doit = () => {
      SHARED.forEach(k => G[k] = STATE[k]);
      const d = {}; Object.keys(STATE).forEach(k => { if (!SHARED.includes(k)) d[k] = STATE[k]; });
      if (!writeJSON(GKEY, G) || !writeJSON(DKEY(G.session && G.session.uid), d)) toast('Could not save — browser storage may be full or blocked.', 'bad');
    };
    if (now) doit(); else saveT = setTimeout(doit, 150);
  },
  logActivity(n = 1) { const d = today(); STATE.activity[d] = (STATE.activity[d] || 0) + n; store.save(); },
  addAttempt(a) { a.id = uid(); a.date = new Date().toISOString(); STATE.attempts.unshift(a); store.logActivity(); store.save(true); return a; },
  switchUser(id) { store.save(true); G.session = id ? { uid: id, at: new Date().toISOString() } : null; STATE = loadData(id); store.save(true); },
  readUser(id) { return Object.assign(DATA_DEFAULT(), readJSON(DKEY(id)) || {}); },
  writeUser(id, d) { const c = {}; Object.keys(d).forEach(k => { if (!SHARED.includes(k)) c[k] = d[k]; }); writeJSON(DKEY(id), c); },
  deleteUser(id) { try { LS.removeItem(DKEY(id)); } catch (e) { } },
  reset() { const keep = {}; SHARED.forEach(k => keep[k] = STATE[k]); STATE = Object.assign(DATA_DEFAULT(), keep); store.save(true); },
  exportAll() { const d = {}; Object.keys(STATE).forEach(k => { if (!SHARED.includes(k)) d[k] = STATE[k]; }); return JSON.stringify({ openband: 2, data: d }, null, 2); },
  importAll(json) { const p = JSON.parse(json); const d = p && p.openband ? p.data : p; if (!d || !Array.isArray(d.attempts)) throw new Error('Not a backup'); SHARED.forEach(k => delete d[k]); const keep = {}; SHARED.forEach(k => keep[k] = STATE[k]); STATE = Object.assign(DATA_DEFAULT(), d, keep); store.save(true); },
  wipeEverything() { lsKeys().filter(k => k && k.startsWith('openband:')).forEach(k => LS.removeItem(k)); }
};
window.addEventListener('beforeunload', () => store.save(true));
OB.store = store;

/* ---------- Accounts (students) ----------
   Passwords are never stored: only a salted PBKDF2-SHA256 hash. Login details are kept per device in
   this demo; connect the online database (README) to share accounts across devices. */
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
/* Pure-JS PBKDF2-HMAC-SHA256 fallback (used only where crypto.subtle is unavailable). */
const SHA_K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
const SHA_IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
const SHA_W = new Int32Array(64);
function shaBlock(H, bytes, off) {
  const W = SHA_W; for (let i = 0; i < 16; i++) { const j = off + i * 4; W[i] = (bytes[j] << 24) | (bytes[j + 1] << 16) | (bytes[j + 2] << 8) | bytes[j + 3]; }
  for (let i = 16; i < 64; i++) { const a = W[i - 15], b = W[i - 2]; W[i] = (W[i - 16] + (((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3)) + W[i - 7] + (((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10))) | 0; }
  let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
  for (let i = 0; i < 64; i++) { const t1 = (h + (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + SHA_K[i] + W[i]) | 0; const t2 = ((((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c))) | 0; h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0; }
  H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0; H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
}
// hash `msg` continuing from state H0 that has already absorbed `prefixLen` bytes (multiple of 64)
function shaFinish(H0, msg, prefixLen) {
  const H = H0.slice(); const total = prefixLen + msg.length; const n = Math.ceil((msg.length + 9) / 64) * 64;
  const buf = new Uint8Array(n); buf.set(msg); buf[msg.length] = 0x80; const bits = total * 8;
  buf[n - 4] = (bits >>> 24) & 255; buf[n - 3] = (bits >>> 16) & 255; buf[n - 2] = (bits >>> 8) & 255; buf[n - 1] = bits & 255; buf[n - 5] = Math.floor(bits / 4294967296) & 255;
  for (let o = 0; o < n; o += 64) shaBlock(H, buf, o);
  const out = new Uint8Array(32); for (let i = 0; i < 8; i++) { out[i * 4] = H[i] >>> 24; out[i * 4 + 1] = (H[i] >>> 16) & 255; out[i * 4 + 2] = (H[i] >>> 8) & 255; out[i * 4 + 3] = H[i] & 255; } return out;
}
function pbkdf2Fallback(pass, salt, it) {
  const enc = new TextEncoder(); let key = enc.encode(pass); if (key.length > 64) key = shaFinish(SHA_IV, key, 0);
  const ip = new Uint8Array(64), op = new Uint8Array(64); for (let i = 0; i < 64; i++) { ip[i] = (key[i] || 0) ^ 0x36; op[i] = (key[i] || 0) ^ 0x5c; }
  const IS = SHA_IV.slice(), OS = SHA_IV.slice(); shaBlock(IS, ip, 0); shaBlock(OS, op, 0);
  const s = enc.encode(salt); const first = new Uint8Array(s.length + 4); first.set(s); first[s.length + 3] = 1;
  let U = shaFinish(OS, shaFinish(IS, first, 64), 64); const T = U.slice();
  for (let k = 1; k < it; k++) { U = shaFinish(OS, shaFinish(IS, U, 64), 64); for (let i = 0; i < 32; i++) T[i] ^= U[i]; }
  return [...T].map(x => x.toString(16).padStart(2, '0')).join('');
}
async function pbkdf2(pass, salt, it = 120000) {
  try {
    if (window.crypto && crypto.subtle) {
      const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveBits']);
      return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(salt), iterations: it, hash: 'SHA-256' }, k, 256));
    }
  } catch (e) { }
  await new Promise(r => setTimeout(r, 20)); // let the UI paint a spinner first
  return pbkdf2Fallback(pass, salt, it);
}
const randHex = n => { const a = new Uint8Array(n); try { crypto.getRandomValues(a); } catch (e) { for (let i = 0; i < n; i++) a[i] = Math.floor(Math.random() * 256); } return hex(a); };
function deviceInfo() {
  const ua = navigator.userAgent;
  const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /SamsungBrowser/.test(ua) ? 'Samsung Internet' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad|iPod/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac OS X/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : 'Unknown OS';
  return { browser, os, mobile: /Mobi|Android|iPhone/.test(ua), screen: `${screen.width}×${screen.height}`, lang: navigator.language || '' };
}
const normLogin = s => String(s || '').trim().toLowerCase().replace(/[\s-]/g, '');
const auth = {
  me: () => sessionUser(),
  users: () => G.users,
  find: q => { const n = normLogin(q); return n ? G.users.find(u => [u.email, u.phone, u.roll].some(v => v && normLogin(v) === n)) : null; },
  logEvent(u, kind, method) { u.logins = u.logins || []; u.logins.unshift(Object.assign({ at: new Date().toISOString(), kind, method }, deviceInfo())); u.logins = u.logins.slice(0, 60); if (kind !== 'failed') { u.lastLogin = u.logins[0].at; u.loginCount = (u.loginCount || 0) + 1; } },
  async register(f, keepGuest) {
    if (!G.settings.allowRegister) throw new Error('New registrations are currently closed.');
    const errs = {};
    if (!f.name || f.name.trim().length < 2) errs.name = 'Please enter your full name.';
    if (!f.email && !f.phone) errs.email = 'Enter an email address or a phone number.';
    if (f.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) errs.email = 'Please enter a valid email address.';
    if (f.phone && !/^\+?[0-9\s-]{8,16}$/.test(f.phone)) errs.phone = 'Please enter a valid phone number.';
    if (!f.password || f.password.length < 6) errs.password = 'Password must be at least 6 characters.';
    if (f.password !== f.password2) errs.password2 = 'Passwords do not match.';
    ['email', 'phone', 'roll'].forEach(k => { if (f[k] && auth.find(f[k])) errs[k] = 'An account with this ' + (k === 'roll' ? 'roll / student ID' : k) + ' already exists.'; });
    if (Object.keys(errs).length) { const e = new Error('Please fix the highlighted fields.'); e.fields = errs; throw e; }
    const salt = randHex(16);
    const u = { id: 'u' + uid(), name: f.name.trim(), roll: (f.roll || '').trim(), email: (f.email || '').trim().toLowerCase(), phone: (f.phone || '').trim(), institution: (f.institution || '').trim(), country: (f.country || '').trim(), target: +f.target || 6.5, type: f.type === 'general' ? 'general' : 'academic', examDate: f.examDate || '', created: new Date().toISOString(), salt, hash: await pbkdf2(f.password, salt), status: 'active', note: '', logins: [] };
    auth.logEvent(u, 'register', f.email ? 'email' : 'phone'); G.users.push(u);
    const guest = keepGuest ? readJSON(DKEY(null)) : null;
    if (guest) { writeJSON(DKEY(u.id), guest); try { LS.removeItem(DKEY(null)); } catch (e) { } }
    store.switchUser(u.id); return u;
  },
  async login(id, pass) {
    const lk = readJSON('openband:loginlock') || { n: 0, until: 0 };
    if (Date.now() < lk.until) throw new Error('Too many attempts. Please wait a minute and try again.');
    const u = auth.find(id); let ok = false;
    if (u) ok = (await pbkdf2(pass, u.salt)) === u.hash; else await pbkdf2(pass, 'x'); // same timing either way
    if (!ok) { lk.n++; if (lk.n >= 5) { lk.until = Date.now() + 60000; lk.n = 0; } writeJSON('openband:loginlock', lk); if (u) { auth.logEvent(u, 'failed', 'password'); store.save(true); } throw new Error('Incorrect login details.'); }
    writeJSON('openband:loginlock', { n: 0, until: 0 });
    if (u.status === 'blocked') throw new Error('This account has been disabled. Please contact the administrator.');
    const n = normLogin(id); auth.logEvent(u, 'login', u.email && normLogin(u.email) === n ? 'email' : u.phone && normLogin(u.phone) === n ? 'phone' : 'roll');
    store.switchUser(u.id); return u;
  },
  logout() { store.switchUser(null); },
  async changePassword(u, oldP, newP) { if ((await pbkdf2(oldP, u.salt)) !== u.hash) throw new Error('Current password is incorrect.'); if (!newP || newP.length < 6) throw new Error('New password must be at least 6 characters.'); u.salt = randHex(16); u.hash = await pbkdf2(newP, u.salt); store.save(true); },
  async setPassword(u, newP) { u.salt = randHex(16); u.hash = await pbkdf2(newP, u.salt); store.save(true); },
  pbkdf2, randHex, deviceInfo
};
OB.auth = auth;
OB.me = () => sessionUser();

/* Admin credential: PBKDF2-SHA256 hash only (the password itself is not in the source). */
const ADMIN_DEFAULT = { salt: 'eca9711cd3c7cb12dd3c22f71d9aaf70', h: 'c8eed0c40071e7e22e7a12fb3e3b56f6ed7baf19dd4bd2b22fb4f537894b9427', it: 310000 };
OB.adminCred = () => (G.admin && G.admin.it) ? G.admin : ADMIN_DEFAULT;

/* Save a generated file: platform download capability when hosted on claude.ai, a normal download elsewhere. */
OB.saveFile = async function (filename, data, mime = 'application/octet-stream') {
  try {
    if (window.claude && typeof window.claude.use === 'function' && window.self !== window.top) {
      const dl = await Promise.race([window.claude.use('downloads'), new Promise(r => setTimeout(() => r(null), 4000))]);
      if (dl) { try { await dl.save({ filename, data }); toast('Saved: ' + filename, 'ok'); } catch (e) { if (e && e.code !== 'declined') toast('This file could not be saved here.', 'bad'); } return; }
      toast('Downloads are not available in this preview. Open the standalone file to save.', 'bad'); return;
    }
  } catch (e) { }
  const blob = data instanceof Blob ? data : new Blob([data], { type: mime });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
};

/* IndexedDB for audio blobs (speaking recordings, admin-uploaded listening audio) */
const idb = {
  _db: null,
  open() {
    if (this._db) return Promise.resolve(this._db);
    return new Promise((res, rej) => {
      if (!window.indexedDB) return rej(new Error('IndexedDB unavailable'));
      const r = indexedDB.open('openband', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('blobs');
      r.onsuccess = () => { this._db = r.result; res(r.result); };
      r.onerror = () => rej(r.error);
    });
  },
  async put(k, v) { const db = await this.open(); return new Promise((res, rej) => { const t = db.transaction('blobs', 'readwrite'); t.objectStore('blobs').put(v, k); t.oncomplete = res; t.onerror = () => rej(t.error); }); },
  async get(k) { const db = await this.open(); return new Promise((res, rej) => { const t = db.transaction('blobs'); const q = t.objectStore('blobs').get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); },
  async del(k) { const db = await this.open(); return new Promise(res => { const t = db.transaction('blobs', 'readwrite'); t.objectStore('blobs').delete(k); t.oncomplete = res; }); }
};
OB.idb = idb;

/* ---------- i18n: see i18n.js (OB.BN dictionary + DOM translator) ---------- */
const t = s => (STATE.settings.lang === 'bn' && OB.BN && OB.BN[s]) ? OB.BN[s] : s;
OB.t = t;
OB.locale = () => STATE.settings.lang === 'bn' ? 'bn-BD' : undefined;

/* ---------- Toast + modal ---------- */
function toast(msg, kind = '') {
  let box = $('.toasts'); if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
  const el = document.createElement('div'); el.className = 'toast ' + kind; el.textContent = msg; box.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}
function modal(html, { wide = false, onClose } = {}) {
  const m = document.createElement('div'); m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
  m.innerHTML = `<div class="scrim"></div><div class="box ${wide ? 'wide' : ''}">${html}</div>`;
  document.body.appendChild(m);
  const close = () => { m.remove(); document.removeEventListener('keydown', key); onClose && onClose(); };
  const key = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', key);
  m.querySelector('.scrim').onclick = close;
  on(m, 'click', '[data-close]', close);
  const f = m.querySelector('input,button,textarea,select'); f && setTimeout(() => f.focus(), 30);
  return { el: m, close };
}
function confirmBox(title, body, okLabel = 'Confirm', danger = false) {
  return new Promise(res => {
    const m = modal(`<h3>${esc(title)}</h3><div class="muted" style="margin-bottom:18px">${body}</div><div class="row end"><button class="btn btn-ghost" data-no>Cancel</button><button class="btn ${danger ? 'btn-coral' : 'btn-primary'}" data-yes>${esc(okLabel)}</button></div>`, { onClose: () => res(false) });
    m.el.querySelector('[data-no]').onclick = () => { m.close(); };
    m.el.querySelector('[data-yes]').onclick = () => { res(true); m.el.remove(); };
  });
}
Object.assign(OB, { toast, modal, confirmBox });

/* ---------- Band score conversion (configurable — admin can override) ---------- */
// Widely published raw-score → band tables (IELTS guide for teachers). Exact cut-offs vary by test version.
const BAND_TABLES = {
  listening: [[39, 9], [37, 8.5], [35, 8], [32, 7.5], [30, 7], [26, 6.5], [23, 6], [18, 5.5], [16, 5], [13, 4.5], [10, 4], [8, 3.5], [6, 3], [4, 2.5], [2, 2], [1, 1], [0, 0]],
  academic: [[39, 9], [37, 8.5], [35, 8], [33, 7.5], [30, 7], [27, 6.5], [23, 6], [19, 5.5], [15, 5], [13, 4.5], [10, 4], [8, 3.5], [6, 3], [4, 2.5], [2, 2], [1, 1], [0, 0]],
  general: [[40, 9], [39, 8.5], [37, 8], [36, 7.5], [34, 7], [32, 6.5], [30, 6], [27, 5.5], [23, 5], [19, 4.5], [15, 4], [12, 3.5], [9, 3], [6, 2.5], [3, 2], [1, 1], [0, 0]]
};
function tableFor(kind) { const c = STATE.settings.bandTables && STATE.settings.bandTables[kind]; return Array.isArray(c) && c.length ? c : BAND_TABLES[kind]; }
function rawToBand(raw, kind, total = 40) {
  const scaled = total === 40 ? raw : Math.round(raw / total * 40);
  for (const [min, b] of tableFor(kind)) if (scaled >= min) return b;
  return 0;
}
function overallBand(arr) {
  const v = arr.filter(x => typeof x === 'number' && !isNaN(x)); if (!v.length) return null;
  const avg = v.reduce((a, b) => a + b, 0) / v.length; const f = Math.floor(avg), r = avg - f;
  return r < 0.25 ? f : r < 0.75 ? f + 0.5 : f + 1;
}
const bandLabel = b => b == null ? '–' : (Number.isInteger(b) ? b.toFixed(1) : String(b));
Object.assign(OB, { BAND_TABLES, rawToBand, overallBand, bandLabel, tableFor });

/* ---------- Answer marking ---------- */
const norm = s => String(s ?? '').toLowerCase().replace(/[’']/g, "'").replace(/[.,;:!?"()]/g, ' ').replace(/\s+/g, ' ').trim();
function isCorrect(given, accepted) {
  const g = norm(given); if (!g) return false;
  const list = Array.isArray(accepted) ? accepted : [accepted];
  return list.some(a => {
    const n = norm(a); if (g === n) return true;
    // numbers: allow "8" vs "eight" not handled; allow optional words in (brackets)
    if (/\(.+\)/.test(a)) { const full = norm(a.replace(/[()]/g, '')), short = norm(a.replace(/\(.+?\)/g, '')); return g === full || g === short; }
    return false;
  });
}
OB.norm = norm; OB.isCorrect = isCorrect;

/* ---------- Speech synthesis "audio" engine ----------
   Original listening scripts are voiced by the browser's built-in text-to-speech, so every test
   has playable audio with no copyrighted recordings. Admin-uploaded audio files use FilePlayer. */
const TTS = {
  ok: 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window,
  voices: [],
  load() { if (!this.ok) return; const v = speechSynthesis.getVoices(); if (v.length) this.voices = v; },
  pickVoice(kind) {
    this.load(); const en = this.voices.filter(v => /^en/i.test(v.lang)); if (!en.length) return null;
    const gb = en.filter(v => /GB|AU|IE|NZ/i.test(v.lang)); const pool = gb.length ? gb : en;
    const fem = /female|libby|sonia|hazel|susan|serena|kate|karen|moira|tessa|fiona|zira|aria|jenny|natasha|samantha|victoria/i;
    const mal = /\bmale|ryan|george|daniel|arthur|oliver|thomas|guy|david|mark|james|william|alex|fred/i;
    if (kind === 'm') return pool.find(v => mal.test(v.name) && !/female/i.test(v.name)) || en.find(v => mal.test(v.name) && !/female/i.test(v.name)) || pool[1] || pool[0];
    if (kind === 'f') return pool.find(v => fem.test(v.name)) || en.find(v => fem.test(v.name)) || pool[0];
    return pool[0];
  },
  speak(text, { rate = 1, voice = 'f', onend } = {}) {
    if (!this.ok) { onend && onend(); return; }
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text); const v = this.pickVoice(voice); if (v) u.voice = v;
    u.lang = v ? v.lang : 'en-GB'; u.rate = rate; u.pitch = voice === 'm' ? .9 : 1.05; u.onend = () => onend && onend(); u.onerror = () => onend && onend();
    speechSynthesis.speak(u);
  },
  stop() { if (this.ok) speechSynthesis.cancel(); }
};
if (TTS.ok) { TTS.load(); speechSynthesis.onvoiceschanged = () => TTS.load(); }
OB.TTS = TTS;

class ScriptPlayer {
  // lines: [{s:speaker, v:'f'|'m'|'n', t:text}]
  constructor(lines, { onTick, onLine, onEnd, rate = 1 } = {}) {
    this.lines = lines; this.i = 0; this.playing = false; this.rate = rate; this.onTick = onTick; this.onLine = onLine; this.onEnd = onEnd;
    this.dur = lines.map(l => Math.max(1.2, l.t.split(/\s+/).length / 2.55 + .5)); this.total = this.dur.reduce((a, b) => a + b, 0);
    this.lineStart = 0; this.token = 0;
  }
  elapsed() { let e = 0; for (let k = 0; k < this.i && k < this.lines.length; k++) e += this.dur[k]; if (this.playing) e += Math.min(this.dur[this.i] || 0, (Date.now() - this.lineStart) / 1000 * this.rate); return e / this.rate; }
  totalTime() { return this.total / this.rate; }
  play() {
    if (!TTS.ok) return false;
    if (this.i >= this.lines.length) this.i = 0;
    this.playing = true; this._tick(); this._say(); return true;
  }
  _tick() { clearInterval(this.tm); this.tm = setInterval(() => this.onTick && this.onTick(this.elapsed(), this.totalTime(), this.i), 250); }
  _say() {
    const tok = ++this.token; const line = this.lines[this.i];
    if (!line) { this.playing = false; clearInterval(this.tm); this.onTick && this.onTick(this.totalTime(), this.totalTime(), this.i); this.onEnd && this.onEnd(); return; }
    this.onLine && this.onLine(this.i); this.lineStart = Date.now();
    // split long lines into sentences (Chrome stops very long utterances)
    const parts = line.t.match(/[^.!?]+[.!?]*\s*/g) || [line.t]; let p = 0;
    const next = () => {
      if (tok !== this.token || !this.playing) return;
      if (p >= parts.length) { this.i++; setTimeout(() => { if (tok === this.token && this.playing) this._say(); }, line.pause ? line.pause * 1000 : 380); return; }
      const txt = parts[p++].trim(); if (!txt) return next();
      TTS.speak(txt, { rate: this.rate, voice: line.v || 'f', onend: next });
    };
    next();
  }
  pause() { this.playing = false; this.token++; clearInterval(this.tm); TTS.stop(); this.onTick && this.onTick(this.elapsed(), this.totalTime(), this.i); }
  seek(i) { const was = this.playing; this.pause(); this.i = clamp(i, 0, this.lines.length - 1); this.onLine && this.onLine(this.i); this.onTick && this.onTick(this.elapsed(), this.totalTime(), this.i); if (was) this.play(); }
  setRate(r) { const was = this.playing; this.pause(); this.rate = r; if (was) this.play(); }
  destroy() { this.pause(); this.onTick = this.onLine = this.onEnd = null; }
}
class FilePlayer {
  constructor(url, { onTick, onEnd } = {}) {
    this.a = new Audio(url); this.onTick = onTick; this.onEnd = onEnd; this.playing = false;
    this.a.ontimeupdate = () => this.onTick && this.onTick(this.a.currentTime, this.a.duration || 0, 0);
    this.a.onended = () => { this.playing = false; this.onEnd && this.onEnd(); };
  }
  play() { this.a.play(); this.playing = true; return true; } pause() { this.a.pause(); this.playing = false; }
  seekFrac(f) { if (this.a.duration) this.a.currentTime = f * this.a.duration; }
  setRate(r) { this.a.playbackRate = r; } totalTime() { return this.a.duration || 0; } elapsed() { return this.a.currentTime; }
  destroy() { this.a.pause(); this.onTick = this.onEnd = null; }
}
OB.ScriptPlayer = ScriptPlayer; OB.FilePlayer = FilePlayer;

/* ---------- Countdown timer ---------- */
class Countdown {
  constructor(seconds, { onTick, onEnd, startElapsed = 0 } = {}) { this.total = seconds; this.elapsed = startElapsed; this.onTick = onTick; this.onEnd = onEnd; }
  start() { this.stop(); this.last = Date.now(); this.t = setInterval(() => { const n = Date.now(); this.elapsed += (n - this.last) / 1000; this.last = n; const left = this.total - this.elapsed; this.onTick && this.onTick(left, this.elapsed); if (left <= 0) { this.stop(); this.onEnd && this.onEnd(); } }, 500); this.onTick && this.onTick(this.total - this.elapsed, this.elapsed); }
  stop() { clearInterval(this.t); }
}
OB.Countdown = Countdown;

/* ---------- Router ---------- */
const routes = [];
let cleanup = [];
OB.route = (pattern, fn) => routes.push({ re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });
OB.onLeave = fn => cleanup.push(fn);
/* Routing is kept in memory (CUR) and links are intercepted, so navigation works everywhere —
   including sandboxed previews (about:srcdoc) where changing location.hash would blank the page.
   The address bar is updated only where the browser allows it, for back/forward support. */
const canHash = /^(https?|file):$/.test(location.protocol);
let CUR = (canHash && location.hash.startsWith('#/')) ? location.hash : '#/';
OB.loc = () => CUR;
OB.go = h => {
  if (!h || h === '#') h = '#/'; if (!h.startsWith('#/')) h = '#/' + h.replace(/^#?\/?/, '');
  CUR = h;
  if (canHash && location.hash !== h) { try { history.pushState(null, '', h); } catch (e) { } }
  OB.render();
};
OB.render = () => {
  cleanup.forEach(f => { try { f(); } catch (e) { } }); cleanup = []; TTS.stop();
  const path = (CUR.replace(/^#/, '') || '/').split('?')[0] || '/';
  for (const r of routes) { const m = path.match(r.re); if (m) { try { r.fn(m.groups || {}); } catch (e) { console.error(e); OB.renderError(e); } return; } }
  OB.notFound();
};
const fromAddress = () => { if (canHash && location.hash.startsWith('#/') && location.hash !== CUR) { CUR = location.hash; OB.render(); } };
window.addEventListener('hashchange', fromAddress);
window.addEventListener('popstate', fromAddress);
document.addEventListener('click', e => {
  if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  const a = e.target.closest && e.target.closest('a[href^="#"]'); if (!a || a.target || a.hasAttribute('download')) return;
  const h = a.getAttribute('href');
  if (h.startsWith('#/')) { e.preventDefault(); OB.go(h); }
  else if (h.length > 1) { e.preventDefault(); const t = document.getElementById(h.slice(1)); if (t) { t.scrollIntoView({ behavior: 'smooth', block: 'start' }); if (t.tabIndex < 0 && !/^(A|BUTTON|INPUT|SELECT|TEXTAREA)$/.test(t.tagName)) t.setAttribute('tabindex', '-1'); t.focus({ preventScroll: true }); } }
  else e.preventDefault();
});
OB.query = () => Object.fromEntries(new URLSearchParams(CUR.split('?')[1] || ''));
