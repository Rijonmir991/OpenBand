/* OpenBand — Speaking module: Part 1/2/3 practice, mock interview, recorder, recordings history */
(function () {
  const { $, $$, esc, on, icon, store, toast, modal, confirmBox, fmtTime, TTS, idb, uid, pick, overallBand, bandLabel } = OB;
  OB.allCards = () => [...window.SPEAKING.cards, ...store.s.custom.speaking.filter(s => s.type === 'card')];
  OB.allP1 = () => [...window.SPEAKING.part1, ...store.s.custom.speaking.filter(s => s.type === 'p1')];

  /* ---------- recorder ---------- */
  const Rec = {
    mr: null, stream: null, chunks: [], t0: 0, rec: null, transcript: '',
    supported: () => !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder),
    async start(withTranscript) {
      if (!this.supported()) throw new Error('Recording is not supported in this browser.');
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.chunks = []; this.mr = new MediaRecorder(this.stream);
      this.mr.ondataavailable = e => e.data.size && this.chunks.push(e.data); this.mr.start(); this.t0 = Date.now(); this.transcript = '';
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (withTranscript && SR) { try { this.rec = new SR(); this.rec.lang = 'en-GB'; this.rec.continuous = true; this.rec.interimResults = false; this.rec.onresult = e => { for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) this.transcript += e.results[i][0].transcript + ' '; }; this.rec.onerror = () => { }; this.rec.start(); } catch (e) { this.rec = null; } }
    },
    stop() {
      return new Promise(res => {
        if (!this.mr) return res(null);
        const dur = (Date.now() - this.t0) / 1000;
        this.mr.onstop = () => { const blob = new Blob(this.chunks, { type: this.mr.mimeType || 'audio/webm' }); this.stream.getTracks().forEach(t => t.stop()); this.mr = null; setTimeout(() => res({ blob, dur, transcript: this.transcript.trim() }), this.rec ? 600 : 0); try { this.rec && this.rec.stop(); } catch (e) { } this.rec = null; };
        this.mr.stop();
      });
    },
    get on() { return !!this.mr; }
  };
  OB.Rec = Rec;
  async function saveRec(r, meta) {
    const id = uid(); try { await idb.put('rec:' + id, r.blob); } catch (e) { toast('Could not store audio in this browser; playback available this session only.', 'bad'); }
    const m = Object.assign({ id, dur: Math.round(r.dur), date: new Date().toISOString(), transcript: r.transcript || '' }, meta);
    store.s.speaking.unshift(m); store.logActivity(); store.save(true); m._url = URL.createObjectURL(r.blob); return m;
  }
  function fluency(m) {
    if (!m.transcript) return '';
    const w = m.transcript.split(/\s+/).filter(Boolean); const wpm = Math.round(w.length / Math.max(1, m.dur) * 60);
    const fill = (m.transcript.toLowerCase().match(/\b(um|uh|er|erm|ah|like|you know|actually|basically)\b/g) || []).length;
    return `<div class="tiny muted" style="margin-top:4px">Practice indicators (not a score): ~${wpm} words/min · ${fill} filler word${fill === 1 ? '' : 's'} · transcript: “${esc(m.transcript.slice(0, 160))}${m.transcript.length > 160 ? '…' : ''}”</div>`;
  }
  async function recItemHTML(m) {
    let url = m._url; if (!url) { try { const b = await idb.get('rec:' + m.id); if (b) url = URL.createObjectURL(b); } catch (e) { } }
    return `<div class="rec-item" data-rec="${m.id}"><div style="flex:1;min-width:200px"><b class="small">${esc(m.label || 'Recording')}</b><div class="tiny muted">Part ${m.part} · ${fmtTime(m.dur)} · ${OB.fmtDate(m.date)}</div>${fluency(m)}</div>${url ? `<audio controls src="${url}" preload="metadata"></audio>` : '<span class="tiny muted">Audio unavailable</span>'}<button class="icon-btn" data-delrec="${m.id}" aria-label="Delete recording">${icon('trash', 16)}</button></div>`;
  }
  OB.recItemHTML = recItemHTML;
  async function deleteRec(id) { store.s.speaking = store.s.speaking.filter(r => r.id !== id); store.save(true); try { await idb.del('rec:' + id); } catch (e) { } }

  // A record button with live timer. opts: {limit, label, part, onSaved, autoStart}
  function recorderWidget(box, opts) {
    let tm, el = 0;
    const transcriptOk = !!(window.SpeechRecognition || window.webkitSpeechRecognition);
    box.innerHTML = `<div class="row"><button class="btn btn-coral" data-rec-btn>${icon('S', 16)} Record answer</button><span class="small muted" data-rec-t></span>
      ${transcriptOk ? `<label class="tiny muted row" style="gap:5px"><input type="checkbox" data-tr ${store.s.settings.liveTranscript ? 'checked' : ''}> Live transcript (uses your browser's speech service)</label>` : ''}</div><div data-rec-list style="margin-top:8px"></div>`;
    const btn = $('[data-rec-btn]', box), t = $('[data-rec-t]', box), tr = $('[data-tr]', box);
    if (tr) tr.onchange = () => { store.s.settings.liveTranscript = tr.checked; store.save(); };
    const stop = async () => {
      clearInterval(tm); btn.disabled = true; const r = await Rec.stop(); btn.disabled = false; btn.innerHTML = `${icon('S', 16)} Record again`; btn.classList.add('btn-coral'); btn.classList.remove('btn-ghost'); t.textContent = '';
      if (!r || r.dur < .8) return toast('Recording too short.');
      const m = await saveRec(r, { part: opts.part, label: opts.label() }); $('[data-rec-list]', box).insertAdjacentHTML('afterbegin', await recItemHTML(m)); opts.onSaved && opts.onSaved(m);
    };
    const start = async () => {
      TTS.stop();
      try { await Rec.start(tr && tr.checked); } catch (e) { return modal(`<h3>Microphone not available</h3><p class="muted">${esc(e.name === 'NotAllowedError' ? 'Microphone permission was blocked. Allow microphone access for this site in your browser settings (the icon next to the address bar), then try again.' : (e.message || 'This browser cannot record audio.'))}</p>${window.self !== window.top ? '<p class="small"><b>Viewing inside an embedded preview?</b> Some previews block the microphone. Open the standalone OpenBand file (index.html) in Chrome or Edge, or deploy it to your own HTTPS site, to record.</p>' : ''}<p class="small muted">You can still practise: speak your answer aloud while the timer runs, then use the self-assessment checklist.</p><div class="row end"><button class="btn btn-primary" data-close>OK</button></div>`); }
      el = 0; btn.innerHTML = `<span class="rec-dot"></span> Stop recording`; btn.classList.remove('btn-coral'); btn.classList.add('btn-ghost');
      tm = setInterval(() => { el++; t.textContent = `${fmtTime(el)}${opts.limit ? ' / ' + fmtTime(opts.limit) : ''}`; if (opts.limit && el >= opts.limit) stop(); }, 1000);
    };
    btn.onclick = () => Rec.on ? stop() : start();
    OB.onLeave(() => { clearInterval(tm); if (Rec.on) Rec.stop(); });
    if (opts.autoStart) start();
    return { start, stop };
  }

  const examinerHTML = q => `<div class="examiner"><div class="av">EX</div><div class="bubble">${esc(q)}<div style="margin-top:8px"><button class="btn btn-sm btn-ghost" data-say>${icon('vol', 14)} Hear question</button></div></div></div>`;
  const say = q => TTS.ok ? TTS.speak(q, { voice: 'f', rate: .95 }) : toast('Speech playback not supported in this browser.');

  /* ---------- page ---------- */
  OB.route('/speaking', () => {
    const app = OB.page(); const q = OB.query(); let tab = q.tab || 'p1';
    app.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('S', 16)} Speaking</span><h1 style="font-size:2.2rem">IELTS Speaking practice</h1><p>Hear examiner questions, record your answers with your microphone, replay them and assess yourself against the four IELTS criteria. Recordings stay in your browser.</p></div></div>
    <div class="wrap" style="padding-bottom:40px"><div class="side-layout"><nav class="side-nav" data-tabs>${[['p1', 'Part 1 · Interview'], ['p2', 'Part 2 · Cue card'], ['p3', 'Part 3 · Discussion'], ['mock', 'Mock speaking test'], ['cards', 'Cue card library'], ['recs', 'My recordings'], ['self', 'Self-assessment guide']].map(([k, l]) => `<button data-tab="${k}">${l}</button>`).join('')}</nav><div data-pane></div></div></div>`;
    const pane = $('[data-pane]', app);
    on(app, 'click', '[data-say]', (e, b) => say(b.closest('.bubble').firstChild.textContent));
    on(app, 'click', '[data-delrec]', async (e, b) => { if (await confirmBox('Delete recording?', 'This cannot be undone.', 'Delete', true)) { await deleteRec(b.dataset.delrec); b.closest('.rec-item').remove(); } });
    const show = k => { tab = k; $$('[data-tab]', app).forEach(b => b.classList.toggle('on', b.dataset.tab === k)); TTS.stop(); VIEWS[k](pane, q); };
    on(app, 'click', '[data-tab]', (e, b) => show(b.dataset.tab));
    show(tab);
  });

  const VIEWS = {
    p1(pane) {
      const topics = OB.allP1(); let ti = Math.floor(Math.random() * topics.length), qi = 0;
      const draw = () => {
        const tp = topics[ti]; const qq = tp.qs[qi];
        pane.innerHTML = `<div class="card"><div class="row between"><div><span class="chip blue">Part 1</span> <b style="margin-left:6px">${esc(tp.topic)}</b></div><div class="row"><select class="select" style="width:auto;height:38px" data-topic>${topics.map((t, i) => `<option value="${i}" ${i === ti ? 'selected' : ''}>${esc(t.topic)}</option>`).join('')}</select><button class="btn btn-sm btn-ghost" data-rand>${icon('refresh', 14)} Random</button></div></div>
          <p class="small muted" style="margin:10px 0 16px">Part 1 lasts 4–5 minutes. Aim for 2–3 sentences per answer (about 20–30 seconds): answer → reason → example.</p>
          ${examinerHTML(qq)}<div style="margin:18px 0" data-recbox></div>
          <div class="row between"><span class="small muted">Question ${qi + 1} of ${tp.qs.length}</span><div class="row"><button class="btn btn-ghost btn-sm" data-pq ${qi === 0 ? 'disabled' : ''}>${icon('left', 14)} Previous</button><button class="btn btn-primary btn-sm" data-nq>${qi < tp.qs.length - 1 ? 'Next question' : 'New topic'} ${icon('right', 14)}</button></div></div></div>`;
        recorderWidget($('[data-recbox]', pane), { part: 1, limit: 60, label: () => `${tp.topic}: ${qq}` });
        $('[data-topic]', pane).onchange = e => { ti = +e.target.value; qi = 0; draw(); };
        $('[data-rand]', pane).onclick = () => { ti = Math.floor(Math.random() * topics.length); qi = 0; draw(); };
        $('[data-nq]', pane).onclick = () => { if (qi < tp.qs.length - 1) qi++; else { ti = (ti + 1) % topics.length; qi = 0; } draw(); say(topics[ti].qs[qi]); };
        $('[data-pq]', pane).onclick = () => { qi--; draw(); };
      };
      draw();
    },
    p2(pane, q) {
      const cards = OB.allCards(); let card = cards.find(c => c.id === q.card) || pick(cards); let phase = 'idle', cd;
      const stopCd = () => clearInterval(cd); OB.onLeave(stopCd);
      const draw = () => {
        stopCd();
        pane.innerHTML = `<div class="card"><div class="row between" style="margin-bottom:14px"><span class="chip coral">Part 2 · Long turn</span><button class="btn btn-sm btn-ghost" data-new>${icon('refresh', 14)} New cue card</button></div>
          <div class="grid g2" style="align-items:start"><div class="cue"><b style="font-size:1.1rem">${esc(card.title)}</b><div style="margin-top:8px">You should say:</div><ul>${card.bullets.map(b => `<li>${esc(b)}</li>`).join('')}</ul><div>${esc(card.end)}</div></div>
          <div class="center"><div class="small muted" data-phase-l>${phase === 'idle' ? 'Ready when you are' : ''}</div><div class="big-timer" data-big>01:00</div><div class="small muted" style="margin:6px 0 14px" data-phase-sub>1 minute to prepare · 2 minutes to speak</div>
            <div class="row" style="justify-content:center" data-ctrl><button class="btn btn-primary" data-prep>${icon('clock', 16)} Start 1-minute preparation</button><button class="btn btn-ghost" data-skip>Skip to speaking</button></div></div></div>
          <div class="field" style="margin-top:16px"><label class="lbl">Your notes (key words for each point)</label><textarea class="textarea" rows="3" data-notes placeholder="e.g. Who: my uncle Karim · How: lives nearby · What: taught me to ride a bike…"></textarea></div>
          <div data-recbox></div>
          <div class="hr"></div><div class="row between"><span class="small muted">After Part 2, the examiner asks related Part 3 questions.</span><a class="btn btn-sm btn-ghost" href="#/speaking?tab=p3&card=${esc(card.id)}" data-p3>Go to Part 3 for this topic ${icon('arrow', 14)}</a></div></div>`;
        const big = $('[data-big]', pane), lab = $('[data-phase-l]', pane), sub = $('[data-phase-sub]', pane);
        const speak = () => {
          stopCd(); phase = 'speak'; lab.textContent = 'Speak now'; sub.textContent = 'Recording stops automatically at 2:00'; $('[data-ctrl]', pane).innerHTML = '';
          const w = recorderWidget($('[data-recbox]', pane), { part: 2, limit: 120, label: () => card.title, autoStart: true, onSaved: () => { stopCd(); lab.textContent = 'Done — listen back below'; } });
          let left = 120; big.textContent = fmtTime(left); cd = setInterval(() => { left--; big.textContent = fmtTime(Math.max(0, left)); if (left <= 0) stopCd(); }, 1000);
        };
        $('[data-prep]', pane).onclick = () => { phase = 'prep'; lab.textContent = 'Preparation time'; let left = 60; big.textContent = fmtTime(left); $('[data-notes]', pane).focus(); say('You have one minute to prepare. You can make some notes.'); cd = setInterval(() => { left--; big.textContent = fmtTime(left); if (left <= 0) { say('Please start speaking now.'); speak(); } }, 1000); };
        $('[data-skip]', pane).onclick = speak;
        $('[data-new]', pane).onclick = () => { card = pick(cards.filter(c => c.id !== card.id)); phase = 'idle'; draw(); };
        $('[data-p3]', pane).onclick = e => { e.preventDefault(); VIEWS.p3(pane, { card: card.id }); $$('[data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === 'p3')); };
      };
      draw();
    },
    p3(pane, q) {
      const cards = OB.allCards(); let card = cards.find(c => c.id === q.card) || pick(cards);
      const draw = () => {
        pane.innerHTML = `<div class="card"><div class="row between"><span class="chip mint">Part 3 · Discussion</span><select class="select" style="width:auto;max-width:100%;height:38px" data-card>${cards.map(c => `<option value="${c.id}" ${c.id === card.id ? 'selected' : ''}>${esc(c.title.replace('Describe ', ''))}</option>`).join('')}</select></div>
          <p class="small muted" style="margin:10px 0 16px">Part 3 questions are more abstract. Give an opinion, explain it, consider other views and give examples (aim for 40–60 seconds).</p>
          ${(card.p3 || []).map((qq, i) => `<div style="margin-bottom:22px">${examinerHTML(qq)}<div style="margin-top:10px" data-recbox="${i}"></div></div>`).join('')}</div>`;
        $$('[data-recbox]', pane).forEach(b => { const qq = card.p3[+b.dataset.recbox]; recorderWidget(b, { part: 3, limit: 120, label: () => qq }); });
        $('[data-card]', pane).onchange = e => { card = cards.find(c => c.id === e.target.value); draw(); };
      };
      draw();
    },
    cards(pane) {
      const cards = OB.allCards();
      pane.innerHTML = `<div class="row between" style="margin-bottom:14px"><h2 style="margin:0">Cue card library</h2><input class="input" style="max-width:260px" placeholder="Search cue cards…" data-s></div><div class="grid g2" data-g></div>`;
      const draw = s => { $('[data-g]', pane).innerHTML = cards.filter(c => c.title.toLowerCase().includes(s)).map(c => `<div class="card"><b>${esc(c.title)}</b><ul class="small muted" style="padding-left:18px;margin:8px 0">${c.bullets.map(b => `<li>${esc(b)}</li>`).join('')}<li>${esc(c.end)}</li></ul><div class="row"><a class="btn btn-sm btn-primary" href="#/speaking?tab=p2&card=${c.id}" data-open="${c.id}">Practise Part 2</a><a class="btn btn-sm btn-ghost" href="#/speaking?tab=p3&card=${c.id}">Part 3 questions</a></div></div>`).join('') || '<div class="empty">No matching cue cards.</div>'; };
      $('[data-s]', pane).oninput = e => draw(e.target.value.toLowerCase()); draw('');
    },
    async recs(pane) {
      const list = store.s.speaking;
      pane.innerHTML = `<div class="card"><div class="row between"><h3 style="margin:0">My recordings (${list.length})</h3>${list.length ? '<button class="btn btn-sm btn-danger" data-clearall>Delete all</button>' : ''}</div><p class="small muted">Recordings are stored only in this browser (IndexedDB). They are not uploaded anywhere.</p><div data-l>${list.length ? '<div class="loader"></div>' : `<div class="empty"><div class="ico">${icon('S', 28)}</div>No recordings yet. Try Part 1 or a cue card.</div>`}</div></div>`;
      if (list.length) $('[data-l]', pane).innerHTML = (await Promise.all(list.map(recItemHTML))).join('');
      const c = $('[data-clearall]', pane); if (c) c.onclick = async () => { if (await confirmBox('Delete all recordings?', 'This permanently removes every recording stored in this browser.', 'Delete all', true)) { for (const r of [...store.s.speaking]) await deleteRec(r.id); VIEWS.recs(pane); } };
    },
    self(pane) { pane.innerHTML = selfAssessHTML(false); bindSelf(pane); },
    mock(pane) { mockSpeaking(pane); }
  };

  /* ---------- self assessment ---------- */
  const SCRIT = [
    ['fc', 'Fluency & Coherence', [[5, 'Frequent pauses and repetition; simple linking.'], [6, 'Willing to speak at length, but some hesitation; linking not always smooth.'], [7, 'Speaks at length without noticeable effort; uses a range of connectives.'], [8, 'Speaks fluently with only occasional hesitation; well-developed ideas.']]],
    ['lr', 'Lexical Resource', [[5, 'Limited vocabulary for familiar topics; paraphrasing is difficult.'], [6, 'Enough vocabulary to discuss topics; some inappropriate choices.'], [7, 'Flexible vocabulary, some less common words and idioms.'], [8, 'Wide, precise vocabulary; uses idioms naturally.']]],
    ['gr', 'Grammatical Range & Accuracy', [[5, 'Mostly basic sentences; frequent errors.'], [6, 'Mix of simple and complex sentences; errors with complex ones.'], [7, 'Range of complex structures; frequent error-free sentences.'], [8, 'Wide range; most sentences error-free.']]],
    ['pr', 'Pronunciation', [[5, 'Sometimes hard to understand.'], [6, 'Generally understood; some mispronunciation.'], [7, 'Easy to understand; some natural intonation and stress.'], [8, 'Easy to understand throughout; natural rhythm and intonation.']]]
  ];
  const CHECK = ['I answered every question directly before adding detail.', 'I extended answers with reasons and examples.', 'I spoke for the full two minutes in Part 2.', 'I used linking words (because, however, for instance).', 'I paraphrased instead of repeating the question\'s words.', 'I used at least two complex sentences per answer in Part 3.', 'I corrected myself naturally when I made mistakes.', 'My word stress and intonation sounded natural on playback.'];
  function selfAssessHTML(forMock) {
    return `<div class="card"><h3>${forMock ? 'Assess your mock speaking test' : 'Self-assessment guide'}</h3>
      <div class="estimate-note" style="margin-bottom:14px">${icon('info')} <div>A browser recording cannot determine an official IELTS Speaking band. Listen to your recordings and choose the description that best matches each criterion. The result is a <b>self-assessed estimate</b>.</div></div>
      <form data-selfform>${SCRIT.map(([k, l, d]) => `<div class="field"><label class="lbl">${l}</label>${d.map(([b, t]) => `<label class="opt" style="margin-bottom:6px"><input type="radio" name="${k}" value="${b}"><span class="small"><b>Band ${b}:</b> ${esc(t)}</span></label>`).join('')}</div>`).join('')}
      <div class="hr"></div><label class="lbl">Practice checklist</label>${CHECK.map((c, i) => `<label class="row small" style="gap:8px;margin:6px 0;flex-wrap:nowrap"><input type="checkbox" name="c${i}"> ${esc(c)}</label>`).join('')}
      <div class="row between" style="margin-top:14px"><div data-sres></div><button class="btn btn-primary" type="submit">${forMock ? 'Save result' : 'Calculate self-assessed band'}</button></div></form></div>`;
  }
  function bindSelf(pane, onSave) {
    const f = $('[data-selfform]', pane);
    f.onsubmit = e => {
      e.preventDefault(); const d = Object.fromEntries(new FormData(f)); const vals = SCRIT.map(([k]) => +d[k]).filter(Boolean);
      if (vals.length < 4) return toast('Choose a band for each of the four criteria.', 'bad');
      const b = overallBand(vals); const checks = CHECK.filter((_, i) => d['c' + i]).length;
      $('[data-sres]', pane).innerHTML = `Self-assessed band: <span class="band-pill">${bandLabel(b)}</span> <span class="small muted">· checklist ${checks}/${CHECK.length}</span>`;
      onSave && onSave(b, d);
    };
  }

  /* ---------- mock speaking test ---------- */
  function mockSpeaking(pane) {
    pane.innerHTML = `<div class="card"><span class="chip">Mock test mode</span><h2 style="margin-top:10px">Speaking mock test (11–14 minutes)</h2><p class="muted">The examiner reads each question aloud. Record your answer, then continue. Part 2 includes 1 minute of preparation and up to 2 minutes of speaking.</p>
      <ul class="small"><li>Part 1: 4 questions on a familiar topic</li><li>Part 2: one cue card</li><li>Part 3: 3 discussion questions</li></ul>
      <div class="estimate-note" style="margin:12px 0">${icon('info')} Allow microphone access when your browser asks. Use headphones for the examiner's voice.</div>
      <button class="btn btn-primary btn-lg" data-go>${icon('play', 16)} Start mock speaking test</button></div>`;
    $('[data-go]', pane).onclick = () => runMock(pane);
  }
  function runMock(pane) {
    const topic = pick(OB.allP1()), card = pick(OB.allCards());
    const steps = [...topic.qs.slice(0, 4).map(q => ({ part: 1, q })), { part: 2, card }, ...(card.p3 || []).slice(0, 3).map(q => ({ part: 3, q }))];
    let i = 0; const recs = [];
    const next = () => {
      if (i >= steps.length) return finish();
      const s = steps[i]; const head = `<div class="row between" style="margin-bottom:14px"><span class="chip ${s.part === 1 ? 'blue' : s.part === 2 ? 'coral' : 'mint'}">Part ${s.part}</span><span class="small muted">Step ${i + 1} of ${steps.length}</span></div><div class="bar" style="margin-bottom:18px"><i style="width:${i / steps.length * 100}%"></i></div>`;
      if (s.part === 2) {
        pane.innerHTML = `<div class="card">${head}<div class="cue"><b>${esc(s.card.title)}</b><div style="margin-top:6px">You should say:</div><ul>${s.card.bullets.map(b => `<li>${esc(b)}</li>`).join('')}</ul>${esc(s.card.end)}</div>
          <div class="center" style="margin:16px 0"><div class="small muted" data-l>Preparation</div><div class="big-timer" data-big>01:00</div></div><textarea class="textarea" rows="3" placeholder="Notes…"></textarea><div style="margin-top:12px" data-recbox></div><div class="row end" style="margin-top:12px"><button class="btn btn-primary" data-nx disabled>Continue to Part 3 ${icon('right', 14)}</button></div></div>`;
        say('Now I am going to give you a topic. You have one minute to prepare. ' + s.card.title);
        let left = 60; const big = $('[data-big]', pane); const cd = setInterval(() => { left--; big.textContent = fmtTime(Math.max(0, left)); if (left <= 0) { clearInterval(cd); startSpeak(); } }, 1000); OB.onLeave(() => clearInterval(cd));
        const startSpeak = () => {
          $('[data-l]', pane).textContent = 'Speak now (2 minutes)'; let l2 = 120; big.textContent = '02:00'; const c2 = setInterval(() => { l2--; big.textContent = fmtTime(Math.max(0, l2)); if (l2 <= 0) clearInterval(c2); }, 1000); OB.onLeave(() => clearInterval(c2));
          recorderWidget($('[data-recbox]', pane), { part: 2, limit: 120, label: () => 'Mock · ' + s.card.title, autoStart: true, onSaved: m => { clearInterval(c2); recs.push(m); $('[data-nx]', pane).disabled = false; } });
          $('[data-nx]', pane).disabled = false;
        };
        $('[data-recbox]', pane).innerHTML = `<button class="btn btn-ghost btn-sm" data-skipprep>Start speaking now</button>`; $('[data-skipprep]', pane).onclick = () => { clearInterval(cd); startSpeak(); };
      } else {
        pane.innerHTML = `<div class="card">${head}${examinerHTML(s.q)}<div style="margin:16px 0" data-recbox></div><div class="row end"><button class="btn btn-primary" data-nx>${i === steps.length - 1 ? 'Finish test' : 'Next question'} ${icon('right', 14)}</button></div></div>`;
        say((i === 0 ? `Let's talk about ${topic.topic.toLowerCase()}. ` : '') + s.q);
        recorderWidget($('[data-recbox]', pane), { part: s.part, limit: s.part === 1 ? 60 : 120, label: () => 'Mock · ' + s.q, onSaved: m => recs.push(m) });
      }
      $('[data-nx]', pane).onclick = async () => { if (Rec.on) await Rec.stop(); TTS.stop(); i++; next(); };
    };
    const finish = async () => {
      say('That is the end of the speaking test. Thank you.');
      pane.innerHTML = `<div class="card" style="margin-bottom:18px"><h2>Mock test complete</h2><p class="muted">Listen to your answers, then assess yourself honestly.</p><div data-l>${recs.length ? '' : '<p class="small muted">No recordings were saved in this session.</p>'}</div></div>${selfAssessHTML(true)}`;
      if (recs.length) $('[data-l]', pane).innerHTML = (await Promise.all(recs.map(recItemHTML))).join('');
      bindSelf(pane, (b) => { store.addAttempt({ testId: 'speaking-mock', module: 'S', title: 'Speaking mock test (self-assessed)', band: b, mode: 'mock', recs: recs.map(r => r.id) }); toast('Saved to your dashboard.', 'ok'); });
    };
    next();
  }
  OB.speakingSelfHTML = selfAssessHTML; OB.bindSpeakingSelf = bindSelf;
})();
