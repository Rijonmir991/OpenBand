/* OpenBand — Learning centre: vocabulary, flashcards, quizzes, grammar, paraphrasing, connectors, collocations */
(function () {
  const { $, $$, esc, on, icon, store, toast, TTS, shuffle, pick, today } = OB;
  OB.allVocab = () => [...window.VOCAB, ...store.s.custom.vocab];
  const dayHash = d => [...d].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  OB.dailyWords = (n = 5) => { const v = OB.allVocab(); const h = dayHash(today()); const out = []; for (let i = 0; out.length < Math.min(n, v.length); i++) { const w = v[(h + i * 7) % v.length]; if (!out.includes(w)) out.push(w); } return out; };
  const isFav = w => store.s.favWords.includes(w);
  const toggleFav = w => { const f = store.s.favWords; const i = f.indexOf(w); i >= 0 ? f.splice(i, 1) : f.push(w); store.save(); return i < 0; };
  const speak = w => TTS.ok ? TTS.speak(w, { voice: 'f', rate: .9 }) : toast('Pronunciation audio is not supported in this browser.');
  OB.wordCard = w => `<div class="card word-card"><div class="row between"><div><span class="w">${esc(w.w)}</span> <span class="chip">${esc(w.pos)}</span></div><div class="row" style="gap:4px"><button class="icon-btn" style="width:34px;height:34px" data-speak="${esc(w.w)}" aria-label="Pronounce ${esc(w.w)}">${icon('vol', 16)}</button><button class="star ${isFav(w.w) ? 'on' : ''}" data-fav="${esc(w.w)}" aria-label="Save ${esc(w.w)}">★</button></div></div>
    <p style="margin:8px 0 4px">${esc(w.m)}</p>${w.bn ? `<p class="small" style="margin:0 0 6px;color:var(--blue)" lang="bn">বাংলা: ${esc(w.bn)}</p>` : ''}<p class="small muted" style="font-style:italic;margin:0 0 8px">“${esc(w.ex)}”</p>
    <div class="small">${w.syn && w.syn.length ? `<span class="chip mint">syn</span> ${w.syn.map(esc).join(', ')} ` : ''}${w.ant && w.ant.length ? `<br><span class="chip coral" style="margin-top:4px">ant</span> ${w.ant.map(esc).join(', ')}` : ''}</div></div>`;
  OB.bindWordCards = root => { on(root, 'click', '[data-speak]', (e, b) => speak(b.dataset.speak)); on(root, 'click', '[data-fav]', (e, b) => { const now = toggleFav(b.dataset.fav); $$(`[data-fav="${CSS.escape(b.dataset.fav)}"]`, root).forEach(x => x.classList.toggle('on', now)); toast(now ? 'Saved to favourites' : 'Removed from favourites'); }); };

  OB.route('/learn', () => {
    const app = OB.page(); const q = OB.query();
    const TABS = [['daily', 'Daily words'], ['vocab', 'Topic vocabulary'], ['flash', 'Flashcards'], ['quiz', 'Vocabulary quiz'], ['grammar', 'Grammar'], ['para', 'Paraphrasing'], ['improve', 'Sentence improvement'], ['connect', 'Connectors & expressions'], ['colloc', 'Collocations']];
    app.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('V', 16)} Learning centre</span><h1 style="font-size:2.2rem">Vocabulary & Grammar</h1><p>Build the language you need for a higher band — topic vocabulary with Bangla meanings, flashcards, quizzes, grammar lessons with instant checking, and writing tools.</p></div></div>
      <div class="wrap" style="padding-bottom:40px"><div class="side-layout"><nav class="side-nav">${TABS.map(([k, l]) => `<button data-tab="${k}">${l}</button>`).join('')}</nav><div data-pane></div></div></div>`;
    const pane = $('[data-pane]', app); OB.bindWordCards(pane);
    const show = k => { $$('[data-tab]', app).forEach(b => b.classList.toggle('on', b.dataset.tab === k)); V[k](pane, q); };
    on(app, 'click', '[data-tab]', (e, b) => show(b.dataset.tab)); show(q.tab || 'daily');
  });

  const V = {
    daily(p) {
      const ws = OB.dailyWords(5); const done = store.s.wordsSeen[today()];
      p.innerHTML = `<div class="dash-hero" style="margin-bottom:18px"><div class="small" style="opacity:.8">${new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })}</div><h2 style="color:#fff;margin:4px 0">Today's 5 words</h2><p style="opacity:.85;margin:0">A new set every day. Learn them, then take the quick quiz.</p></div>
        <div class="grid g2">${ws.map(OB.wordCard).join('')}</div>
        <div class="row" style="margin-top:18px"><button class="btn btn-primary" data-learned ${done ? 'disabled' : ''}>${done ? '✓ Marked as learned today' : 'Mark as learned'}</button><button class="btn btn-ghost" data-q>Quiz me on today's words</button></div>`;
      $('[data-learned]', p).onclick = e => { store.s.wordsSeen[today()] = ws.map(w => w.w); store.logActivity(); e.target.disabled = true; e.target.textContent = '✓ Marked as learned today'; toast('Great work! Streak updated.', 'ok'); };
      $('[data-q]', p).onclick = () => V.quiz(p, {}, ws);
    },
    vocab(p) {
      const all = OB.allVocab(); const topics = ['All', ...new Set(all.map(w => w.topic))]; let t = 'All', s = '', fav = false;
      p.innerHTML = `<div class="row" style="margin-bottom:14px"><input class="input" style="max-width:260px" placeholder="Search words or meanings…" data-s><div class="filters" data-t>${topics.map(x => `<button class="filter" data-v="${esc(x)}">${esc(x)}</button>`).join('')}</div><button class="filter" data-fv>★ Favourites</button></div><div class="small muted" data-c style="margin-bottom:10px"></div><div class="grid g2" data-g></div>`;
      const draw = () => { $$('[data-t] .filter', p).forEach(b => b.classList.toggle('on', b.dataset.v === t)); $('[data-fv]', p).classList.toggle('on', fav); const l = all.filter(w => (t === 'All' || w.topic === t) && (!fav || isFav(w.w)) && (!s || (w.w + ' ' + w.m + ' ' + (w.bn || '')).toLowerCase().includes(s))); $('[data-c]', p).textContent = `${l.length} word${l.length === 1 ? '' : 's'}`; $('[data-g]', p).innerHTML = l.map(OB.wordCard).join('') || `<div class="empty">${fav ? 'No favourite words yet — tap ★ on any word to save it.' : 'No words match your search.'}</div>`; };
      on(p, 'click', '[data-t] .filter', (e, b) => { t = b.dataset.v; draw(); }); $('[data-fv]', p).onclick = () => { fav = !fav; draw(); }; $('[data-s]', p).oninput = e => { s = e.target.value.toLowerCase(); draw(); }; draw();
    },
    flash(p) {
      const all = OB.allVocab(); let deck = shuffle(all), i = 0, known = 0, src = 'all';
      const draw = () => {
        const w = deck[i];
        p.innerHTML = `<div class="row between" style="margin-bottom:14px"><div class="seg" data-src><button data-v="all">All words</button><button data-v="fav">Favourites (${store.s.favWords.length})</button><button data-v="today">Today's words</button></div><span class="small muted">${deck.length ? `${i + 1} / ${deck.length} · known ${known}` : ''}</span></div>
          ${w ? `<div class="flash" data-card tabindex="0" role="button" aria-label="Flip card"><div class="in"><div class="face front"><div class="small" style="opacity:.75">${esc(w.topic)} · ${esc(w.pos)}</div><div class="w">${esc(w.w)}</div><div class="small" style="opacity:.75;margin-top:10px">Tap to reveal meaning</div></div><div class="face back"><b style="font-size:1.2rem">${esc(w.w)}</b><p style="margin:8px 0">${esc(w.m)}</p>${w.bn ? `<p class="small" style="color:var(--blue);margin:0" lang="bn">${esc(w.bn)}</p>` : ''}<p class="small muted" style="font-style:italic">“${esc(w.ex)}”</p></div></div></div>
          <div class="row" style="justify-content:center;margin-top:16px"><button class="btn btn-ghost" data-prev>${icon('left', 16)}</button><button class="btn btn-ghost" data-speak="${esc(w.w)}">${icon('vol', 16)} Pronounce</button><button class="btn btn-coral" data-again>Still learning</button><button class="btn btn-mint" data-know>I know it</button><button class="btn btn-ghost" data-next>${icon('right', 16)}</button></div>` : `<div class="empty"><div class="ico">${icon('star', 28)}</div>This deck is empty. Save words with ★ to build your favourites deck.</div>`}`;
        $$('[data-src] button', p).forEach(b => b.classList.toggle('on', b.dataset.v === src));
        const c = $('[data-card]', p); if (c) { c.onclick = () => c.classList.toggle('flip'); c.onkeydown = e => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); c.classList.toggle('flip'); } }; }
        const nx = () => { i = (i + 1) % deck.length; draw(); };
        const b = (s, f) => { const el = $(s, p); if (el) el.onclick = f; };
        b('[data-next]', nx); b('[data-prev]', () => { i = (i - 1 + deck.length) % deck.length; draw(); }); b('[data-know]', () => { known++; store.logActivity(); nx(); }); b('[data-again]', () => { deck.push(deck[i]); nx(); });
      };
      on(p, 'click', '[data-src] button', (e, b) => { src = b.dataset.v; const all2 = OB.allVocab(); deck = shuffle(src === 'fav' ? all2.filter(w => isFav(w.w)) : src === 'today' ? OB.dailyWords(5) : all2); i = 0; known = 0; draw(); });
      draw();
    },
    quiz(p, q, pool) {
      const all = OB.allVocab(); const base = shuffle(pool || all).slice(0, pool ? pool.length : 10); let i = 0, score = 0;
      const mk = w => { const type = Math.random() < .6 || !(w.syn && w.syn.length) ? 'meaning' : 'syn'; const wrong = shuffle(all.filter(x => x.w !== w.w)).slice(0, 3); return { w, type, opts: shuffle([w, ...wrong]) }; };
      const qs = base.map(mk);
      const draw = () => {
        if (i >= qs.length) { store.logActivity(); const best = store.s.vocabBest || 0; if (score / qs.length * 100 > best) { store.s.vocabBest = Math.round(score / qs.length * 100); store.save(); } p.innerHTML = `<div class="card center"><div class="ring" style="--p:${score / qs.length * 100};margin:0 auto 14px"><div><b>${score}/${qs.length}</b><div class="tiny muted">correct</div></div></div><h3>${score === qs.length ? 'Perfect score!' : score >= qs.length * .7 ? 'Great job!' : 'Keep practising!'}</h3><p class="muted small">Best score: ${store.s.vocabBest || 0}%</p><button class="btn btn-primary" data-again>New quiz</button></div>`; $('[data-again]', p).onclick = () => V.quiz(p, {}); return; }
        const it = qs[i];
        p.innerHTML = `<div class="card"><div class="row between"><span class="chip blue">Vocabulary quiz</span><span class="small muted">Question ${i + 1} of ${qs.length} · score ${score}</span></div><div class="bar" style="margin:12px 0 18px"><i style="width:${i / qs.length * 100}%"></i></div>
          <h3>${it.type === 'meaning' ? `Which word means: “${esc(it.w.m)}”?` : `Which word is closest in meaning to “${esc(it.w.syn[0])}”?`}</h3>
          <div class="opts">${it.opts.map(o => `<button class="opt" style="text-align:left;background:var(--card)" data-a="${esc(o.w)}"><b>${esc(o.w)}</b></button>`).join('')}</div><div data-fb></div></div>`;
        on(p.firstElementChild, 'click', '[data-a]', (e, b) => {
          if (p.dataset.lock) return; p.dataset.lock = 1; const ok = b.dataset.a === it.w.w; if (ok) score++;
          $$('[data-a]', p).forEach(x => { if (x.dataset.a === it.w.w) x.classList.add('right'); else if (x === b) x.classList.add('wrong'); });
          $('[data-fb]', p).innerHTML = `<div class="fb ${ok ? 'ok' : 'no'}" style="margin-top:12px"><span class="k">${ok ? 'Correct!' : 'Not quite.'}</span> <b>${esc(it.w.w)}</b> — ${esc(it.w.m)} <i class="muted">“${esc(it.w.ex)}”</i></div><div class="row end" style="margin-top:12px"><button class="btn btn-primary" data-nx>Next</button></div>`;
          $('[data-nx]', p).onclick = () => { delete p.dataset.lock; i++; draw(); };
        });
      };
      delete p.dataset.lock; draw();
    },
    grammar(p, q) {
      const G = [...window.GRAMMAR, ...(store.s.custom.grammar || [])]; let cur = G.find(g => g.id === q.topic) || null;
      const list = () => { p.innerHTML = `<div class="grid g2">${G.map(g => { const d = store.s.grammarDone[g.id]; return `<button class="card hover" style="text-align:left;cursor:pointer" data-g="${g.id}"><div class="row between"><h3 style="margin:0">${esc(g.title)}</h3>${d != null ? `<span class="chip mint">${d}/${g.ex.length}</span>` : `<span class="chip">${g.ex.length} exercises</span>`}</div><p class="small muted" style="margin:8px 0 0">${g.lesson.replace(/<[^>]+>/g, '').slice(0, 110)}…</p></button>`; }).join('')}</div>`; };
      const topic = g => {
        let answered = 0, score = 0;
        p.innerHTML = `<button class="btn btn-sm btn-ghost" data-back style="margin-bottom:12px">${icon('left', 14)} All grammar topics</button><div class="card" style="margin-bottom:16px"><h2>${esc(g.title)}</h2><div class="tip-card" style="padding-left:14px">${g.lesson}</div></div>
          <div class="card"><h3>Practice — instant checking</h3>${g.ex.map((x, k) => `<div class="qitem" data-ex="${k}"><div><span class="qn">${k + 1}</span>${esc(x.q)}</div><div class="opts" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">${x.opts.map(o => `<button class="opt" style="background:var(--card);text-align:left" data-o="${esc(o)}">${esc(o)}</button>`).join('')}</div><div data-fb></div></div>`).join('')}<div data-total class="small" style="margin-top:12px"></div></div>`;
        $('[data-back]', p).onclick = list;
        on(p, 'click', '[data-ex] [data-o]', (e, b) => {
          const box = b.closest('[data-ex]'); if (box.dataset.done) return; box.dataset.done = 1; const x = g.ex[+box.dataset.ex]; const ok = b.dataset.o === x.a; answered++; if (ok) score++;
          $$('[data-o]', box).forEach(o => { if (o.dataset.o === x.a) o.classList.add('right'); else if (o === b) o.classList.add('wrong'); });
          $('[data-fb]', box).innerHTML = `<div class="fb ${ok ? 'ok' : 'no'}"><span class="k">${ok ? 'Correct' : 'Incorrect'}</span> — ${esc(x.why)}</div>`;
          if (answered === g.ex.length) { store.s.grammarDone[g.id] = score; store.logActivity(); $('[data-total]', p).innerHTML = `<b>You scored ${score}/${g.ex.length}.</b> ${score === g.ex.length ? 'Excellent!' : '<a href="#" data-retry>Try again</a>'}`; const r = $('[data-retry]', p); if (r) r.onclick = e2 => { e2.preventDefault(); topic(g); }; }
        });
      };
      on(p, 'click', '[data-g]', (e, b) => topic(G.find(g => g.id === b.dataset.g)));
      cur ? topic(cur) : list();
    },
    para(p) {
      let i = 0; const L = window.PARAPHRASE;
      const draw = () => {
        const it = L[i];
        p.innerHTML = `<div class="card"><div class="row between"><span class="chip blue">Paraphrasing practice</span><span class="small muted">${i + 1} / ${L.length}</span></div><p class="small muted">Paraphrasing is essential for Task 1 & 2 introductions and for matching Reading questions. Rewrite the sentence using different words and structures.</p>
          <div class="bubble" style="margin:10px 0 14px">${esc(it.s)}</div><textarea class="textarea" rows="3" data-a placeholder="Write your paraphrase…"></textarea>
          <div class="row" style="margin-top:12px"><button class="btn btn-primary" data-chk>Compare</button><button class="btn btn-ghost" data-nx>Next sentence</button></div><div data-fb style="margin-top:14px"></div></div>`;
        $('[data-chk]', p).onclick = () => {
          const a = $('[data-a]', p).value.trim(); if (!a) return toast('Write your paraphrase first.');
          const ow = new Set(it.s.toLowerCase().match(/[a-z]+/g)); const aw = a.toLowerCase().match(/[a-z]+/g) || []; const content = aw.filter(w => w.length > 3); const same = content.filter(w => ow.has(w)).length; const pct = content.length ? Math.round(same / content.length * 100) : 0;
          $('[data-fb]', p).innerHTML = `<div class="fb ${pct <= 50 ? 'ok' : 'no'}"><span class="k">${pct}% of your key words are copied from the original.</span> ${pct <= 50 ? 'Good — you changed most of the wording.' : 'Try changing more words: use synonyms, change word forms (increase → an increase), or reorder the sentence.'}</div><div style="margin-top:10px"><b class="small">Model paraphrases</b>${it.models.map(m => `<div class="issue">${esc(m)}</div>`).join('')}</div>`;
          store.logActivity();
        };
        $('[data-nx]', p).onclick = () => { i = (i + 1) % L.length; draw(); };
      };
      draw();
    },
    improve(p) {
      let i = 0; const L = window.SENTENCE_FIX;
      const draw = () => {
        const it = L[i];
        p.innerHTML = `<div class="card"><div class="row between"><span class="chip coral">Sentence improvement</span><span class="small muted">${i + 1} / ${L.length}</span></div><p class="small muted">Improve this weak sentence so it sounds more academic and precise.</p>
          <div class="issue" style="font-size:1rem"><s style="color:inherit;text-decoration:none">${esc(it.weak)}</s></div><textarea class="textarea" rows="3" data-a placeholder="Your improved sentence…" style="margin-top:10px"></textarea>
          <div class="row" style="margin-top:12px"><button class="btn btn-primary" data-show>Show improved version</button><button class="btn btn-ghost" data-nx>Next</button></div><div data-fb style="margin-top:12px"></div></div>`;
        $('[data-show]', p).onclick = () => { $('[data-fb]', p).innerHTML = `<div class="fb ok"><span class="k">Improved:</span> ${esc(it.better)}<div class="muted small" style="margin-top:4px">${esc(it.tip)}</div></div>`; store.logActivity(); };
        $('[data-nx]', p).onclick = () => { i = (i + 1) % L.length; draw(); };
      };
      draw();
    },
    connect(p) {
      p.innerHTML = `<div class="card" style="margin-bottom:16px"><h3>Essay connectors</h3><div class="grid g2">${window.CONNECTORS.map(c => `<div><b class="small">${esc(c.g)}</b><div style="margin-top:6px">${c.w.map(w => `<span class="chip blue" style="margin:3px">${esc(w)}</span>`).join('')}</div></div>`).join('')}</div></div>
        <div class="card"><h3>Common IELTS expressions</h3><ul class="list-clean">${window.EXPRESSIONS.map(e => `<li><b>${esc(e.e)}</b><span class="small muted right">${esc(e.use)}</span></li>`).join('')}</ul></div>`;
    },
    colloc(p) {
      const L = shuffle(window.COLLOCATIONS); let i = 0, score = 0;
      const draw = () => {
        if (i >= L.length) { store.logActivity(); p.innerHTML = `<div class="card center"><h3>You scored ${score}/${L.length}</h3><p class="muted">Collocations are word partnerships that sound natural to native speakers. Using them raises your Lexical Resource score.</p><button class="btn btn-primary" data-r>Play again</button></div>`; $('[data-r]', p).onclick = () => V.colloc(p); return; }
        const it = L[i];
        p.innerHTML = `<div class="card"><div class="row between"><span class="chip mint">Collocation practice</span><span class="small muted">${i + 1}/${L.length} · score ${score}</span></div><h2 style="margin:18px 0">${esc(it.q.replace('___', '_____'))}</h2><div class="row">${shuffle(it.opts).map(o => `<button class="btn btn-ghost" data-o="${esc(o)}">${esc(o)}</button>`).join('')}</div><div data-fb style="margin-top:14px"></div></div>`;
        on(p.firstElementChild, 'click', '[data-o]', (e, b) => { if (b.closest('.card').dataset.done) return; b.closest('.card').dataset.done = 1; const ok = b.dataset.o === it.a; if (ok) score++; b.classList.add(ok ? 'btn-mint' : 'btn-danger'); $('[data-fb]', p).innerHTML = `<div class="fb ${ok ? 'ok' : 'no'}"><span class="k">${ok ? 'Correct!' : 'Not quite.'}</span> The natural collocation is <b>${esc(it.q.replace('___', it.a))}</b>.</div><div class="row end" style="margin-top:10px"><button class="btn btn-primary" data-nx>Next</button></div>`; $('[data-nx]', p).onclick = () => { i++; draw(); }; });
      };
      draw();
    }
  };
})();
