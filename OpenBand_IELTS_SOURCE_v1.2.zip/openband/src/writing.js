/* OpenBand — Writing module: task charts, editor, automated text analysis, self-assessment */
(function () {
  const { $, $$, esc, on, icon, store, toast, modal, confirmBox, fmtTime, Countdown, overallBand, bandLabel, uid } = OB;
  const COLORS = ['#3157D5', '#FF8A76', '#1FA37A', '#7B5CF6', '#F6B23C'];
  OB.allWriting = () => [...window.WRITING, ...store.s.custom.writing];
  OB.getWriting = id => OB.allWriting().find(w => w.id === id);

  /* ---------- SVG charts ---------- */
  const T = 'style="fill:var(--muted)"', G = 'style="stroke:var(--line)"';
  function legend(series, x0 = 60, y = 18) { let x = x0; return series.map((s, i) => { const w = s.name.length * 7 + 30; const o = `<rect x="${x}" y="${y - 9}" width="12" height="12" rx="3" fill="${COLORS[i % 5]}"/><text x="${x + 17}" y="${y + 1}" font-size="12" ${T}>${esc(s.name)}</text>`; x += w; return o; }).join(''); }
  function axes(c, W, H, L, B, top) {
    let o = ''; const steps = 5;
    for (let k = 0; k <= steps; k++) { const v = c.max / steps * k; const y = H - B - (H - B - top) * k / steps; o += `<line x1="${L}" x2="${W - 14}" y1="${y}" y2="${y}" ${G}/><text x="${L - 8}" y="${y + 4}" font-size="11" text-anchor="end" ${T}>${Math.round(v)}${c.unit === '%' ? '%' : ''}</text>`; }
    return o;
  }
  function lineChart(c) {
    const W = 640, H = 340, L = 52, B = 40, top = 40; const n = c.x.length; const xs = i => L + 10 + (W - L - 40) * i / (n - 1); const ys = v => H - B - (H - B - top) * v / c.max;
    return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(c.title)}">${legend(c.series)}${axes(c, W, H, L, B, top)}
      ${c.x.map((l, i) => `<text x="${xs(i)}" y="${H - B + 20}" font-size="12" text-anchor="middle" ${T}>${esc(l)}</text>`).join('')}
      ${c.series.map((s, k) => `<polyline fill="none" stroke="${COLORS[k]}" stroke-width="3" points="${s.v.map((v, i) => `${xs(i)},${ys(v)}`).join(' ')}"/>${s.v.map((v, i) => `<circle cx="${xs(i)}" cy="${ys(v)}" r="4.5" fill="${COLORS[k]}"><title>${esc(s.name)} ${c.x[i]}: ${v}${c.unit}</title></circle>`).join('')}`).join('')}
      <text x="${W / 2}" y="${H - 4}" font-size="11" text-anchor="middle" ${T}>${esc(c.title)}</text></svg>`;
  }
  function barChart(c) {
    const W = 640, H = 340, L = 52, B = 40, top = 40; const n = c.x.length, m = c.series.length; const gw = (W - L - 30) / n; const bw = Math.min(28, (gw - 18) / m); const ys = v => (H - B - top) * v / c.max;
    return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(c.title)}">${m > 1 ? legend(c.series) : ''}${axes(c, W, H, L, B, top)}
      ${c.x.map((l, i) => { const gx = L + 10 + gw * i + (gw - bw * m) / 2; return c.series.map((s, k) => `<rect x="${gx + k * bw}" y="${H - B - ys(s.v[i])}" width="${bw - 3}" height="${ys(s.v[i])}" rx="3" fill="${COLORS[k]}"><title>${esc(s.name)} ${esc(l)}: ${s.v[i]}${c.unit}</title></rect>`).join('') + `<text x="${L + 10 + gw * i + gw / 2}" y="${H - B + 20}" font-size="12" text-anchor="middle" ${T}>${esc(l)}</text>`; }).join('')}
      <text x="${W / 2}" y="${H - 4}" font-size="11" text-anchor="middle" ${T}>${esc(c.title)}</text></svg>`;
  }
  function pie(p, cx, cy, r) {
    let a0 = -Math.PI / 2; const tot = p.slices.reduce((s, x) => s + x[1], 0);
    return p.slices.map(([name, v], i) => { const a1 = a0 + v / tot * Math.PI * 2; const big = a1 - a0 > Math.PI ? 1 : 0; const pa = `M${cx},${cy} L${cx + r * Math.cos(a0)},${cy + r * Math.sin(a0)} A${r},${r} 0 ${big} 1 ${cx + r * Math.cos(a1)},${cy + r * Math.sin(a1)} Z`; const mid = (a0 + a1) / 2; const lx = cx + r * .66 * Math.cos(mid), ly = cy + r * .66 * Math.sin(mid); a0 = a1; return `<path d="${pa}" fill="${COLORS[i % 5]}" stroke="var(--card)" stroke-width="2"><title>${esc(name)}: ${v}%</title></path>${v >= 6 ? `<text x="${lx}" y="${ly + 4}" text-anchor="middle" font-size="12" font-weight="700" fill="#fff">${v}%</text>` : ''}`; }).join('') + `<text x="${cx}" y="${cy + r + 22}" text-anchor="middle" font-weight="700" font-size="13" style="fill:var(--text)">${esc(p.name)}</text>`;
  }
  function piesChart(c) {
    const W = 640, H = 330; const names = c.pies[0].slices.map(s => s[0]);
    return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(c.title)}">${c.pies.map((p, i) => pie(p, 150 + i * 250, 140, 105)).join('')}
      ${names.map((n, i) => `<rect x="${40 + i * 118}" y="${H - 30}" width="12" height="12" rx="3" fill="${COLORS[i % 5]}"/><text x="${57 + i * 118}" y="${H - 20}" font-size="12" ${T}>${esc(n)}</text>`).join('')}</svg>`;
  }
  function villageMap(year, today) {
    const lbl = (x, y, t) => `<text x="${x}" y="${y}" font-size="11" text-anchor="middle" fill="#14213D" font-weight="700">${t}</text>`;
    return `<svg viewBox="0 0 300 260" role="img" aria-label="Ashford ${year}"><rect width="300" height="260" rx="10" fill="#EAF6EE"/>
      <path d="M0 150 H300" stroke="#C9A97A" stroke-width="14"/>${lbl(40, 145, 'Main Road')}
      <path d="M150 0 V150" stroke="#C9A97A" stroke-width="${today ? 10 : 6}"/>
      <path d="M0 215 Q150 190 300 225" stroke="#9FD0F0" stroke-width="16" fill="none"/>${lbl(250, 245, 'River')}
      ${today ? `<rect x="20" y="20" width="110" height="60" rx="6" fill="#D9DDE6"/>${lbl(75, 55, 'Housing estate')}<rect x="170" y="20" width="110" height="50" rx="6" fill="#FFD9CF"/>${lbl(225, 50, 'Supermarket')}<rect x="170" y="85" width="60" height="45" rx="6" fill="#E9E8FF"/>${lbl(200, 112, 'School')}<rect x="20" y="95" width="110" height="38" rx="6" fill="#BFE3C6"/>${lbl(75, 118, 'Park')}<rect x="190" y="160" width="80" height="26" rx="6" fill="#D9DDE6"/>${lbl(230, 178, 'Car park')}<path d="M100 196 L130 226" stroke="#8a6" stroke-width="5"/>${lbl(95, 190, 'Footbridge')}`
        : `<rect x="20" y="20" width="110" height="110" rx="6" fill="#CDE8B5"/>${lbl(75, 78, 'Farmland')}<rect x="170" y="20" width="60" height="45" rx="6" fill="#F3E3C2"/>${lbl(200, 47, 'Shops')}<rect x="170" y="85" width="60" height="45" rx="6" fill="#E9E8FF"/>${lbl(200, 112, 'School')}<rect x="240" y="20" width="45" height="110" rx="6" fill="#BFE3C6"/>${lbl(262, 78, 'Woods')}<rect x="190" y="160" width="80" height="26" rx="6" fill="#F3E3C2"/>${lbl(230, 178, 'Market')}`}
      <text x="150" y="252" text-anchor="middle" font-size="13" font-weight="800" fill="#14213D">${year}</text></svg>`;
  }
  OB.renderChart = function (c) {
    if (!c) return '';
    if (c.kind === 'line') return lineChart(c);
    if (c.kind === 'bar') return barChart(c);
    if (c.kind === 'pies') return piesChart(c);
    if (c.kind === 'table') return `<div style="overflow:auto"><div class="small muted" style="margin-bottom:6px;font-weight:700">${esc(c.title)}</div><table class="tbl"><thead><tr>${c.head.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${c.rows.map(r => `<tr>${r.map(x => `<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    if (c.kind === 'maps') return `<div class="grid g2" style="gap:10px">${villageMap('1995', false)}${villageMap('Today', true)}</div>`;
    if (c.kind === 'process') return `<div class="small muted" style="margin-bottom:8px;font-weight:700">${esc(c.title)}</div><div class="grid g4" style="gap:8px">${c.steps.map((s, i) => `<div style="border:1.5px solid var(--line-2);border-radius:12px;padding:10px;background:var(--card-2);font-size:.85rem;position:relative"><span class="qn" style="margin-bottom:6px">${i + 1}</span><div>${esc(s)}</div></div>`).join('')}</div><div class="tiny faint" style="margin-top:6px">Stages run 1 → 8 in order.</div>`;
    if (c.kind === 'mixed') return `<div class="grid g2" style="gap:10px;align-items:center">${barChart(c.bar)}<svg viewBox="0 0 300 300">${pie(c.pie, 150, 130, 100)}${c.pie.slices.map((s, i) => `<rect x="${20 + i * 95}" y="280" width="11" height="11" rx="3" fill="${COLORS[i]}"/><text x="${35 + i * 95}" y="290" font-size="11" ${T}>${esc(s[0])}</text>`).join('')}</svg></div>`;
    return '';
  };

  /* ---------- automated analysis (NOT AI) ---------- */
  const STOP = new Set('a an the and or but if of to in on at for with by from as is are was were be been being it its this that these those there their they them he she his her we our you your i my me not no so than then too very can could will would should may might must do does did have has had which who whom what when where why how all any each more most other some such only own same just also into over under about after before between through during while because'.split(' '));
  const LINKERS = { addition: ['furthermore', 'moreover', 'in addition', 'additionally', 'not only', 'besides'], contrast: ['however', 'nevertheless', 'on the other hand', 'although', 'whereas', 'in contrast', 'despite', 'even though', 'while'], cause: ['therefore', 'as a result', 'consequently', 'thus', 'because', 'since', 'due to', 'owing to', 'this means'], example: ['for example', 'for instance', 'such as', 'to illustrate'], sequence: ['firstly', 'secondly', 'finally', 'first of all', 'to begin with', 'lastly'], conclusion: ['in conclusion', 'to conclude', 'to sum up', 'overall', 'in summary', 'all things considered'] };
  const COMPLEX = /\b(although|though|whereas|while|which|who|whom|whose|unless|if|because|since|despite|when|whether|so that|in order to|not only)\b/gi;
  const SYN = { good: 'beneficial, positive, valuable', bad: 'harmful, detrimental, negative', big: 'significant, substantial, considerable', important: 'crucial, essential, vital', many: 'numerous, a large number of', thing: 'aspect, factor, issue', things: 'aspects, factors, issues', get: 'obtain, receive, gain', show: 'illustrate, indicate, demonstrate', shows: 'illustrates, indicates, demonstrates', very: 'extremely, highly (or a stronger adjective)', people: 'individuals, citizens, residents', increase: 'rise, growth, climb', problem: 'issue, challenge, difficulty', problems: 'issues, challenges', help: 'assist, support, enable', think: 'believe, consider, argue', use: 'utilise, employ, make use of', nowadays: 'currently, in recent years', lot: 'a great deal, a considerable amount', also: 'furthermore, in addition', make: 'create, produce, cause', change: 'shift, transformation' };
  const ERRORS = [
    [/\b(informations|advices|knowledges|equipments|furnitures|homeworks|researches)\b/gi, m => m.replace(/s$/i, ''), 'This noun is uncountable — no plural “s”.'],
    [/\bmore (better|worse|easier|bigger|higher|cheaper|faster|lower)\b/gi, m => m.split(' ')[1], 'Double comparative — the adjective is already comparative.'],
    [/\bdiscuss about\b/gi, () => 'discuss', '“Discuss” needs no preposition.'],
    [/\b(am|is|are) agree\b/gi, () => 'agree', '“Agree” is a verb.'],
    [/\bin the other hand\b/gi, () => 'on the other hand', 'Fixed phrase.'],
    [/\bdepends? of\b/gi, m => m.replace(/of$/i, 'on'), 'depend ON.'],
    [/\bcompare to\b/gi, () => 'compared to / compared with', 'Use the past participle.'],
    [/\bthe most of\b/gi, () => 'most', '“Most people”, not “the most of people”.'],
    [/\b(gonna|wanna|kinda|gotta)\b/gi, () => 'going to / want to', 'Too informal for IELTS writing.'],
    [/\bin my opinion,? i think\b/gi, () => 'In my opinion,', 'Redundant — both mean the same.'],
    [/\bvery very\b/gi, () => 'extremely', 'Avoid repeating intensifiers.'],
    [/\b(\w{3,})\s+\1\b/gi, m => m.split(/\s+/)[0], 'Repeated word.'],
    [/(^|[.!?]\s+)i\b/g, m => m.replace(/i$/, 'I'), 'Capitalise “I”.'],
    [/\s+i\s+/g, () => ' I ', 'Capitalise “I”.'],
    [/[,.](?=[A-Za-z])/g, m => m + ' ', 'Add a space after punctuation.'],
    [/\ba (?=[aeio][a-z])(?!(?:one|once|use|euro|uni|eu))\w+/gi, m => 'an ' + m.slice(2), '“an” before a vowel sound.'],
    [/\ban (?=[bcdfgjklmnpqrstvwxyz])(?!(?:hour|honest|honour|heir))\w+/gi, m => 'a ' + m.slice(3), '“a” before a consonant sound.']
  ];
  const INFORMAL = /\b(don't|doesn't|can't|won't|isn't|aren't|it's|I'm|they're|we're|you're|didn't|wasn't|kids|stuff|okay|ok|guys|a lot of|lots of)\b/gi;

  OB.analyzeWriting = function (text, task) {
    const raw = text.trim(); const words = raw.match(/[A-Za-z][A-Za-z'’-]*/g) || []; const wc = words.length;
    const sents = raw.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(s => s.split(/\s+/).length > 1);
    const paras = raw.split(/\n\s*\n|\n/).map(p => p.trim()).filter(p => p.split(/\s+/).length > 4);
    const low = raw.toLowerCase(); const lw = words.map(w => w.toLowerCase());
    const content = lw.filter(w => !STOP.has(w)); const uniq = new Set(content);
    const ttr = content.length ? uniq.size / content.length : 0;
    const adv = content.filter(w => w.length >= 9).length / Math.max(1, content.length);
    const linkUsed = {}; Object.entries(LINKERS).forEach(([g, list]) => list.forEach(l => { const n = (low.match(new RegExp('\\b' + l + '\\b', 'g')) || []).length; if (n) { linkUsed[g] = (linkUsed[g] || 0) + n; } }));
    const linkFreq = {}; Object.values(LINKERS).flat().forEach(l => { const n = (low.match(new RegExp('\\b' + l + '\\b', 'g')) || []).length; if (n) linkFreq[l] = n; });
    const complex = (raw.match(COMPLEX) || []).length; const cps = complex / Math.max(1, sents.length);
    const lens = sents.map(s => s.split(/\s+/).length); const avgLen = lens.length ? lens.reduce((a, b) => a + b, 0) / lens.length : 0;
    const errors = []; ERRORS.forEach(([re, fix, why]) => { const seen = new Set(); (raw.match(re) || []).forEach(m => { if (seen.has(m.toLowerCase()) || errors.length > 14 || errors.some(e => e.from.toLowerCase() === m.trim().toLowerCase())) return; seen.add(m.toLowerCase()); errors.push({ from: m.trim(), to: fix(m).trim(), why }); }); });
    const informal = [...new Set((raw.match(INFORMAL) || []).map(x => x.toLowerCase()))];
    const freq = {}; content.forEach(w => freq[w] = (freq[w] || 0) + 1);
    const repeated = Object.entries(freq).filter(([w, n]) => n >= Math.max(4, wc / 60) && w.length > 3).sort((a, b) => b[1] - a[1]).slice(0, 6);
    const weakWords = Object.keys(SYN).filter(w => (lw.filter(x => x === w).length >= (w === 'very' ? 2 : 2))).slice(0, 8).map(w => ({ w, n: lw.filter(x => x === w).length, alt: SYN[w] }));
    const longS = sents.filter(s => s.split(/\s+/).length > 40).slice(0, 3);
    const starts = sents.filter(s => /^(and|but|so|because)\b/i.test(s)).slice(0, 3);

    const isLetter = task.track === 'general' && task.task === 1; const t1 = task.task === 1; const min = t1 ? 150 : 250;
    const checks = [];
    const add = (ok, label, tip) => checks.push({ ok, label, tip });
    add(wc >= min, `At least ${min} words (${wc})`, `Task ${task.task} requires at least ${min} words. Under-length answers lose marks in ${t1 ? 'Task Achievement' : 'Task Response'}.`);
    if (isLetter) {
      add(/^\s*dear\b/i.test(raw), 'Opens with a greeting (Dear …)', 'Start with “Dear Sir or Madam,” (formal) or “Dear [name],”.');
      add(/(yours faithfully|yours sincerely|best wishes|kind regards|regards|love|take care|warm wishes|all the best)/i.test(raw), 'Has an appropriate sign-off', 'End with “Yours faithfully” (unknown recipient), “Yours sincerely” (named) or “Best wishes” (friend).');
      if (/dear sir or madam/i.test(raw) && /yours sincerely/i.test(raw)) add(false, 'Sign-off matches greeting', '“Dear Sir or Madam” should end with “Yours faithfully”.');
      if (/formal/i.test(task.kind) && !/semi|informal/i.test(task.kind)) add(informal.length === 0, 'Formal tone (no contractions/slang)', 'Avoid contractions and informal words in a formal letter.');
      add(/\b(i am writing|i'm writing)\b/i.test(raw), 'States the purpose early', 'Start with a clear purpose: “I am writing to …”.');
    } else if (t1) {
      add(/\b(overall|in general|it is clear that|it is evident|generally|to summarise|in summary)\b/i.test(raw), 'Includes an overview', 'Write a sentence starting “Overall, …” that summarises the main trends.');
      add((raw.match(/\d/g) || []).length >= 4, 'Supports with figures', 'Quote key numbers from the chart to support your description.');
      add(!/\b(i think|i believe|in my opinion|i feel)\b/i.test(raw), 'No personal opinion', 'Task 1 is a factual report — don\'t give opinions.');
    } else {
      add(/\b(i (strongly |firmly )?(believe|agree|disagree|think)|in my (view|opinion)|from my perspective|it seems to me)\b/i.test(raw), 'States a clear position', 'Make your opinion clear in the introduction and conclusion.');
      add(/\b(in conclusion|to conclude|to sum up|in summary|overall)\b/i.test(raw.split(/\s+/).slice(-90).join(' ')), 'Has a conclusion', 'Finish with a short conclusion that restates your view.');
      add(/\b(for example|for instance|such as|to illustrate)\b/i.test(raw), 'Supports ideas with examples', 'Support each main idea with an example or explanation.');
    }
    add(paras.length >= (t1 ? 3 : 4), `Clear paragraphs (${paras.length})`, t1 ? 'Use 3–4 paragraphs: introduction, overview, details.' : 'Use 4–5 paragraphs: introduction, 2–3 body paragraphs, conclusion.');

    // criterion estimates (indicative only, capped)
    const cap = v => Math.max(4, Math.min(8, Math.round(v * 2) / 2));
    let ta = 6; if (wc < min * .8) ta -= 1.5; else if (wc < min) ta -= .5;
    const keyChecks = checks.slice(1, isLetter ? 4 : 4); keyChecks.forEach(c => { ta += c.ok ? .3 : -.6; });
    let cc = 5.5; const groups = Object.keys(linkUsed).length; cc += groups >= 4 ? 1 : groups >= 2 ? .5 : 0; cc += paras.length >= (t1 ? 3 : 4) ? .5 : paras.length <= 1 ? -1.5 : 0; if (Object.values(linkFreq).some(n => n > 3)) cc -= .5;
    const tAdj = ttr - Math.max(0, (300 - wc) / 300) * .12; let lr = tAdj >= .74 ? 7 : tAdj >= .66 ? 6.5 : tAdj >= .58 ? 6 : tAdj >= .5 ? 5.5 : 5; if (wc < min * .8) lr -= .5; if (adv > .12) lr += .5; if (informal.length > 2 && !/informal/i.test(task.kind)) lr -= .5; if (repeated.length > 3) lr -= .5;
    let gr = 6; gr += cps >= .6 ? 1 : cps >= .35 ? .5 : cps < .15 ? -.5 : 0; const errRate = errors.length / Math.max(1, wc) * 100; gr -= errRate > 3 ? 1.5 : errRate > 1.5 ? 1 : errRate > .5 ? .5 : 0; if (avgLen < 9 || avgLen > 34) gr -= .5;
    const crit = { ta: cap(ta), cc: cap(cc), lr: cap(lr), gr: cap(gr) };
    const enough = wc >= 60;
    const overall = enough ? overallBand(Object.values(crit)) : null;

    const strengths = [], weaknesses = [];
    checks.forEach(c => (c.ok ? strengths : weaknesses).push(c.ok ? c.label : c.tip));
    if (groups >= 3) strengths.push(`Uses a range of linking devices (${Object.keys(linkUsed).join(', ')}).`); else weaknesses.push('Use a wider range of linking words: contrast (however, whereas), cause (therefore, as a result), examples (for instance).');
    if (cps >= .35) strengths.push('Good mix of complex sentences.'); else weaknesses.push('Add more complex sentences using although, which, because, whereas, if.');
    if (ttr >= .6) strengths.push('Good lexical variety.'); else weaknesses.push('Vocabulary is repetitive — try synonyms and topic-specific words.');
    if (errors.length) weaknesses.push(`${errors.length} common grammar/usage issue${errors.length > 1 ? 's' : ''} detected.`);
    const plan = [];
    if (wc < min) plan.push(`Practise planning so you can reach ${min}+ words: spend 3–5 minutes outlining before writing.`);
    if (weaknesses.some(w => /overview/i.test(w))) plan.push('For every Task 1 practice, write the overview sentence first, before the details.');
    if (weaknesses.some(w => /position/i.test(w))) plan.push('Write a one-sentence thesis in your introduction that answers the question directly.');
    if (groups < 3) plan.push('Learn 2 connectors from each group in Learn → Connectors and use them in your next essay.');
    if (ttr < .6 || weakWords.length) plan.push('Replace basic words (good, bad, big, very) with precise alternatives — see suggestions above.');
    if (errors.length) plan.push('Review the Grammar → Common IELTS mistakes lesson and re-check your essay for these patterns.');
    if (cps < .35) plan.push('Rewrite 3 sentences from this essay as complex sentences (Grammar → Complex sentences).');
    plan.push('Compare your answer with the sample answer (when available) and note 3 phrases to reuse.');
    return { wc, sents: sents.length, paras: paras.length, avgLen: Math.round(avgLen * 10) / 10, ttr: Math.round(ttr * 100), complex, linkUsed, errors, informal, repeated, weakWords, longS, starts, checks, crit, overall, enough, strengths, weaknesses, plan, min };
  };

  /* ---------- pages ---------- */
  OB.route('/writing', () => {
    const app = OB.page(); const q = OB.query();
    let track = q.track || 'academic', task = q.task || 'all';
    app.innerHTML = `<div class="page-head"><div class="wrap"><span class="eyebrow">${icon('W', 16)} Writing</span><h1 style="font-size:2.2rem">IELTS Writing practice</h1><p>Write in a distraction-free editor with a live word counter, timer and autosave. Get an automated text-analysis estimate, a self-assessment checklist and model answers. All free.</p>
      <div class="row"><div class="seg" data-tr><button data-v="academic">Academic</button><button data-v="general">General Training</button></div><div class="seg" data-tk><button data-v="all">All tasks</button><button data-v="1">Task 1</button><button data-v="2">Task 2</button></div><a class="btn btn-sm btn-ghost" href="#/writing-history">${icon('clock', 15)} Writing history (${store.s.writing.length})</a></div></div></div>
      <div class="wrap" style="padding-bottom:40px"><div class="grid g3" data-list></div>
      <div class="card tip-card" style="margin-top:26px"><h3>${icon('bulb')} How Writing is assessed</h3><div class="grid g4 small">${[['Task Achievement / Response', 'Do you answer every part of the task, with a clear overview (Task 1) or position (Task 2)?'], ['Coherence & Cohesion', 'Is your writing logically organised in paragraphs, with clear linking?'], ['Lexical Resource', 'Do you use a range of accurate, precise vocabulary?'], ['Grammatical Range & Accuracy', 'Do you use a variety of structures with few errors?']].map(([a, b]) => `<div><b>${a}</b><p class="muted" style="margin:4px 0 0">${b}</p></div>`).join('')}</div></div></div>`;
    const draw = () => {
      $$('[data-tr] button', app).forEach(b => b.classList.toggle('on', b.dataset.v === track)); $$('[data-tk] button', app).forEach(b => b.classList.toggle('on', b.dataset.v === task));
      const list = OB.allWriting().filter(w => w.track === track && (task === 'all' || String(w.task) === task));
      $('[data-list]', app).innerHTML = list.map(w => { const d = store.s.drafts[w.id]; const done = store.s.writing.filter(s => s.taskId === w.id).length; return `<a class="card hover test-card" href="#/writing/${esc(w.id)}" style="color:inherit"><div class="row between"><span class="chip ${w.task === 1 ? 'coral' : 'blue'}">Task ${w.task} · ${esc(w.kind)}</span><span class="chip">${esc(w.level)}</span></div><h3 style="margin:4px 0 0">${esc(w.title)}</h3><p class="small muted" style="margin:0">${esc(w.prompt.split('\n')[0].slice(0, 120))}${w.prompt.length > 120 ? '…' : ''}</p><div class="meta"><span>${icon('clock', 14)} ${w.task === 1 ? 20 : 40} min</span><span>${w.task === 1 ? '150' : '250'}+ words</span>${w.sample ? `<span>${icon('check', 14)} Sample answer</span>` : ''}${d && d.text ? `<span style="color:var(--blue)">Draft saved</span>` : ''}${done ? `<span>${done} submitted</span>` : ''}</div></a>`; }).join('') || '<div class="empty">No tasks in this category yet.</div>';
    };
    on(app, 'click', '[data-tr] button', (e, b) => { track = b.dataset.v; draw(); }); on(app, 'click', '[data-tk] button', (e, b) => { task = b.dataset.v; draw(); });
    draw();
  });

  OB.route('/writing/:id', ({ id }) => {
    const w = OB.getWriting(id); if (!w) return OB.notFound();
    OB.page().innerHTML = '';
    const opts = OB.query();
    OB.runWriting(w, { exitTo: '#/writing' });
  });

  // opts: {timed, minutes, onSubmit(text), label, exitTo, mock}
  OB.runWriting = function (w, opts = {}) {
    const draft = store.s.drafts[w.id] || { text: '', elapsed: 0 };
    const mins = opts.minutes || (w.task === 1 ? 20 : 40); let timed = !!opts.timed;
    const root = document.createElement('div'); root.className = 'exam'; document.body.appendChild(root); document.body.style.overflow = 'hidden';
    let timer; const close = () => { timer && timer.stop(); root.remove(); document.body.style.overflow = ''; }; OB.onLeave(close);
    const isLetter = w.track === 'general' && w.task === 1;
    root.innerHTML = `<div class="exam-top">${OB.LOGO(30)}<div class="ttl">${esc(opts.label || `Writing Task ${w.task} · ${w.kind}`)}<small>${esc(w.title)}</small></div>
      <div class="timer" data-timer>${icon('clock', 18)} <span>${fmtTime(timed ? mins * 60 - (draft.elapsed || 0) : 0)}</span></div>
      ${opts.mock ? '' : `<label class="small row" style="gap:6px;color:#C9D3F2;white-space:nowrap"><input type="checkbox" data-timed ${timed ? 'checked' : ''}> Timer</label>`}
      <button class="btn btn-sm btn-outline-white" data-exit>${opts.mock ? 'Pause' : 'Save & exit'}</button></div>
      <div class="write-wrap"><div class="pane" style="border-right:1px solid var(--line)">
        <span class="chip ${w.task === 1 ? 'coral' : 'blue'}">${w.track === 'academic' ? 'Academic' : 'General Training'} · Task ${w.task}</span>
        <div style="white-space:pre-line;margin:14px 0;font-size:1.02rem">${esc(w.prompt)}</div>
        ${w.chart ? `<div class="chart-box">${OB.renderChart(w.chart)}</div>` : ''}
        <p class="small muted" style="margin-top:12px">${w.task === 1 ? 'You should spend about 20 minutes on this task. Write at least 150 words.' : 'You should spend about 40 minutes on this task. Write at least 250 words.'}</p>
        <details class="card" style="margin-top:12px;padding:14px 18px"><summary style="cursor:pointer;font-weight:700">${icon('bulb', 16)} Task-specific tips</summary><ul class="small" style="padding-left:18px">${(isLetter ? ['Identify the tone: formal (company), semi-formal (neighbour/colleague) or informal (friend).', 'Cover all three bullet points — one paragraph each.', 'Open with your purpose; close with what you want to happen next.', 'Match greeting and sign-off: Dear Sir or Madam → Yours faithfully.'] : w.task === 1 ? ['Paraphrase the question in your introduction.', 'Write an overview of the main trends — no numbers needed there.', 'Group similar data and make comparisons.', 'Do not give opinions or reasons not shown in the data.'] : ['Underline every part of the question and answer all of them.', 'State your position clearly in the introduction.', 'One main idea per body paragraph, with explanation and an example.', 'Leave 3 minutes to check grammar and spelling.']).map(t => `<li>${t}</li>`).join('')}</ul></details>
      </div>
      <div class="pane" style="display:flex;flex-direction:column;gap:12px;min-height:420px">
        <textarea class="editor" data-ed placeholder="Start writing here…" spellcheck="false" aria-label="Your answer">${esc(draft.text)}</textarea>
        <div class="row between"><div class="wc" data-wc></div><div class="row" style="gap:8px">${opts.mock ? '' : `<button class="btn btn-sm btn-ghost" data-clear>${icon('trash', 14)} Clear</button>${w.sample ? `<button class="btn btn-sm btn-ghost" data-sample>Sample answer</button>` : ''}`}<button class="btn btn-sm btn-primary" data-submit>${opts.mock ? 'Finish task' : 'Submit for feedback'}</button></div></div>
      </div></div>`;
    const ed = $('[data-ed]', root), wcEl = $('[data-wc]', root), tEl = $('[data-timer]', root); const min = w.task === 1 ? 150 : 250;
    let savedAt = null;
    const count = () => { const n = (ed.value.match(/[A-Za-z0-9][A-Za-z0-9'’-]*/g) || []).length; wcEl.innerHTML = `<span><b class="${n >= min ? 'ok' : 'low'}">${n}</b> words</span><span>${min - n > 0 ? `${min - n} to minimum` : '<span class="ok">✓ minimum reached</span>'}</span><span class="faint">${savedAt ? 'Draft saved ' + savedAt : 'Autosave on'}</span>`; return n; };
    let st; ed.addEventListener('input', () => { count(); clearTimeout(st); st = setTimeout(() => { store.s.drafts[w.id] = { text: ed.value, elapsed: draft.elapsed, updated: Date.now() }; store.save(); savedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); count(); }, 600); });
    count(); setTimeout(() => ed.focus(), 50);
    const startTimer = () => { timer && timer.stop(); timer = new Countdown(timed ? mins * 60 : 1e9, { startElapsed: draft.elapsed || 0, onTick: (left, el) => { draft.elapsed = el; $('span', tEl).textContent = fmtTime(timed ? left : el); tEl.classList.toggle('low', timed && left < 180); }, onEnd: () => { if (timed) { toast('Time is up!'); submit(true); } } }); timer.start(); };
    startTimer();
    const t = $('[data-timed]', root); if (t) t.onchange = () => { timed = t.checked; draft.elapsed = 0; startTimer(); };
    const saveDraft = () => { store.s.drafts[w.id] = { text: ed.value, elapsed: draft.elapsed, updated: Date.now() }; store.save(true); };
    $('[data-exit]', root).onclick = () => { saveDraft(); close(); if (opts.onPause) opts.onPause(ed.value); else { toast('Draft saved.', 'ok'); OB.go(opts.exitTo || '#/writing'); } };
    const c = $('[data-clear]', root); if (c) c.onclick = async () => { if (await confirmBox('Clear your answer?', 'This removes all text in the editor.', 'Clear', true)) { ed.value = ''; ed.dispatchEvent(new Event('input')); } };
    const s = $('[data-sample]', root); if (s) s.onclick = () => modal(`<div class="row between"><h3 style="margin:0">Sample answer</h3><button class="icon-btn" data-close aria-label="Close">${icon('x')}</button></div><p class="small muted">An original example of a well-organised response, written for practice. Try writing your own first.</p><div style="white-space:pre-line;font-family:var(--serif);line-height:1.75">${esc(w.sample)}</div>`, { wide: true });
    async function submit(auto) {
      const n = count();
      if (!auto && !opts.mock && n < 20) return toast('Write a bit more before submitting.', 'bad');
      if (!auto && n < min && !(await confirmBox('Submit now?', `Your answer has ${n} words, below the ${min}-word minimum. Under-length answers lose marks.`, 'Submit anyway'))) return;
      timer && timer.stop();
      if (opts.onSubmit) { close(); delete store.s.drafts[w.id]; store.save(); opts.onSubmit(ed.value, draft.elapsed); return; }
      const res = OB.analyzeWriting(ed.value, w);
      const sub = { id: uid(), taskId: w.id, title: w.title, task: w.task, track: w.track, kind: w.kind, text: ed.value, words: res.wc, est: res.overall, crit: res.crit, date: new Date().toISOString(), elapsed: Math.round(draft.elapsed || 0) };
      store.s.writing.unshift(sub); delete store.s.drafts[w.id];
      store.addAttempt({ testId: w.id, module: 'W', title: `Writing Task ${w.task}: ${w.title}`, band: res.overall, raw: res.wc, total: min, mode: timed ? 'timed' : 'practice', subId: sub.id, elapsed: sub.elapsed });
      close(); OB.go('#/writing-review/' + sub.id);
    }
    $('[data-submit]', root).onclick = () => submit(false);
  };

  /* ---------- review page ---------- */
  const CRIT = [['ta', 'Task Achievement / Response'], ['cc', 'Coherence & Cohesion'], ['lr', 'Lexical Resource'], ['gr', 'Grammatical Range & Accuracy']];
  const SELF = {
    ta: [[5, 'Only partly answers the task; ideas limited or unclear.'], [6, 'Answers all parts but some ideas are underdeveloped.'], [7, 'Answers all parts; clear position/overview; ideas extended and supported.'], [8, 'Fully answers the task with well-developed, relevant ideas.']],
    cc: [[5, 'Some organisation, but paragraphing or linking is weak.'], [6, 'Generally organised; linking sometimes mechanical.'], [7, 'Logical progression; clear paragraphs; range of linkers.'], [8, 'Sequenced smoothly; cohesion used naturally.']],
    lr: [[5, 'Limited vocabulary; frequent repetition; noticeable errors.'], [6, 'Adequate range; some errors that don\'t impede meaning.'], [7, 'Some less common words and collocations; occasional errors.'], [8, 'Wide, precise vocabulary; rare errors.']],
    gr: [[5, 'Mostly simple sentences; frequent errors.'], [6, 'Mix of simple and complex; some errors.'], [7, 'Variety of complex structures; many error-free sentences.'], [8, 'Wide range; majority of sentences error-free.']]
  };
  OB.writingFeedbackHTML = function (sub, w) {
    const r = OB.analyzeWriting(sub.text, w || sub);
    return `<div class="estimate-note" style="margin-bottom:16px">${icon('info')} <div><b>Automated text-analysis estimate — not an AI evaluation and not an official IELTS score.</b> It measures length, structure, linking, sentence variety, vocabulary range and common error patterns. It cannot fully judge your ideas, accuracy of data or spelling. Use it alongside the self-assessment below.</div></div>
    <div class="grid g2" style="align-items:start">
      <div class="card"><div class="row between"><h3 style="margin:0">Estimated band</h3><span class="band-pill" style="font-size:1.3rem;height:44px;min-width:64px">${r.enough ? bandLabel(r.overall) : '—'}</span></div>
        ${r.enough ? `<p class="small muted">Indicative range: ${bandLabel(Math.max(4, r.overall - .5))}–${bandLabel(Math.min(8.5, r.overall + .5))}</p>` : '<p class="small muted">Too short to estimate (minimum 60 words).</p>'}
        <div class="stack">${CRIT.map(([k, l]) => `<div class="crit"><span class="small" style="font-weight:700">${l}</span><span class="band-pill">${r.enough ? bandLabel(r.crit[k]) : '—'}</span><div class="bar ${k === 'ta' ? '' : k === 'cc' ? 'mint' : k === 'lr' ? 'coral' : 'violet'}"><i style="width:${r.enough ? r.crit[k] / 9 * 100 : 0}%"></i></div></div>`).join('')}</div>
        <div class="hr"></div><div class="grid g2 small" style="gap:8px"><div>Words: <b>${r.wc}</b></div><div>Paragraphs: <b>${r.paras}</b></div><div>Sentences: <b>${r.sents}</b></div><div>Avg sentence: <b>${r.avgLen}</b> words</div><div>Vocabulary variety: <b>${r.ttr}%</b></div><div>Complex structures: <b>${r.complex}</b></div></div></div>
      <div class="card"><h3>Task checklist</h3><ul class="list-clean">${r.checks.map(c => `<li style="justify-content:flex-start"><span style="color:${c.ok ? 'var(--ok)' : 'var(--coral)'}">${icon(c.ok ? 'check' : 'x', 18)}</span><span><b class="small">${esc(c.label)}</b>${c.ok ? '' : `<div class="small muted">${esc(c.tip)}</div>`}</span></li>`).join('')}</ul></div>
    </div>
    <div class="grid g2" style="margin-top:18px;align-items:start">
      <div class="card"><h3 style="color:var(--ok)">Strengths</h3><ul class="small" style="padding-left:18px;margin:0">${r.strengths.map(s => `<li>${esc(s)}</li>`).join('') || '<li>Keep practising — strengths will show here.</li>'}</ul>
        <h3 style="color:var(--coral);margin-top:16px">Areas to improve</h3><ul class="small" style="padding-left:18px;margin:0">${r.weaknesses.map(s => `<li>${esc(s)}</li>`).join('') || '<li>No major issues detected by the analyser.</li>'}</ul></div>
      <div class="card"><h3>Grammar & usage</h3>${r.errors.length ? r.errors.map(e => `<div class="issue"><s>${esc(e.from)}</s> → <ins>${esc(e.to)}</ins><div class="tiny muted">${esc(e.why)}</div></div>`).join('') : '<p class="small muted">No common error patterns detected. This check does not catch every mistake — proofread carefully.</p>'}
        ${r.informal.length && !/informal/i.test((w || sub).kind) ? `<p class="small" style="margin-top:10px"><b>Informal language:</b> ${r.informal.map(esc).join(', ')}</p>` : ''}</div>
    </div>
    <div class="grid g2" style="margin-top:18px;align-items:start">
      <div class="card"><h3>Vocabulary suggestions</h3>${r.weakWords.length ? r.weakWords.map(x => `<div class="issue"><b>${esc(x.w)}</b> <span class="tiny muted">used ${x.n}×</span> → <span class="small">${esc(x.alt)}</span></div>`).join('') : '<p class="small muted">No overused basic words detected.</p>'}
        ${r.repeated.length ? `<p class="small" style="margin-top:8px"><b>Most repeated:</b> ${r.repeated.map(([w, n]) => `${esc(w)} (${n})`).join(', ')}</p>` : ''}</div>
      <div class="card"><h3>Sentence & coherence suggestions</h3>
        ${r.longS.map(s => `<div class="issue"><b>Long sentence (${s.split(/\s+/).length} words):</b> “${esc(s.slice(0, 90))}…” — consider splitting it into two.</div>`).join('')}
        ${r.starts.map(s => `<div class="issue"><b>Informal opening:</b> “${esc(s.slice(0, 60))}…” — in formal writing, prefer “Furthermore,” “However,” or “Therefore,”.</div>`).join('')}
        ${Object.keys(r.linkUsed).length ? `<p class="small">Linking used: ${Object.entries(r.linkUsed).map(([g, n]) => `<span class="chip" style="margin:2px">${g} ×${n}</span>`).join('')}</p>` : '<p class="small">No linking words detected — add connectors to show how ideas relate.</p>'}
        ${!r.longS.length && !r.starts.length ? '<p class="small muted">Sentence lengths look balanced.</p>' : ''}</div>
    </div>
    <div class="card" style="margin-top:18px"><h3>${icon('target', 18)} Your improvement plan</h3><ol class="small" style="padding-left:20px;margin:0">${r.plan.map(p => `<li style="margin:5px 0">${esc(p)}</li>`).join('')}</ol></div>`;
  };
  OB.route('/writing-review/:id', ({ id }) => {
    const sub = store.s.writing.find(s => s.id === id); if (!sub) return OB.notFound();
    const w = OB.getWriting(sub.taskId) || sub; const app = OB.page();
    app.innerHTML = `<div class="page-head"><div class="wrap"><div class="crumbs"><a href="#/writing">Writing</a> / <a href="#/writing-history">History</a> / Feedback</div><h1 style="font-size:2rem">${esc(sub.title)}</h1><div class="row"><span class="chip">${esc(sub.kind)}</span><span class="chip">${OB.fmtDate(sub.date)}</span><span class="chip">${sub.words} words</span></div></div></div>
    <div class="wrap fade-in" style="padding-bottom:40px">${OB.writingFeedbackHTML(sub, w)}
      <div class="grid g2" style="margin-top:18px;align-items:start">
        <div class="card"><h3>Self-assessment</h3><p class="small muted">Read your answer again and choose the description that fits best for each criterion. This builds the habit examiners use.</p>
          <form data-self>${CRIT.map(([k, l]) => `<div class="field"><label class="lbl">${l}</label>${SELF[k].map(([b, d]) => `<label class="opt" style="margin-bottom:6px"><input type="radio" name="${k}" value="${b}" ${sub.self && sub.self[k] == b ? 'checked' : ''}><span class="small"><b>Band ${b}:</b> ${esc(d)}</span></label>`).join('')}</div>`).join('')}
          <div class="row between"><div data-selfres class="small"></div><button class="btn btn-primary" type="submit">Save self-assessment</button></div></form></div>
        <div class="card"><div class="row between"><h3 style="margin:0">Your answer</h3><a class="btn btn-sm btn-ghost" href="#/writing/${esc(sub.taskId)}">${icon('refresh', 14)} Write again</a></div><div style="white-space:pre-line;font-family:var(--serif);line-height:1.75;margin-top:12px;max-height:520px;overflow:auto">${esc(sub.text)}</div>
          ${w.sample ? `<details style="margin-top:14px"><summary style="cursor:pointer;font-weight:700">Compare with the sample answer</summary><div style="white-space:pre-line;font-family:var(--serif);line-height:1.75;margin-top:10px">${esc(w.sample)}</div></details>` : ''}</div>
      </div></div>`;
    const f = $('[data-self]', app); const show = () => { if (sub.self) { const b = overallBand(Object.values(sub.self).map(Number)); $('[data-selfres]', app).innerHTML = `Self-assessed band: <span class="band-pill">${bandLabel(b)}</span>`; } }; show();
    f.onsubmit = e => { e.preventDefault(); const d = Object.fromEntries(new FormData(f)); if (Object.keys(d).length < 4) return toast('Choose a band for all four criteria.', 'bad'); sub.self = d; store.save(true); show(); toast('Self-assessment saved.', 'ok'); };
  });
  OB.route('/writing-history', () => {
    const app = OB.page(); const list = store.s.writing; const drafts = Object.entries(store.s.drafts).filter(([, d]) => d.text && d.text.trim());
    app.innerHTML = `<div class="page-head"><div class="wrap"><div class="crumbs"><a href="#/writing">Writing</a> / History</div><h1 style="font-size:2rem">Writing history</h1><p>Your submitted answers and saved drafts are stored in this browser.</p></div></div>
    <div class="wrap" style="padding-bottom:40px">${drafts.length ? `<div class="card" style="margin-bottom:18px"><h3>Saved drafts</h3><ul class="list-clean">${drafts.map(([id, d]) => { const w = OB.getWriting(id); return w ? `<li><span><b>${esc(w.title)}</b> <span class="small muted">· ${(d.text.match(/\S+/g) || []).length} words</span></span><a class="btn btn-sm btn-ghost" href="#/writing/${esc(id)}">Continue</a></li>` : ''; }).join('')}</ul></div>` : ''}
      <div class="card"><h3>Submitted answers</h3>${list.length ? `<ul class="list-clean">${list.map(s => `<li><span><b>${esc(s.title)}</b><br><span class="small muted">${esc(s.kind)} · ${s.words} words · ${OB.fmtDate(s.date)}</span></span><span class="row"><span class="band-pill">${bandLabel(s.est)}</span><a class="btn btn-sm btn-ghost" href="#/writing-review/${s.id}">Feedback</a></span></li>`).join('')}</ul>` : `<div class="empty"><div class="ico">${icon('W', 28)}</div>No submitted answers yet.<br><a class="btn btn-primary" style="margin-top:12px" href="#/writing">Start a writing task</a></div>`}</div></div>`;
  });
})();
