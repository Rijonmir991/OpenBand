/* OpenBand — boot */
(function () {
  OB.applyTheme();
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (!OB.store.s.settings.theme) OB.applyTheme(); });
  OB.shell();
  OB.applyLang();
  OB.render();
})();
