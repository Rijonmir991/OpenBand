/* Original Writing, Speaking, Vocabulary and Grammar content for OpenBand.
   Country names in charts (Northland, Eastmere, Southport) are fictional, so data cannot be mistaken for real statistics. */

window.WRITING = [
  /* ---------- Academic Task 1 ---------- */
  { id: 'WA1-line', track: 'academic', task: 1, kind: 'Line graph', level: 'Intermediate', title: 'Household internet access, 2000–2020',
    prompt: 'The graph below shows the percentage of households with internet access in three countries between 2000 and 2020.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.',
    chart: { kind: 'line', title: 'Households with internet access (%)', x: ['2000', '2005', '2010', '2015', '2020'], unit: '%', max: 100, series: [{ name: 'Northland', v: [32, 55, 74, 88, 95] }, { name: 'Eastmere', v: [12, 25, 48, 70, 86] }, { name: 'Southport', v: [5, 9, 18, 35, 62] }] },
    sample: `The line graph compares the proportion of households that had internet access in Northland, Eastmere and Southport over a twenty-year period from 2000.

Overall, access rose considerably in all three countries. Northland had the highest rate throughout the period, while Southport remained well behind the other two, although it saw the most rapid growth in the final decade.

In 2000, roughly a third of Northland households (32%) were online, compared with 12% in Eastmere and only 5% in Southport. Northland's figure increased steadily, reaching 74% in 2010 and almost universal access, at 95%, by 2020.

Eastmere followed a similar upward trend but started from a lower base. Its rate doubled between 2000 and 2005 to 25%, and then climbed sharply to 70% in 2015, finishing at 86%, less than ten percentage points below Northland.

Southport's growth was slow in the first decade, with access rising to just 18% by 2010. After that, however, the figure accelerated, almost doubling to 35% in 2015 and then reaching 62% in 2020. Despite this rapid increase, the country still lagged behind its neighbours at the end of the period.` },
  { id: 'WA1-bar', track: 'academic', task: 1, kind: 'Bar chart', level: 'Intermediate', title: 'Weekly leisure time by age group',
    prompt: 'The bar chart below shows the average number of hours per week that people in different age groups in Eastmere spent on four leisure activities in 2024.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.',
    chart: { kind: 'bar', title: 'Average hours per week, Eastmere 2024', x: ['16–24', '25–44', '45–64', '65+'], unit: 'h', max: 16, series: [{ name: 'Social media', v: [14, 9, 5, 2] }, { name: 'Watching TV', v: [6, 8, 11, 15] }, { name: 'Sport / exercise', v: [5, 4, 3, 3] }, { name: 'Reading', v: [2, 3, 4, 7] }] } },
  { id: 'WA1-pie', track: 'academic', task: 1, kind: 'Pie chart', level: 'Intermediate', title: 'Electricity sources, 2000 and 2020',
    prompt: 'The pie charts below show the sources of electricity generated in Northland in 2000 and 2020.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.',
    chart: { kind: 'pies', title: 'Electricity generation in Northland', pies: [{ name: '2000', slices: [['Coal', 46], ['Natural gas', 28], ['Nuclear', 18], ['Hydro', 6], ['Wind & solar', 2]] }, { name: '2020', slices: [['Coal', 12], ['Natural gas', 34], ['Nuclear', 16], ['Hydro', 8], ['Wind & solar', 30]] }] } },
  { id: 'WA1-table', track: 'academic', task: 1, kind: 'Table', level: 'Intermediate', title: 'International students at five universities',
    prompt: 'The table below shows the number of international students enrolled at five universities in 2015, 2020 and 2025.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.',
    chart: { kind: 'table', title: 'International students enrolled', head: ['University', '2015', '2020', '2025'], rows: [['Harbour University', '4,200', '5,100', '6,800'], ['Lakeside Institute', '3,900', '3,600', '3,100'], ['Northgate College', '1,200', '2,500', '4,900'], ['St Brendan University', '2,800', '2,900', '3,000'], ['Westfield Tech', '600', '1,100', '1,050']] } },
  { id: 'WA1-map', track: 'academic', task: 1, kind: 'Map', level: 'Advanced', title: 'Changes to Ashford village',
    prompt: 'The maps below show the village of Ashford in 1995 and today.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.',
    chart: { kind: 'maps' } },
  { id: 'WA1-process', track: 'academic', task: 1, kind: 'Process diagram', level: 'Advanced', title: 'Recycling glass bottles',
    prompt: 'The diagram below shows how glass bottles are recycled.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.',
    chart: { kind: 'process', title: 'Glass bottle recycling', steps: ['Collection from homes and bottle banks', 'Transport to recycling plant', 'Sorting by colour (clear, green, brown)', 'Washing to remove labels and dirt', 'Crushing into small pieces (cullet)', 'Melting in a furnace at 1,500°C', 'Moulding into new bottles', 'Filling and delivery to shops'] } },
  { id: 'WA1-mixed', track: 'academic', task: 1, kind: 'Mixed charts', level: 'Advanced', title: 'Rainfall and water use in Southport',
    prompt: 'The bar chart shows average monthly rainfall in Southport, and the pie chart shows how water was used in the country in 2023.\n\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.',
    chart: { kind: 'mixed', bar: { kind: 'bar', title: 'Average rainfall (mm)', x: ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'], unit: 'mm', max: 300, series: [{ name: 'Rainfall', v: [12, 18, 35, 80, 160, 260, 290, 240, 170, 90, 25, 10] }] }, pie: { name: 'Water use, 2023', slices: [['Agriculture', 68], ['Industry', 19], ['Households', 13]] } } },
  /* ---------- Academic Task 2 ---------- */
  { id: 'WA2-opinion', track: 'academic', task: 2, kind: 'Opinion essay', level: 'Intermediate', title: 'Free university education',
    prompt: 'Some people believe that university education should be free for all students, regardless of their background.\n\nTo what extent do you agree or disagree?\n\nGive reasons for your answer and include any relevant examples from your own knowledge or experience.',
    sample: `Whether higher education should be paid for by the state or by students themselves is a long-standing debate. In my view, university tuition should be free for most students, although I accept that some limits are necessary.

The strongest argument for free university education is fairness. When students must pay high fees, talented young people from poorer families are often discouraged from applying, or they leave university with debts that shape their career choices for years. A country that makes education free allows people to progress on the basis of ability rather than family income. In Bangladesh, for example, many of the most successful graduates of public universities come from rural families that could never have paid private tuition.

Free education also benefits society as a whole. Graduates generally earn more and therefore pay more tax over their lifetimes, which helps to repay the initial investment. Moreover, a well-educated workforce attracts employers and encourages innovation, so the advantages are not limited to the individual student.

Nevertheless, completely free education for everyone would be extremely expensive, and governments have to balance it against other priorities such as healthcare and primary schools. For this reason, I believe free places should be linked to academic performance, and that courses with very low employment rates should be reviewed. Wealthy families could also be asked to contribute through a modest fee.

In conclusion, I largely agree that university education should be free, because it promotes equal opportunity and brings long-term economic benefits. However, to be sustainable, such a system should include sensible conditions rather than being entirely unlimited.` },
  { id: 'WA2-discuss', track: 'academic', task: 2, kind: 'Discussion essay', level: 'Intermediate', title: 'When should children start school?',
    prompt: 'Some people think children should start formal schooling at a very early age, while others believe they should not begin until they are at least seven years old.\n\nDiscuss both views and give your own opinion.' },
  { id: 'WA2-advdis', track: 'academic', task: 2, kind: 'Advantages & disadvantages', level: 'Intermediate', title: 'Working from home',
    prompt: 'More and more people are working from home rather than travelling to an office.\n\nDo the advantages of this development outweigh the disadvantages?' },
  { id: 'WA2-problem', track: 'academic', task: 2, kind: 'Problem & solution', level: 'Beginner', title: 'Traffic congestion in cities',
    prompt: 'In many cities, traffic congestion is becoming a serious problem.\n\nWhat are the causes of this problem, and what measures could be taken to solve it?' },
  { id: 'WA2-twopart', track: 'academic', task: 2, kind: 'Two-part question', level: 'Advanced', title: 'Young people and self-employment',
    prompt: 'Many young people today would prefer to work for themselves rather than for a company.\n\nWhy is this the case? Is this a positive or a negative development?' },
  /* ---------- General Training ---------- */
  { id: 'WG1-formal', track: 'general', task: 1, kind: 'Formal letter', level: 'Beginner', title: 'Complaint about a damaged washing machine',
    prompt: 'You recently bought a washing machine from an online store, but it was damaged when it was delivered.\n\nWrite a letter to the company. In your letter:\n• describe the damage\n• explain what happened when you contacted customer service\n• say what you would like the company to do\n\nBegin your letter as follows: Dear Sir or Madam,',
    sample: `Dear Sir or Madam,

I am writing to complain about a washing machine I ordered from your website on 3 November (order number 48213), which arrived in a damaged condition.

When the machine was delivered on 7 November, the box was torn, and after unpacking it I found that the door was cracked and one of the feet had broken off. As a result, the machine cannot be used safely. I took photographs of the damage, which I have attached to this letter.

On the same day, I telephoned your customer service department. After waiting for almost forty minutes, I spoke to an assistant who promised that someone would call me back within 24 hours to arrange a collection. Unfortunately, nobody has contacted me since, and my two follow-up emails have not received a reply.

I would therefore like you to collect the damaged machine and deliver a replacement within the next seven days. If this is not possible, I would expect a full refund, including the delivery charge.

I look forward to your prompt response.

Yours faithfully,
Rahim Uddin` },
  { id: 'WG1-semi', track: 'general', task: 1, kind: 'Semi-formal letter', level: 'Beginner', title: 'Noise from a neighbour',
    prompt: 'Your neighbour has recently been playing loud music late at night.\n\nWrite a letter to your neighbour. In your letter:\n• explain the situation\n• describe how it is affecting you\n• suggest a solution\n\nBegin your letter as follows: Dear …,' },
  { id: 'WG1-informal', track: 'general', task: 1, kind: 'Informal letter', level: 'Beginner', title: "Can't attend a friend's wedding",
    prompt: 'A friend has invited you to their wedding, but you cannot attend.\n\nWrite a letter to your friend. In your letter:\n• congratulate your friend\n• explain why you cannot attend\n• suggest how you could celebrate together later\n\nBegin your letter as follows: Dear …,' },
  { id: 'WG2-social', track: 'general', task: 2, kind: 'Essay (discussion)', level: 'Intermediate', title: 'Social media and relationships',
    prompt: 'Some people say that social media brings people closer together, while others believe it makes people more isolated.\n\nDiscuss both views and give your own opinion.' },
  { id: 'WG2-ageing', track: 'general', task: 2, kind: 'Essay (problem & solution)', level: 'Intermediate', title: 'Ageing populations',
    prompt: 'In many countries, people are living longer than ever before.\n\nWhat problems does this cause, and how can they be solved?' }
];

window.SPEAKING = {
  part1: [
    { topic: 'Work or study', qs: ['Do you work or are you a student?', 'What do you like most about your studies or job?', 'Is there anything you would like to change about it?', 'Do you plan to continue in the same field in the future?'] },
    { topic: 'Hometown', qs: ['Where is your hometown?', 'What do you like about living there?', 'How has your hometown changed in recent years?', 'Would you recommend it to tourists? Why?'] },
    { topic: 'Daily routine', qs: ['What is your daily routine like?', 'Which part of the day do you like most?', 'Do you prefer mornings or evenings?', 'Has your routine changed since you were a child?'] },
    { topic: 'Hobbies', qs: ['What do you like to do in your free time?', 'How long have you had this hobby?', 'Do you prefer hobbies you do alone or with others?', 'Is there a new hobby you would like to try?'] },
    { topic: 'Family', qs: ['Do you have a large or small family?', 'Who are you closest to in your family?', 'What do you usually do together as a family?', 'Do you think families are less close than in the past?'] },
    { topic: 'Travel', qs: ['Do you enjoy travelling?', 'Where did you go on your last trip?', 'Do you prefer travelling alone or in a group?', 'Which country would you most like to visit?'] },
    { topic: 'Technology', qs: ['How often do you use your mobile phone?', 'Which apps do you use most?', 'Could you live without the internet for a week?', 'Has technology made your life easier?'] },
    { topic: 'Food', qs: ['What is your favourite food?', 'Do you prefer eating at home or in restaurants?', 'Can you cook?', 'Is there any food you did not like as a child but enjoy now?'] },
    { topic: 'Weather', qs: ['What is the weather like where you live?', 'What is your favourite season?', 'Does the weather affect your mood?', 'Do you check the weather forecast often?'] },
    { topic: 'Music', qs: ['What kind of music do you like?', 'Did you learn to play an instrument as a child?', 'When do you usually listen to music?', 'Has your taste in music changed over time?'] }
  ],
  cards: [
    { id: 'c1', title: 'Describe a person who has had a positive influence on you.', bullets: ['who this person is', 'how you know them', 'what they have done for you'], end: 'and explain why their influence has been important to you.', p3: ['What qualities make a good role model?', 'Do celebrities have a positive or negative influence on young people?', 'How has the role of teachers changed in recent years?', 'Should parents be the most important influence on children?'] },
    { id: 'c2', title: 'Describe a place you visited that you would like to go back to.', bullets: ['where it is', 'when you went there', 'what you did there'], end: 'and explain why you would like to return.', p3: ['Why do people like to visit the same places again?', 'How does tourism affect local communities?', 'Will people travel more or less in the future?', 'Is it better to travel in your own country or abroad?'] },
    { id: 'c3', title: 'Describe a skill you learned that you think is useful.', bullets: ['what the skill is', 'when and how you learned it', 'how often you use it'], end: 'and explain why you think it is useful.', p3: ['What skills should schools teach that they do not teach now?', 'Is it easier to learn skills when you are young?', 'Will practical skills become less important because of technology?', 'How do people learn new skills at work?'] },
    { id: 'c4', title: 'Describe a book or film that made a strong impression on you.', bullets: ['what it was', 'when you read or watched it', 'what it was about'], end: 'and explain why it made such an impression.', p3: ['Do people read fewer books than in the past?', 'Should films based on books stay close to the original?', 'What can children learn from stories?', 'Why are some films popular all over the world?'] },
    { id: 'c5', title: 'Describe a time when you helped someone.', bullets: ['who you helped', 'what the situation was', 'how you helped them'], end: 'and explain how you felt afterwards.', p3: ['Why do some people enjoy volunteering?', 'Should schools require students to do community work?', 'Are people today less willing to help strangers?', 'What role should governments play in helping people in need?'] },
    { id: 'c6', title: 'Describe a piece of technology you find useful.', bullets: ['what it is', 'when you started using it', 'what you use it for'], end: 'and explain why it is useful to you.', p3: ['How has technology changed the way people communicate?', 'Are older people disadvantaged by new technology?', 'Should children be allowed to use smartphones?', 'What technology will be important in the next twenty years?'] },
    { id: 'c7', title: 'Describe a festival or celebration that is important in your country.', bullets: ['what it is called', 'when it takes place', 'what people do during it'], end: 'and explain why it is important.', p3: ['Why are traditional festivals important?', 'Are festivals becoming too commercial?', 'How do young people celebrate differently from older people?', 'Should schools teach children about other cultures\' festivals?'] },
    { id: 'c8', title: 'Describe a goal you would like to achieve in the future.', bullets: ['what the goal is', 'when you set this goal', 'what you need to do to achieve it'], end: 'and explain why this goal is important to you.', p3: ['Is it important for young people to have clear goals?', 'Do people\'s goals change as they get older?', 'What makes some people more successful than others?', 'Should success be measured by money?'] },
    { id: 'c9', title: 'Describe an occasion when you had to wait for a long time.', bullets: ['when and where it was', 'what you were waiting for', 'what you did while you were waiting'], end: 'and explain how you felt about waiting.', p3: ['Why are people less patient today?', 'In what situations is patience most important?', 'How could public services reduce waiting times?', 'Is technology making people more impatient?'] },
    { id: 'c10', title: 'Describe a park or garden you enjoy visiting.', bullets: ['where it is', 'what it looks like', 'what people do there'], end: 'and explain why you enjoy going there.', p3: ['Why are green spaces important in cities?', 'Should building more homes be more important than keeping parks?', 'How can cities encourage people to spend time outdoors?', 'Do children spend less time outside than in the past?'] },
    { id: 'c11', title: 'Describe a decision you made that changed your life.', bullets: ['what the decision was', 'when you made it', 'how you made it'], end: 'and explain how it changed your life.', p3: ['Do young people make decisions differently from older people?', 'Should parents decide what their children study?', 'Is it better to make decisions quickly or slowly?', 'Why do some people find it hard to make decisions?'] },
    { id: 'c12', title: 'Describe a meal you enjoyed with other people.', bullets: ['where and when it was', 'who you were with', 'what you ate'], end: 'and explain why you enjoyed it.', p3: ['Why is eating together important for families?', 'How have eating habits changed in your country?', 'Is fast food a serious health problem?', 'Should schools teach children how to cook?'] }
  ]
};

window.VOCAB = [
  // Environment
  { w: 'sustainable', pos: 'adj', topic: 'Environment', m: 'able to continue for a long time without damaging the environment', bn: 'টেকসই', ex: 'Governments should invest in sustainable forms of transport.', syn: ['eco-friendly', 'renewable'], ant: ['unsustainable'] },
  { w: 'deplete', pos: 'v', topic: 'Environment', m: 'to reduce the amount of something until little remains', bn: 'নিঃশেষ করা', ex: 'Overfishing has severely depleted fish stocks.', syn: ['exhaust', 'use up'], ant: ['replenish'] },
  { w: 'emission', pos: 'n', topic: 'Environment', m: 'gas or other substance sent into the air', bn: 'নির্গমন', ex: 'Carbon emissions from cars contribute to climate change.', syn: ['discharge', 'release'], ant: ['absorption'] },
  { w: 'biodiversity', pos: 'n', topic: 'Environment', m: 'the variety of plants and animals in a particular place', bn: 'জীববৈচিত্র্য', ex: 'Deforestation is a major threat to biodiversity.', syn: ['variety of life'], ant: [] },
  { w: 'mitigate', pos: 'v', topic: 'Environment', m: 'to make something bad less severe', bn: 'প্রশমিত করা', ex: 'Planting trees can help mitigate the effects of flooding.', syn: ['reduce', 'alleviate'], ant: ['aggravate', 'worsen'] },
  { w: 'contaminate', pos: 'v', topic: 'Environment', m: 'to make something dirty or harmful by adding a substance', bn: 'দূষিত করা', ex: 'Factory waste has contaminated the river.', syn: ['pollute', 'poison'], ant: ['purify'] },
  { w: 'renewable', pos: 'adj', topic: 'Environment', m: 'able to be replaced naturally', bn: 'নবায়নযোগ্য', ex: 'Solar power is a renewable source of energy.', syn: ['sustainable'], ant: ['finite', 'non-renewable'] },
  { w: 'degradation', pos: 'n', topic: 'Environment', m: 'the process of something becoming worse in condition', bn: 'অবক্ষয়', ex: 'Land degradation reduces agricultural productivity.', syn: ['deterioration', 'decline'], ant: ['improvement'] },
  // Education
  { w: 'curriculum', pos: 'n', topic: 'Education', m: 'the subjects taught in a school or course', bn: 'পাঠ্যক্রম', ex: 'Coding has been added to the primary school curriculum.', syn: ['syllabus', 'programme'], ant: [] },
  { w: 'literacy', pos: 'n', topic: 'Education', m: 'the ability to read and write', bn: 'সাক্ষরতা', ex: 'Adult literacy rates have risen sharply.', syn: ['reading ability'], ant: ['illiteracy'] },
  { w: 'vocational', pos: 'adj', topic: 'Education', m: 'related to skills needed for a particular job', bn: 'বৃত্তিমূলক', ex: 'Vocational training can reduce youth unemployment.', syn: ['practical', 'job-related'], ant: ['academic'] },
  { w: 'compulsory', pos: 'adj', topic: 'Education', m: 'required by a rule or law', bn: 'বাধ্যতামূলক', ex: 'Education is compulsory until the age of sixteen.', syn: ['mandatory', 'obligatory'], ant: ['optional', 'voluntary'] },
  { w: 'rote learning', pos: 'n', topic: 'Education', m: 'learning by repetition rather than understanding', bn: 'মুখস্থবিদ্যা', ex: 'Rote learning does little to develop critical thinking.', syn: ['memorisation'], ant: ['critical thinking'] },
  { w: 'tuition', pos: 'n', topic: 'Education', m: 'teaching, or the money paid for it', bn: 'টিউশন / শিক্ষাদান ফি', ex: 'Tuition fees have increased at many universities.', syn: ['instruction', 'fees'], ant: [] },
  { w: 'aptitude', pos: 'n', topic: 'Education', m: 'a natural ability to do something', bn: 'স্বাভাবিক দক্ষতা / প্রবণতা', ex: 'She showed an early aptitude for mathematics.', syn: ['talent', 'flair'], ant: ['inability'] },
  { w: 'discipline', pos: 'n', topic: 'Education', m: 'controlled behaviour; also a subject of study', bn: 'শৃঙ্খলা', ex: 'Strict discipline is not always effective in schools.', syn: ['self-control', 'order'], ant: ['disorder'] },
  // Technology
  { w: 'innovation', pos: 'n', topic: 'Technology', m: 'a new idea, method or invention', bn: 'উদ্ভাবন', ex: 'Technological innovation drives economic growth.', syn: ['invention', 'breakthrough'], ant: ['stagnation'] },
  { w: 'obsolete', pos: 'adj', topic: 'Technology', m: 'no longer used because something newer exists', bn: 'অপ্রচলিত', ex: 'Many jobs may become obsolete because of automation.', syn: ['outdated', 'redundant'], ant: ['modern', 'current'] },
  { w: 'automation', pos: 'n', topic: 'Technology', m: 'the use of machines to do work that people did', bn: 'স্বয়ংক্রিয়করণ', ex: 'Automation has transformed the manufacturing industry.', syn: ['mechanisation'], ant: ['manual work'] },
  { w: 'privacy', pos: 'n', topic: 'Technology', m: 'the right to keep personal information secret', bn: 'গোপনীয়তা', ex: 'Social media raises serious concerns about privacy.', syn: ['confidentiality'], ant: ['exposure'] },
  { w: 'breakthrough', pos: 'n', topic: 'Technology', m: 'an important new discovery', bn: 'যুগান্তকারী আবিষ্কার', ex: 'The vaccine was a major medical breakthrough.', syn: ['advance', 'discovery'], ant: ['setback'] },
  { w: 'accessible', pos: 'adj', topic: 'Technology', m: 'easy to reach, obtain or use', bn: 'সহজলভ্য', ex: 'The internet has made information accessible to millions.', syn: ['available', 'reachable'], ant: ['inaccessible'] },
  { w: 'reliance', pos: 'n', topic: 'Technology', m: 'the state of depending on something', bn: 'নির্ভরশীলতা', ex: 'Our reliance on smartphones is increasing.', syn: ['dependence'], ant: ['independence'] },
  { w: 'cutting-edge', pos: 'adj', topic: 'Technology', m: 'the most modern and advanced', bn: 'অত্যাধুনিক', ex: 'The hospital uses cutting-edge equipment.', syn: ['state-of-the-art', 'advanced'], ant: ['outdated'] },
  // Health
  { w: 'sedentary', pos: 'adj', topic: 'Health', m: 'involving a lot of sitting and little exercise', bn: 'বসে থাকা / অলস (জীবনযাপন)', ex: 'A sedentary lifestyle increases the risk of heart disease.', syn: ['inactive'], ant: ['active'] },
  { w: 'obesity', pos: 'n', topic: 'Health', m: 'the condition of being very overweight', bn: 'স্থূলতা', ex: 'Childhood obesity has become a global concern.', syn: ['excess weight'], ant: [] },
  { w: 'preventive', pos: 'adj', topic: 'Health', m: 'intended to stop something bad from happening', bn: 'প্রতিরোধমূলক', ex: 'Preventive healthcare is cheaper than treatment.', syn: ['precautionary'], ant: ['curative'] },
  { w: 'nutritious', pos: 'adj', topic: 'Health', m: 'containing substances the body needs to be healthy', bn: 'পুষ্টিকর', ex: 'Schools should provide nutritious meals.', syn: ['healthy', 'wholesome'], ant: ['unhealthy'] },
  { w: 'well-being', pos: 'n', topic: 'Health', m: 'the state of being healthy and happy', bn: 'সুস্থতা / কল্যাণ', ex: 'Regular exercise improves mental well-being.', syn: ['welfare', 'wellness'], ant: [] },
  { w: 'epidemic', pos: 'n', topic: 'Health', m: 'a disease that spreads quickly among many people', bn: 'মহামারী', ex: 'Diabetes is described as a modern epidemic.', syn: ['outbreak'], ant: [] },
  { w: 'life expectancy', pos: 'n', topic: 'Health', m: 'the number of years a person is expected to live', bn: 'গড় আয়ু', ex: 'Life expectancy has risen in most countries.', syn: ['lifespan'], ant: [] },
  // Work & Economy
  { w: 'unemployment', pos: 'n', topic: 'Work', m: 'the state of not having a job', bn: 'বেকারত্ব', ex: 'Youth unemployment remains high in many regions.', syn: ['joblessness'], ant: ['employment'] },
  { w: 'incentive', pos: 'n', topic: 'Work', m: 'something that encourages a person to do something', bn: 'প্রণোদনা', ex: 'Tax incentives encourage companies to invest.', syn: ['motivation', 'encouragement'], ant: ['deterrent'] },
  { w: 'productivity', pos: 'n', topic: 'Work', m: 'the rate at which work is done', bn: 'উৎপাদনশীলতা', ex: 'Flexible hours can increase productivity.', syn: ['efficiency', 'output'], ant: [] },
  { w: 'entrepreneur', pos: 'n', topic: 'Work', m: 'a person who starts a business', bn: 'উদ্যোক্তা', ex: 'Young entrepreneurs often struggle to find funding.', syn: ['business founder'], ant: ['employee'] },
  { w: 'remuneration', pos: 'n', topic: 'Work', m: 'payment for work', bn: 'পারিশ্রমিক', ex: 'Teachers deserve better remuneration.', syn: ['salary', 'pay'], ant: [] },
  { w: 'work-life balance', pos: 'n', topic: 'Work', m: 'the balance between time spent working and personal life', bn: 'কাজ ও জীবনের ভারসাম্য', ex: 'Remote work can improve work-life balance.', syn: [], ant: [] },
  { w: 'lucrative', pos: 'adj', topic: 'Work', m: 'producing a lot of money', bn: 'লাভজনক', ex: 'Software engineering is a lucrative career.', syn: ['profitable'], ant: ['unprofitable'] },
  // Society
  { w: 'inequality', pos: 'n', topic: 'Society', m: 'an unfair situation in which some people have more than others', bn: 'বৈষম্য', ex: 'Income inequality has widened in recent decades.', syn: ['disparity', 'imbalance'], ant: ['equality'] },
  { w: 'urbanisation', pos: 'n', topic: 'Society', m: 'the movement of people from rural areas to cities', bn: 'নগরায়ণ', ex: 'Rapid urbanisation puts pressure on housing.', syn: ['city growth'], ant: ['ruralisation'] },
  { w: 'infrastructure', pos: 'n', topic: 'Society', m: 'basic systems such as roads, water and power', bn: 'অবকাঠামো', ex: 'Investment in infrastructure creates jobs.', syn: ['facilities'], ant: [] },
  { w: 'legislation', pos: 'n', topic: 'Society', m: 'laws, or the process of making them', bn: 'আইন প্রণয়ন', ex: 'New legislation bans single-use plastic bags.', syn: ['law', 'regulation'], ant: [] },
  { w: 'detrimental', pos: 'adj', topic: 'Society', m: 'causing harm or damage', bn: 'ক্ষতিকর', ex: 'Excessive screen time can be detrimental to children.', syn: ['harmful', 'damaging'], ant: ['beneficial'] },
  { w: 'cohesion', pos: 'n', topic: 'Society', m: 'the state of a group being united', bn: 'সংহতি', ex: 'Community events strengthen social cohesion.', syn: ['unity', 'solidarity'], ant: ['division'] },
  { w: 'marginalised', pos: 'adj', topic: 'Society', m: 'treated as unimportant and excluded from society', bn: 'প্রান্তিক', ex: 'Policies should support marginalised groups.', syn: ['excluded', 'disadvantaged'], ant: ['privileged'] },
  // Academic Word List style
  { w: 'significant', pos: 'adj', topic: 'Academic', m: 'large or important enough to be noticed', bn: 'উল্লেখযোগ্য', ex: 'There was a significant increase in sales.', syn: ['considerable', 'substantial'], ant: ['negligible', 'minor'] },
  { w: 'fluctuate', pos: 'v', topic: 'Academic', m: 'to rise and fall irregularly', bn: 'ওঠানামা করা', ex: 'Oil prices fluctuated throughout the year.', syn: ['vary', 'oscillate'], ant: ['stabilise'] },
  { w: 'subsequently', pos: 'adv', topic: 'Academic', m: 'after something else happened', bn: 'পরবর্তীতে', ex: 'Sales fell in 2019 and subsequently recovered.', syn: ['later', 'afterwards'], ant: ['previously'] },
  { w: 'predominantly', pos: 'adv', topic: 'Academic', m: 'mostly or mainly', bn: 'প্রধানত', ex: 'The workforce is predominantly young.', syn: ['mainly', 'largely'], ant: ['rarely'] },
  { w: 'comprise', pos: 'v', topic: 'Academic', m: 'to consist of or be made up of', bn: 'গঠিত হওয়া / অন্তর্ভুক্ত করা', ex: 'The committee comprises eight members.', syn: ['consist of', 'include'], ant: [] },
  { w: 'phenomenon', pos: 'n', topic: 'Academic', m: 'something that exists or happens, especially something unusual', bn: 'ঘটনা / প্রপঞ্চ', ex: 'Global warming is a complex phenomenon.', syn: ['occurrence', 'event'], ant: [] },
  { w: 'controversial', pos: 'adj', topic: 'Academic', m: 'causing disagreement or discussion', bn: 'বিতর্কিত', ex: 'Animal testing remains a controversial issue.', syn: ['debatable', 'contentious'], ant: ['uncontroversial'] },
  { w: 'feasible', pos: 'adj', topic: 'Academic', m: 'possible and practical to do', bn: 'বাস্তবায়নযোগ্য', ex: 'Free public transport may not be financially feasible.', syn: ['practicable', 'viable'], ant: ['impractical'] },
  { w: 'inevitable', pos: 'adj', topic: 'Academic', m: 'certain to happen and impossible to avoid', bn: 'অনিবার্য', ex: 'Some job losses are inevitable.', syn: ['unavoidable'], ant: ['avoidable'] },
  { w: 'advocate', pos: 'v', topic: 'Academic', m: 'to publicly support an idea', bn: 'সমর্থন করা / পক্ষে বলা', ex: 'Many experts advocate a four-day working week.', syn: ['support', 'champion'], ant: ['oppose'] }
];

window.COLLOCATIONS = [
  { q: '___ a decision', opts: ['make', 'do', 'take part'], a: 'make' }, { q: '___ research', opts: ['do', 'make', 'have'], a: 'do' },
  { q: '___ an effort', opts: ['make', 'do', 'give'], a: 'make' }, { q: 'pose a ___', opts: ['threat', 'danger', 'harm'], a: 'threat' },
  { q: 'a ___ increase', opts: ['sharp', 'strong', 'tall'], a: 'sharp' }, { q: '___ a conclusion', opts: ['reach', 'arrive', 'get'], a: 'reach' },
  { q: 'heavy ___', opts: ['traffic', 'crowd', 'noise'], a: 'traffic' }, { q: '___ attention to', opts: ['pay', 'give', 'make'], a: 'pay' },
  { q: 'raise ___', opts: ['awareness', 'knowledge', 'attention'], a: 'awareness' }, { q: 'a ___ role', opts: ['crucial', 'big', 'strong'], a: 'crucial' },
  { q: '___ a problem', opts: ['tackle', 'fight', 'beat'], a: 'tackle' }, { q: 'meet the ___', opts: ['demand', 'request', 'want'], a: 'demand' }
];

window.CONNECTORS = [
  { g: 'Adding information', w: ['Furthermore,', 'Moreover,', 'In addition,', 'Not only … but also', 'Besides this,'] },
  { g: 'Contrasting', w: ['However,', 'Nevertheless,', 'On the other hand,', 'Although / Even though', 'Whereas', 'In contrast,'] },
  { g: 'Cause and effect', w: ['As a result,', 'Consequently,', 'Therefore,', 'This leads to …', 'Owing to / Due to'] },
  { g: 'Giving examples', w: ['For example,', 'For instance,', 'such as', 'A clear example of this is …', 'This is illustrated by …'] },
  { g: 'Stating opinion', w: ['In my view,', 'I firmly believe that …', 'From my perspective,', 'It seems to me that …'] },
  { g: 'Concluding', w: ['In conclusion,', 'To sum up,', 'Overall,', 'All things considered,'] },
  { g: 'Task 1 trends', w: ['rose steadily', 'fell sharply', 'peaked at', 'levelled off', 'fluctuated between', 'remained stable at', 'accounted for'] }
];

window.EXPRESSIONS = [
  { e: 'It is widely believed that …', use: 'Introducing a common opinion (Task 2 introduction)' },
  { e: 'There is no doubt that …', use: 'Making a strong claim' },
  { e: 'A significant drawback of … is that …', use: 'Introducing a disadvantage' },
  { e: 'This is particularly true in …', use: 'Narrowing a point to a context' },
  { e: 'One possible solution would be to …', use: 'Proposing solutions' },
  { e: 'The figure stood at … before rising to …', use: 'Describing data (Task 1)' },
  { e: 'That\'s an interesting question. I\'ve never really thought about it, but …', use: 'Buying time in Speaking' },
  { e: 'What I mean is …', use: 'Clarifying in Speaking' }
];

window.PARAPHRASE = [
  { s: 'The number of people living in cities has increased significantly.', models: ['The urban population has risen considerably.', 'There has been a substantial growth in the number of city dwellers.'] },
  { s: 'Many students find it difficult to pay for higher education.', models: ['University fees are unaffordable for a large number of students.', 'Paying for tertiary education is a struggle for many learners.'] },
  { s: 'Children spend too much time using electronic devices.', models: ['Young people devote excessive time to screens.', 'Screen time among children has become excessive.'] },
  { s: 'The government should do more to protect the environment.', models: ['The authorities ought to take stronger measures to safeguard nature.', 'More environmental protection is needed from the state.'] },
  { s: 'Working from home has both benefits and drawbacks.', models: ['Remote working has advantages as well as disadvantages.', 'There are pros and cons to working remotely.'] }
];

window.SENTENCE_FIX = [
  { weak: 'Nowadays there are a lot of people who think that technology is very good.', better: 'Many people today regard technology as highly beneficial.', tip: 'Avoid “a lot of” and “very good” — use precise vocabulary and a shorter structure.' },
  { weak: 'Pollution is bad. It makes people sick. Governments must stop it.', better: 'Since pollution damages public health, governments must take action to reduce it.', tip: 'Combine short sentences with subordinating conjunctions such as “since” or “because”.' },
  { weak: 'In my opinion I think that students should wear uniforms.', better: 'In my opinion, students should wear uniforms.', tip: '“In my opinion” and “I think” say the same thing — use one.' },
  { weak: 'The graph shows the sales went up and up until 2010.', better: 'The graph shows that sales rose steadily until 2010.', tip: 'Use Task 1 trend language: rose steadily, climbed, increased gradually.' },
  { weak: 'There are many advantages and also there are many disadvantages.', better: 'This development has both advantages and disadvantages.', tip: 'Use “both … and” to avoid repetition.' }
];

window.GRAMMAR = [
  { id: 'tenses', title: 'Tenses', lesson: 'Use the <b>present perfect</b> for actions connecting past and present (<i>Sales have risen since 2010</i>). Use the <b>past simple</b> for finished time periods (<i>Sales rose in 2010</i>). In Task 1, use the tense that matches the dates shown; for future projections, use <i>is expected to / is predicted to</i>.',
    ex: [
      { q: 'The population ___ steadily since 1990.', opts: ['grew', 'has grown', 'is growing'], a: 'has grown', why: '“since 1990” links past to present → present perfect.' },
      { q: 'In 2005, the company ___ 500 employees.', opts: ['has had', 'had', 'has'], a: 'had', why: 'A finished time (2005) → past simple.' },
      { q: 'By 2030, sales ___ to double.', opts: ['are expected', 'expected', 'have expected'], a: 'are expected', why: 'Future projection → “are expected to”.' },
      { q: 'I ___ English for three years now.', opts: ['study', 'am studying', 'have been studying'], a: 'have been studying', why: 'Ongoing action up to now with a duration → present perfect continuous.' },
      { q: 'While I ___ dinner, the phone rang.', opts: ['cooked', 'was cooking', 'have cooked'], a: 'was cooking', why: 'Background action interrupted → past continuous.' }
    ] },
  { id: 'articles', title: 'Articles (a, an, the)', lesson: 'Use <b>a/an</b> for one non-specific countable noun. Use <b>the</b> when the reader knows which one, for unique things (<i>the internet, the environment</i>), and with superlatives. Use <b>no article</b> for general plural or uncountable nouns (<i>Children need education</i>).',
    ex: [
      { q: '___ environment is under threat from pollution.', opts: ['An', 'The', '—'], a: 'The', why: '“the environment” is a unique, shared reference.' },
      { q: 'She is ___ honest person.', opts: ['a', 'an', 'the'], a: 'an', why: '“honest” begins with a vowel sound (silent h).' },
      { q: '___ education is important for every child.', opts: ['The', 'An', '—'], a: '—', why: 'Uncountable noun used in a general sense → no article.' },
      { q: 'It was ___ best decision I have ever made.', opts: ['a', 'the', '—'], a: 'the', why: 'Superlatives take “the”.' },
      { q: 'He wants to become ___ university lecturer.', opts: ['a', 'an', 'the'], a: 'a', why: '“university” begins with a /j/ consonant sound.' }
    ] },
  { id: 'prepositions', title: 'Prepositions', lesson: 'Learn fixed combinations: <i>an increase <b>in</b> sales, increased <b>by</b> 10%, increased <b>to</b> 50%, depend <b>on</b>, responsible <b>for</b>, interested <b>in</b>, at the end <b>of</b></i>.',
    ex: [
      { q: 'There was a sharp increase ___ the number of tourists.', opts: ['of', 'in', 'on'], a: 'in', why: 'an increase IN something.' },
      { q: 'Profits rose ___ 15% (the size of the change).', opts: ['by', 'to', 'at'], a: 'by', why: '“by” shows the amount of change.' },
      { q: 'Profits rose ___ $2 million (the final figure).', opts: ['by', 'to', 'at'], a: 'to', why: '“to” shows the final level.' },
      { q: 'Success often depends ___ hard work.', opts: ['of', 'from', 'on'], a: 'on', why: 'depend ON.' },
      { q: 'Parents are responsible ___ their children\'s safety.', opts: ['for', 'of', 'about'], a: 'for', why: 'responsible FOR.' }
    ] },
  { id: 'sva', title: 'Subject–verb agreement', lesson: 'The verb must agree with the <b>head noun</b>, not the nearest noun: <i>The number of students <b>has</b> increased</i> (head noun = number). But <i>A number of students <b>have</b> complained</i> (= many students). Uncountable nouns take singular verbs: <i>information is, advice is</i>.',
    ex: [
      { q: 'The number of cars on the roads ___ increased.', opts: ['have', 'has'], a: 'has', why: 'Head noun “number” is singular.' },
      { q: 'A number of students ___ complained about the fees.', opts: ['has', 'have'], a: 'have', why: '“A number of” = many → plural.' },
      { q: 'The information you gave me ___ very useful.', opts: ['was', 'were'], a: 'was', why: '“information” is uncountable.' },
      { q: 'Each of the participants ___ a certificate.', opts: ['receive', 'receives'], a: 'receives', why: '“Each” is singular.' },
      { q: 'Neither the teacher nor the students ___ ready.', opts: ['was', 'were'], a: 'were', why: 'With neither…nor, the verb agrees with the nearer subject (students).' }
    ] },
  { id: 'complex', title: 'Complex sentences', lesson: 'Band 7+ writing uses a mix of simple and complex sentences. Join ideas with <b>although, while, whereas, because, unless, which, who</b>. Example: <i>Although remote work saves time, it can make employees feel isolated.</i>',
    ex: [
      { q: '___ the weather was bad, the match continued.', opts: ['Despite', 'Although', 'Because'], a: 'Although', why: '“Although” + clause; “Despite” needs a noun.' },
      { q: 'Cities, ___ are growing rapidly, need better transport.', opts: ['that', 'which', 'who'], a: 'which', why: 'Non-defining relative clause about things → “which”.' },
      { q: 'You will not improve ___ you practise regularly.', opts: ['unless', 'if', 'although'], a: 'unless', why: '“unless” = if not.' },
      { q: 'Some people prefer cities, ___ others prefer the countryside.', opts: ['whereas', 'because', 'so'], a: 'whereas', why: '“whereas” shows contrast between two groups.' },
      { q: '___ the high cost, many families choose private schools.', opts: ['Although', 'In spite of', 'Even'], a: 'In spite of', why: '“In spite of” + noun phrase.' }
    ] },
  { id: 'conditionals', title: 'Conditionals & sentence structures', lesson: 'Use the <b>second conditional</b> for hypothetical ideas in essays: <i>If governments invested more in public transport, fewer people would drive.</i> Use the <b>first conditional</b> for real possibilities: <i>If you practise daily, you will improve.</i>',
    ex: [
      { q: 'If governments ___ more in public transport, traffic would decrease.', opts: ['invest', 'invested', 'will invest'], a: 'invested', why: 'Second conditional: if + past simple, would + verb.' },
      { q: 'If you practise every day, you ___ improve.', opts: ['would', 'will', 'had'], a: 'will', why: 'First conditional: real possibility.' },
      { q: 'If I ___ known about the test, I would have prepared.', opts: ['have', 'had', 'would'], a: 'had', why: 'Third conditional: if + past perfect.' },
      { q: 'Not only ___ expensive, but it is also slow.', opts: ['it is', 'is it', 'it was'], a: 'is it', why: 'Inversion after “Not only” at the start of a sentence.' },
      { q: 'It is essential that every child ___ access to education.', opts: ['has', 'have', 'having'], a: 'has', why: 'Both “has” and the formal subjunctive “have” exist; for IELTS, “has” is the natural choice here.' }
    ] },
  { id: 'mistakes', title: 'Common IELTS mistakes', lesson: 'Uncountable nouns have no plural: <i>information, advice, research, equipment, knowledge</i>. Do not write <i>“more better”</i> or <i>“discuss about”</i>. Write <i>“people”</i>, not <i>“peoples”</i> (unless you mean nations).',
    ex: [
      { q: 'Choose the correct sentence.', opts: ['She gave me many advices.', 'She gave me a lot of advice.', 'She gave me an advice.'], a: 'She gave me a lot of advice.', why: '“advice” is uncountable.' },
      { q: 'Choose the correct sentence.', opts: ['We discussed about the problem.', 'We discussed the problem.', 'We discussed on the problem.'], a: 'We discussed the problem.', why: '“discuss” takes a direct object, no preposition.' },
      { q: 'Choose the correct sentence.', opts: ['This option is more better.', 'This option is much better.', 'This option is most better.'], a: 'This option is much better.', why: '“better” is already comparative.' },
      { q: 'Choose the correct sentence.', opts: ['Many peoples use public transport.', 'Many people use public transport.', 'Much people use public transport.'], a: 'Many people use public transport.', why: '“people” is already plural.' },
      { q: 'Choose the correct sentence.', opts: ['I am agree with this view.', 'I agree with this view.', 'I am agreed this view.'], a: 'I agree with this view.', why: '“agree” is a verb; no “am”.' }
    ] }
];

window.TIPS = [
  { m: 'L', t: 'Read ahead', d: 'Use the pause before each section to underline key words in the questions and predict the type of answer (a number, a name, a place).' },
  { m: 'L', t: 'Watch for corrections', d: 'Speakers often change their mind — “Tuesday… no, sorry, Thursday”. The final answer is usually the one that counts.' },
  { m: 'R', t: 'Skim, then scan', d: 'Spend 2 minutes skimming for the main idea of each paragraph, then scan for names, dates and key words when answering.' },
  { m: 'R', t: 'FALSE vs NOT GIVEN', d: 'FALSE means the passage says the opposite. NOT GIVEN means the passage says nothing about it. Don\'t use your own knowledge.' },
  { m: 'W', t: 'Always write an overview', d: 'In Task 1, a clear overview of the main trends is essential for Band 6+ in Task Achievement.' },
  { m: 'W', t: 'Answer every part', d: 'In Task 2, check if the question has two parts (e.g. causes AND solutions). Missing one part limits your score.' },
  { m: 'S', t: 'Extend your answers', d: 'In Part 1, aim for 2–3 sentences: answer, reason, example. Short “yes/no” answers limit fluency.' },
  { m: 'S', t: 'Use the full two minutes', d: 'In Part 2, use your one minute to note key words for each bullet point, then keep talking until the examiner stops you.' }
];

window.FAQ = [
  ['Is OpenBand really free?', 'Yes. Every practice test, mock exam, learning tool and feature is free. There are no subscriptions, premium plans, locked tests or payment pages.'],
  ['Do I need an account?', 'No. You can start practising immediately. Your progress is saved in your browser. You can optionally create a local profile to personalise your dashboard.'],
  ['Are the band scores official?', 'No. All scores here are estimates for practice. Only an official IELTS test can give you an official band score. Raw-score conversions vary slightly between test versions.'],
  ['How is Writing feedback produced?', 'This demo uses automated text analysis (word count, sentence variety, linking words, common errors and task checks) to give an indicative estimate, plus a self-assessment checklist. It is not an AI evaluation. A secure AI evaluation service can be connected through a backend later.'],
  ['Is this platform connected to IELTS, the British Council or IDP?', 'No. OpenBand is an independent, free practice platform. All test content is original and written for practice.'],
  ['Where does the listening audio come from?', 'Listening scripts are original and are read aloud by your browser\'s built-in speech engine, so audio works offline and without any copyrighted recordings. Voices vary by device; Chrome and Edge usually offer the most natural voices.'],
  ['Can I use it on my phone?', 'Yes. The whole platform is responsive. On small screens the reading test switches to tabbed passage/question views.']
];
