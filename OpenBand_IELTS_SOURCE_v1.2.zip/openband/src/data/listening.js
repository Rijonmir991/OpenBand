/* Original listening practice content — written for OpenBand. Not taken from any official IELTS material.
   Voices: v:'f' female, v:'m' male, v:'n' narrator. Audio is produced with the browser's speech engine. */
const MAP_SVG = `<svg viewBox="0 0 520 390" xmlns="http://www.w3.org/2000/svg" font-family="Segoe UI,Arial,sans-serif" font-size="12">
<rect width="520" height="390" rx="14" fill="#EAF6EE"/>
<rect x="400" y="20" width="105" height="120" rx="14" fill="#BFE3C6"/><text x="452" y="45" text-anchor="middle" fill="#2E6B3A" font-weight="700">Woodland</text>
<ellipse cx="260" cy="80" rx="120" ry="48" fill="#9FD0F0"/><text x="260" y="85" text-anchor="middle" fill="#1B4F72" font-weight="700">LAKE</text>
<rect x="20" y="320" width="110" height="52" rx="8" fill="#D9DDE6"/><text x="75" y="350" text-anchor="middle" fill="#3B4560" font-weight="700">Car park</text>
<path d="M260 380 V140" stroke="#C9A97A" stroke-width="14" stroke-linecap="round"/>
<path d="M110 205 H410" stroke="#C9A97A" stroke-width="12" stroke-linecap="round"/>
<path d="M140 80 Q140 20 260 18 Q380 20 380 80 Q380 140 260 140 Q140 140 140 80" fill="none" stroke="#C9A97A" stroke-width="8"/>
<rect x="215" y="285" width="90" height="48" rx="8" fill="#14213D"/><text x="260" y="306" text-anchor="middle" fill="#fff" font-weight="700">Visitor</text><text x="260" y="322" text-anchor="middle" fill="#fff" font-weight="700">Centre</text>
<rect x="232" y="368" width="56" height="18" rx="4" fill="#FF8A76"/><text x="260" y="381" text-anchor="middle" fill="#fff" font-weight="700" font-size="10">ENTRANCE</text>
${[['A', 150, 300], ['B', 370, 300], ['C', 90, 205], ['D', 430, 205], ['E', 165, 150], ['F', 400, 92], ['G', 260, 12], ['H', 470, 160]].map(([l, x, y]) => `<circle cx="${x}" cy="${y}" r="15" fill="#3157D5" stroke="#fff" stroke-width="3"/><text x="${x}" y="${y + 4.5}" text-anchor="middle" fill="#fff" font-weight="800" font-size="13">${l}</text>`).join('')}
<text x="475" y="378" fill="#2E6B3A" font-weight="700" font-size="11">N ↑</text>
</svg>`;

window.LISTENING = [
  {
    id: 'L1', module: 'L', title: 'Listening Test 1 — Full Test', level: 'Intermediate', track: 'both', minutes: 30, added: '2026-10-02', plays: 1840,
    parts: [
      {
        title: 'Section 1', context: 'A telephone conversation between a sports centre receptionist and a man who wants to join.',
        script: [
          { v: 'n', t: 'Section 1. You will hear a telephone conversation between a receptionist at a sports centre and a man who wants to become a member. First, you have some time to look at questions 1 to 10.', pause: 2 },
          { s: 'Receptionist', v: 'f', t: 'Good morning, Riverside Sports Centre, Emma speaking. How can I help?' },
          { s: 'Daniel', v: 'm', t: "Hi. I'm thinking of joining the centre and I wondered if you could give me some information." },
          { s: 'Receptionist', v: 'f', t: 'Of course. I can take a few details now and set up a trial membership for you, if you like.' },
          { s: 'Daniel', v: 'm', t: 'That would be great, thanks.' },
          { s: 'Receptionist', v: 'f', t: 'Could I start with your full name?' },
          { s: 'Daniel', v: 'm', t: "It's Daniel Hartley. That's H, A, R, T, L, E, Y." },
          { s: 'Receptionist', v: 'f', t: 'Thank you, Daniel. And what is your address?' },
          { s: 'Daniel', v: 'm', t: "Number forty-two, Mill Lane. That's Mill, M, I, L, L, like a flour mill. In Westbury." },
          { s: 'Receptionist', v: 'f', t: 'Forty-two Mill Lane, Westbury. And the postcode?' },
          { s: 'Daniel', v: 'm', t: 'W, B, seven, then three, Q, T.' },
          { s: 'Receptionist', v: 'f', t: 'W B 7, 3 Q T. Lovely. Now, we have three kinds of membership. Full membership is forty-five pounds a month and lets you come any time. There is also a student membership, but you need a valid student card for that.' },
          { s: 'Daniel', v: 'm', t: "I finished university last year, so I don't think I can use that one." },
          { s: 'Receptionist', v: 'f', t: 'No, I am afraid not. The third option is off-peak membership. You can use the centre on weekdays before four p.m. and all day at weekends.' },
          { s: 'Daniel', v: 'm', t: "Actually, that suits me. I work shifts at the hospital, so I'm usually free in the daytime. I'll go for off-peak." },
          { s: 'Receptionist', v: 'f', t: 'Good choice. That costs twenty-eight pounds a month. It used to be thirty, but we reduced it in September.' },
          { s: 'Receptionist', v: 'f', t: 'And which activities are you most interested in?' },
          { s: 'Daniel', v: 'm', t: "Well, I was going to say the gym, but to be honest it will mainly be swimming. I hurt my knee playing football last winter, and my physiotherapist said swimming would be better for it." },
          { s: 'Receptionist', v: 'f', t: "I'm sorry to hear that. I'll make a note of the knee injury so the staff are aware. Now, all new members do a short induction session. We have one on Tuesday at five o'clock, but that one is already full. The next is on Thursday." },
          { s: 'Daniel', v: 'm', t: 'Thursday is fine. What time does it start?' },
          { s: 'Receptionist', v: 'f', t: "Half past six in the evening, and it takes about forty minutes. Please bring a towel. Oh, and you'll need a padlock for the lockers. We don't provide them, I'm afraid." },
          { s: 'Daniel', v: 'm', t: 'A padlock, right. I have one somewhere.' },
          { s: 'Receptionist', v: 'f', t: 'Lastly, could I ask how you heard about us? Was it our website?' },
          { s: 'Daniel', v: 'm', t: 'No, I saw an advertisement in the newspaper. The free one that comes through the door every week.' },
          { s: 'Receptionist', v: 'f', t: "Great, thank you, Daniel. We'll see you on Thursday." }
        ],
        groups: [
          {
            type: 'gap', layout: 'form', limit: 'Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.', title: 'Riverside Sports Centre — New Member Form',
            lines: ['Name|Daniel Hartley <i class="muted">(example)</i>', 'Address|42 [[1]] Lane, Westbury', 'Postcode|[[2]]', 'Membership type|[[3]]', 'Monthly cost|£[[4]]', 'Main activity|[[5]]', 'Health note|has a [[6]] injury', 'Induction day|[[7]]', 'Induction time|[[8]] p.m.', 'Must bring|towel and a [[9]]', 'Heard about centre from|[[10]]'],
            key: { 1: ['Mill'], 2: ['WB7 3QT', 'WB73QT'], 3: ['off-peak', 'off peak', 'offpeak'], 4: ['28', 'twenty-eight'], 5: ['swimming'], 6: ['knee'], 7: ['Thursday'], 8: ['6.30', '6:30', 'half past six', '18.30', '18:30'], 9: ['padlock'], 10: ['(the) newspaper', '(a) newspaper', 'local newspaper', 'free newspaper'] },
            why: { 1: '“Number forty-two, Mill Lane … M, I, L, L.”', 2: 'The postcode is spelt out: “W, B, seven, then three, Q, T.”', 3: 'He rejects the student option and says “I\'ll go for off-peak.”', 4: '“That costs twenty-eight pounds a month. It used to be thirty” — 30 is the old price.', 5: '“I was going to say the gym, but … it will mainly be swimming.”', 6: '“I hurt my knee … I\'ll make a note of the knee injury.”', 7: 'Tuesday is full; “The next is on Thursday.”', 8: '“Half past six in the evening.”', 9: '“You\'ll need a padlock for the lockers.”', 10: 'Not the website — “I saw an advertisement in the newspaper.”' }
          }
        ]
      },
      {
        title: 'Section 2', context: 'A guide welcomes visitors to Greenhill Botanic Garden.',
        script: [
          { v: 'n', t: 'Section 2. You will hear a guide talking to a group of visitors at Greenhill Botanic Garden. First, look at questions 11 to 20.', pause: 2 },
          { s: 'Guide', v: 'm', t: "Good morning everyone, and welcome to Greenhill Botanic Garden. My name is Paul and I'll be giving you a quick introduction before you explore on your own. You should all have a map, so let me show you where things are." },
          { s: 'Guide', v: 'm', t: "We're standing in the visitor centre, just inside the main entrance. When you leave this building, if you turn left you will find the rose garden straight away. It's right next to the car park, so it's the first thing most people see." },
          { s: 'Guide', v: 'm', t: "The building on the other side of the visitor centre, to your right, is our gift shop. Now, if you follow the main path north, you'll come to a crossroads. Turn right there and walk to the very end of the path, and you'll reach the glasshouse, with our tropical plants." },
          { s: 'Guide', v: 'm', t: "If you have children with you, the play area is in the opposite direction. So at the crossroads, turn left instead and go to the end of that path. It's directly opposite the glasshouse, on the west side of the garden." },
          { s: 'Guide', v: 'm', t: "Keep going north on the main path and you'll reach the lake. The picnic area is on the western shore, near the end of the main path. The café is on the eastern side of the lake, with tables overlooking the water. And if you'd like the best view of the whole garden, walk around to the far side of the lake, on the northern shore, where you'll find the viewing platform. The woodland trail starts in the north-east corner, but it's quite muddy this week." },
          { s: 'Guide', v: 'm', t: "Now a little history. Many people assume the garden was started by the university, because their scientists use it for research. In fact, it was created in eighteen ninety by the Whitmore family as their private garden. The city council only took it over in nineteen fifty-two." },
          { s: 'Guide', v: 'm', t: "We've added something new this year. We already had a herb garden and an audio guide, but this spring we opened a sensory garden, designed especially for visitors who are blind or partially sighted, with plants you can touch and smell." },
          { s: 'Guide', v: 'm', t: "We rely heavily on volunteers. We have plenty of people who lead guided tours and help in the café, but what we really need are people who can help with the gardening at weekends, so please ask at reception if you're interested." },
          { s: 'Guide', v: 'm', t: "A tip about the glasshouse: most visitors go at lunchtime, when it's crowded and very hot. I'd suggest going first thing in the morning, when the butterflies are most active and it's much quieter." },
          { s: 'Guide', v: 'm', t: "Finally, one request. You're very welcome to take photographs and to sit on the grass. But please don't feed the ducks. Bread makes them ill and pollutes the lake. Enjoy your visit!" }
        ],
        groups: [
          {
            type: 'match', image: MAP_SVG, title: 'Label the map', ins: 'Questions 11–15. Label the map below. Choose the correct letter, A–H.',
            opts: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map(k => ({ k, t: '' })), compact: true,
            items: [
              { n: 11, q: 'Rose garden', a: 'A', why: '“When you leave this building, if you turn left you will find the rose garden … right next to the car park.”' },
              { n: 12, q: 'Glasshouse', a: 'D', why: 'Main path north → crossroads → turn right → “the very end of the path”.' },
              { n: 13, q: 'Café', a: 'F', why: '“The café is on the eastern side of the lake.”' },
              { n: 14, q: "Children's play area", a: 'C', why: 'At the crossroads turn left, end of the path, “directly opposite the glasshouse”.' },
              { n: 15, q: 'Viewing platform', a: 'G', why: '“The far side of the lake, on the northern shore.”' }
            ]
          },
          {
            type: 'mcq', ins: 'Questions 16–20. Choose the correct letter, A, B or C.',
            items: [
              { n: 16, q: 'The garden was originally created by', opts: ['a university.', 'a private family.', 'the city council.'], a: 'B', why: '“It was created in 1890 by the Whitmore family as their private garden.” The council took over later; the university only uses it.' },
              { n: 17, q: 'What is new at the garden this year?', opts: ['a herb garden', 'an audio guide', 'a sensory garden'], a: 'C', why: 'The herb garden and audio guide already existed; “this spring we opened a sensory garden”.' },
              { n: 18, q: 'Volunteers are most needed for', opts: ['leading guided tours.', 'gardening at weekends.', 'working in the café.'], a: 'B', why: '“What we really need are people who can help with the gardening at weekends.”' },
              { n: 19, q: 'The guide recommends visiting the glasshouse', opts: ['early in the morning.', 'at lunchtime.', 'late in the afternoon.'], a: 'A', why: '“I\'d suggest going first thing in the morning.”' },
              { n: 20, q: 'Visitors are asked not to', opts: ['feed the ducks.', 'take photographs.', 'sit on the grass.'], a: 'A', why: 'Photos and sitting on the grass are welcome; “please don\'t feed the ducks.”' }
            ]
          }
        ]
      },
      {
        title: 'Section 3', context: 'Two students, Maya and Tom, discuss their research project on urban beekeeping with their tutor.',
        script: [
          { v: 'n', t: 'Section 3. You will hear two students, Maya and Tom, talking to their tutor about their research project on urban beekeeping. First, look at questions 21 to 30.', pause: 2 },
          { s: 'Tutor', v: 'n', t: 'Come in, both of you. So, how is the beekeeping project going? Remind me why you chose this topic.' },
          { s: 'Maya', v: 'f', t: "Well, there was plenty of research available, which helped. But honestly, the main reason was Tom's grandfather." },
          { s: 'Tom', v: 'm', t: "Yes, he's kept bees for forty years, and I grew up helping him. So it was a personal interest for me, and Maya got interested too." },
          { s: 'Tutor', v: 'n', t: 'That kind of motivation always helps. How did your first survey go?' },
          { s: 'Tom', v: 'm', t: "We actually got more responses than we expected, about two hundred. The trouble was that people didn't understand some of the questions. For example, we asked about pollinator corridors and most people had no idea what that meant." },
          { s: 'Maya', v: 'f', t: 'So we rewrote the questions in simpler language and ran it again.' },
          { s: 'Tutor', v: 'n', t: "Good. Now, your literature review. The length is fine, and I don't mind that you've included studies from other countries. But most of your sources are from the nineteen nineties. You need to include more recent research. There has been a lot published in the last five years." },
          { s: 'Maya', v: 'f', t: "OK, we'll look for newer studies. Actually, the thing that surprised us most was the honey. We expected hives in the countryside to do better, but city hives produced more honey on average." },
          { s: 'Tom', v: 'm', t: "Because there's a much wider variety of flowers in city gardens and parks. We thought residents might be frightened of the bees, but most people were very positive." },
          { s: 'Tutor', v: 'n', t: "Interesting. And for the presentation? I don't think you need a video. A poster is optional." },
          { s: 'Maya', v: 'f', t: "We'd like to invite a local beekeeper to answer questions at the end. Tom's grandfather has agreed to come." },
          { s: 'Tutor', v: 'n', t: 'Excellent idea. Now, have you divided up the remaining tasks?' },
          { s: 'Maya', v: 'f', t: "Mostly. I'll contact the local council about their plans for wildflower verges, because I already know someone in the parks department." },
          { s: 'Tom', v: 'm', t: "And I'll analyse the survey data, since I took the statistics course last term." },
          { s: 'Maya', v: 'f', t: "The introduction is the hardest part, so we'll write that together." },
          { s: 'Tom', v: 'm', t: "Maya's much better at design than me, so she'll do the slides." },
          { s: 'Maya', v: 'f', t: "And Tom, you said you'd book the seminar room?" },
          { s: 'Tom', v: 'm', t: "Yes, I'll do that today." }
        ],
        groups: [
          {
            type: 'mcq', ins: 'Questions 21–25. Choose the correct letter, A, B or C.',
            items: [
              { n: 21, q: 'Why did the students choose this topic?', opts: ['Their tutor suggested it.', 'One student has personal experience of it.', 'There was very little research on it.'], a: 'B', why: '“The main reason was Tom\'s grandfather … it was a personal interest for me.”' },
              { n: 22, q: 'What was the problem with their first survey?', opts: ['Too few people responded.', 'Some questions were difficult to understand.', 'They asked the wrong group of people.'], a: 'B', why: 'They got 200 responses, but “people didn\'t understand some of the questions.”' },
              { n: 23, q: 'What does the tutor say about the literature review?', opts: ['It should be shorter.', 'It needs more recent studies.', 'It should only include local studies.'], a: 'B', why: '“You need to include more recent research.”' },
              { n: 24, q: 'What surprised the students most?', opts: ['City hives produced more honey.', 'Residents were afraid of bees.', 'Hives in parks were damaged.'], a: 'A', why: '“City hives produced more honey on average.” Residents were actually positive.' },
              { n: 25, q: 'For their presentation, the students plan to', opts: ['show a short video.', 'display a poster.', 'invite a beekeeper.'], a: 'C', why: '“We\'d like to invite a local beekeeper to answer questions.”' }
            ]
          },
          {
            type: 'match', ins: 'Questions 26–30. Who will do each task? Choose A, B or C.',
            opts: [{ k: 'A', t: 'Maya' }, { k: 'B', t: 'Tom' }, { k: 'C', t: 'both Maya and Tom' }],
            items: [
              { n: 26, q: 'contact the local council', a: 'A', why: 'Maya: “I\'ll contact the local council.”' },
              { n: 27, q: 'analyse the survey data', a: 'B', why: 'Tom: “I\'ll analyse the survey data.”' },
              { n: 28, q: 'write the introduction', a: 'C', why: '“We\'ll write that together.”' },
              { n: 29, q: 'design the slides', a: 'A', why: '“Maya\'s much better at design … she\'ll do the slides.”' },
              { n: 30, q: 'book the seminar room', a: 'B', why: 'Tom: “Yes, I\'ll do that today.”' }
            ]
          }
        ]
      },
      {
        title: 'Section 4', context: 'A lecture about bamboo as a building material.',
        script: [
          { v: 'n', t: 'Section 4. You will hear a lecture about bamboo as a construction material. First, look at questions 31 to 40.', pause: 2 },
          { s: 'Lecturer', v: 'f', t: "Good afternoon. Today I want to talk about a material that is attracting a lot of attention from architects and engineers: bamboo." },
          { s: 'Lecturer', v: 'f', t: "Although bamboo looks like a tree, it is not wood at all. Botanically speaking, it's a type of grass. And it grows remarkably fast. Some species can grow as much as a metre in a single day, which means a bamboo plantation can be harvested after three to five years, compared with decades for most timber." },
          { s: 'Lecturer', v: 'f', t: "What makes bamboo so interesting as a building material? First, its strength. When you pull it, its tensile strength is comparable to that of steel. Second, it is extremely light. And light, flexible structures perform well when the ground shakes, so bamboo is particularly suitable for regions that experience frequent earthquakes." },
          { s: 'Lecturer', v: 'f', t: "However, there are problems. If bamboo is not treated, it is quickly attacked by insects, especially beetles, because of the sugar in the stems. Another difficulty is that the stems are hollow, which makes it hard to create strong joints between pieces. And in many countries there are simply no building codes for bamboo, so engineers and insurers are reluctant to approve its use." },
          { s: 'Lecturer', v: 'f', t: "Recent developments are addressing these issues. One is engineered bamboo. The stems are cut into thin strips, which are treated and then glued together under pressure to form flat panels. These behave much more like conventional timber products." },
          { s: 'Lecturer', v: 'f', t: "Engineered bamboo has already been used in some major projects. A well-known example is the ceiling of an airport terminal in Spain, where curved strips of bamboo cover a huge area." },
          { s: 'Lecturer', v: 'f', t: "Finally, there is an environmental argument. As it grows, bamboo absorbs and stores large amounts of carbon, so replacing some concrete and steel with bamboo could help reduce emissions from the construction industry." }
        ],
        groups: [
          {
            type: 'gap', layout: 'notes', limit: 'Write ONE WORD ONLY for each answer.', title: 'Bamboo as a building material',
            lines: ['#Background', 'Bamboo is not wood — it is a type of [[31]].', 'Some species can grow one metre per [[32]].', '#Advantages', 'Tensile strength is similar to [[33]].', 'Its lightness suits areas with frequent [[34]].', '#Problems', 'Untreated bamboo is attacked by [[35]].', 'Joints are difficult because the stems are [[36]].', 'Many countries have no building [[37]] for bamboo.', '#Recent developments', 'Engineered bamboo: strips are glued to form [[38]].', 'Used in an airport terminal ceiling in [[39]].', 'Bamboo stores [[40]], which could reduce emissions.'],
            key: { 31: ['grass'], 32: ['day'], 33: ['steel'], 34: ['earthquakes', 'earthquake'], 35: ['insects', 'beetles'], 36: ['hollow'], 37: ['codes', 'code'], 38: ['panels'], 39: ['Spain'], 40: ['carbon'] },
            why: { 31: '“Botanically speaking, it\'s a type of grass.”', 32: '“As much as a metre in a single day.”', 33: '“Its tensile strength is comparable to that of steel.”', 34: '“Regions that experience frequent earthquakes.”', 35: '“Attacked by insects, especially beetles.”', 36: '“The stems are hollow, which makes it hard to create strong joints.”', 37: '“No building codes for bamboo.”', 38: '“Glued together under pressure to form flat panels.”', 39: '“An airport terminal in Spain.”', 40: '“Absorbs and stores large amounts of carbon.”' }
          }
        ]
      }
    ]
  },
  {
    id: 'L2', module: 'L', title: 'Listening Test 2 — Sections 1 & 2', level: 'Beginner', track: 'both', minutes: 15, added: '2026-11-08', plays: 960,
    parts: [
      {
        title: 'Section 1', context: 'A woman reports a lost item at a railway station.',
        script: [
          { v: 'n', t: 'Section 1. You will hear a woman reporting a lost item at a railway station. First, look at questions 1 to 10.', pause: 2 },
          { s: 'Clerk', v: 'm', t: 'Lost property office, good afternoon. How can I help?' },
          { s: 'Woman', v: 'f', t: "Hello. I think I left my bag on the train this morning. I'm hoping someone handed it in." },
          { s: 'Clerk', v: 'm', t: "I'll fill in a report for you. What kind of bag is it?" },
          { s: 'Woman', v: 'f', t: "It's a backpack. A small one, dark green, with a brown leather strap on the front." },
          { s: 'Clerk', v: 'm', t: 'And which train were you on?' },
          { s: 'Woman', v: 'f', t: "The eight fifteen from Oxford. I got off here at about nine thirty. I was sitting in coach D, I think. No, sorry, it was coach B, near the front." },
          { s: 'Clerk', v: 'm', t: 'Coach B. What was inside the bag?' },
          { s: 'Woman', v: 'f', t: "My laptop, which is the main worry. A library book, and a blue umbrella. Oh, and my sunglasses, but they're not expensive." },
          { s: 'Clerk', v: 'm', t: 'Is there anything that would help us identify it?' },
          { s: 'Woman', v: 'f', t: "Yes, there's a keyring attached to the zip, shaped like a small elephant." },
          { s: 'Clerk', v: 'm', t: 'An elephant. That is helpful. Can I take your name?' },
          { s: 'Woman', v: 'f', t: "Sarah Okafor. That's O, K, A, F, O, R." },
          { s: 'Clerk', v: 'm', t: "And the best way to contact you? We usually send a text message." },
          { s: 'Woman', v: 'f', t: "Actually, could you email me? I'm not sure my phone battery will last. It's sarah dot okafor at mailbox dot com." },
          { s: 'Clerk', v: 'm', t: "Of course. Items are kept here for ninety days. If it's found, you'll need to bring some photo ID, like a passport or driving licence, when you collect it. There's also a small collection fee of three pounds fifty." },
          { s: 'Woman', v: 'f', t: 'That is fine. Thank you so much.' }
        ],
        groups: [{
          type: 'gap', layout: 'form', title: 'Lost Property Report', limit: 'Write NO MORE THAN TWO WORDS AND/OR A NUMBER for each answer.',
          lines: ['Item|small [[1]] backpack', 'Distinctive feature|brown leather [[2]] on front', 'Train|8.15 from [[3]]', 'Coach|[[4]]', 'Most valuable item|[[5]]', 'Other items|library book, blue [[6]], sunglasses', 'Identification|keyring shaped like an [[7]]', 'Surname|[[8]]', 'Contact by|[[9]]', 'Collection fee|£[[10]]'],
          key: { 1: ['dark green', 'green'], 2: ['strap'], 3: ['Oxford'], 4: ['B'], 5: ['laptop', '(a) laptop'], 6: ['umbrella'], 7: ['elephant'], 8: ['Okafor'], 9: ['email', 'e-mail'], 10: ['3.50', '3.5'] },
          why: { 1: '“A small one, dark green.”', 2: '“With a brown leather strap on the front.”', 3: '“The eight fifteen from Oxford.”', 4: 'She corrects herself: “No, sorry, it was coach B.”', 5: '“My laptop, which is the main worry.”', 6: '“A blue umbrella.”', 7: '“Shaped like a small elephant.”', 8: 'Spelt O-K-A-F-O-R.', 9: 'Texting is usual, but she asks: “could you email me?”', 10: '“A small collection fee of three pounds fifty.”' }
        }]
      },
      {
        title: 'Section 2', context: 'A radio presenter describes events at a town festival.',
        script: [
          { v: 'n', t: 'Section 2. You will hear a local radio presenter talking about the Harbourside Summer Festival. First, look at questions 11 to 20.', pause: 2 },
          { s: 'Presenter', v: 'f', t: "And now, the news everyone's been waiting for: the programme for this year's Harbourside Summer Festival. It runs for three days, from Friday the twelfth to Sunday the fourteenth." },
          { s: 'Presenter', v: 'f', t: "Friday evening opens with the lantern parade, starting at the old lighthouse at eight o'clock. Lanterns are free, but you'll need to collect one from the town library before Friday." },
          { s: 'Presenter', v: 'f', t: "On Saturday the main event is the food market on the harbour wall, with more than sixty stalls. It opens at ten in the morning. Bring your own bag, as stallholders won't be giving out plastic ones this year." },
          { s: 'Presenter', v: 'f', t: "Saturday afternoon features the raft race. Teams build a raft from recycled materials and race across the harbour. Entry costs fifteen pounds per team, and all the money goes to the lifeboat station." },
          { s: 'Presenter', v: 'f', t: "Sunday is family day in Castle Park, with a storytelling tent and a climbing wall. That's all free." },
          { s: 'Presenter', v: 'f', t: "A few practical points. Parking in the town centre will be very limited, so the council is running a free shuttle bus from the football stadium every twenty minutes. Last year's biggest complaint was about queues for toilets, so there will be twice as many this year. And if you'd like to help, the organisers are looking for volunteers to work as stewards. You need to be over eighteen, and you'll get a free festival T-shirt." },
          { s: 'Presenter', v: 'f', t: "The weather forecast is mostly dry, although there may be some rain on Sunday morning. Programmes can be picked up from the tourist information centre." }
        ],
        groups: [
          {
            type: 'table', ins: 'Questions 11–15. Complete the table.', limit: 'Write ONE WORD AND/OR A NUMBER for each answer.',
            head: ['Day', 'Event', 'Details'],
            rows: [['Friday', 'Lantern parade', 'Starts at the old [[11]] at 8 p.m. · collect lanterns from the [[12]]'], ['Saturday', 'Food market', 'Over [[13]] stalls · bring your own bag'], ['Saturday', 'Raft race', 'Rafts made of [[14]] materials · £15 per team'], ['Sunday', 'Family day', 'Storytelling tent and a climbing [[15]]']],
            key: { 11: ['lighthouse'], 12: ['library'], 13: ['60', 'sixty'], 14: ['recycled'], 15: ['wall'] },
            why: { 11: '“Starting at the old lighthouse.”', 12: '“Collect one from the town library.”', 13: '“More than sixty stalls.”', 14: '“A raft from recycled materials.”', 15: '“A storytelling tent and a climbing wall.”' }
          },
          {
            type: 'mcq', ins: 'Questions 16–20. Choose the correct letter, A, B or C.',
            items: [
              { n: 16, q: 'Money from the raft race will go to', opts: ['the festival organisers.', 'the lifeboat station.', 'Castle Park.'], a: 'B', why: '“All the money goes to the lifeboat station.”' },
              { n: 17, q: 'The free shuttle bus leaves from', opts: ['the football stadium.', 'the town centre.', 'the harbour wall.'], a: 'A', why: '“A free shuttle bus from the football stadium.”' },
              { n: 18, q: "Last year's main complaint was about", opts: ['parking.', 'toilet queues.', 'litter.'], a: 'B', why: '“Last year\'s biggest complaint was about queues for toilets.”' },
              { n: 19, q: 'Volunteer stewards will receive', opts: ['a free meal.', 'free parking.', 'a T-shirt.'], a: 'C', why: '“You\'ll get a free festival T-shirt.”' },
              { n: 20, q: 'Rain is possible on', opts: ['Friday evening.', 'Saturday afternoon.', 'Sunday morning.'], a: 'C', why: '“There may be some rain on Sunday morning.”' }
            ]
          }
        ]
      }
    ]
  }
];
