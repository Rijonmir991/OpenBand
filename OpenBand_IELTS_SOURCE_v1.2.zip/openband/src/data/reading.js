/* Original reading practice content — written for OpenBand. People and studies named in passages are
   illustrative unless widely known historical facts. Not taken from official IELTS material. */
window.READING = [
  {
    id: 'RA1', module: 'R', title: 'Academic Reading Test 1 — Full Test', level: 'Intermediate', track: 'academic', minutes: 60, added: '2026-10-05', plays: 2210,
    parts: [
      {
        title: 'Passage 1', heading: 'The Return of the Urban Forest', note: 'You should spend about 20 minutes on Questions 1–13.',
        paras: [
          'For much of the twentieth century, trees in cities were treated mainly as decoration. Planners chose species for their appearance, planted them in neat rows along major roads and removed them whenever they interfered with power lines or new buildings. In many industrial cities, tree cover fell steadily between 1950 and 1990 as streets were widened and older trees were not replaced.',
          'That attitude has changed dramatically. Researchers now describe city trees as "green infrastructure", a phrase that places them in the same category as drains, roads and power networks. The reason is economic as much as environmental. A study of street trees in one North American city estimated that every dollar spent on planting and maintenance returned more than five dollars in benefits, from lower energy bills to reduced flooding.',
          'The most obvious benefit is shade. On a summer afternoon, the surface of an unshaded car park can be more than 20 degrees Celsius hotter than a nearby lawn under trees. Because buildings and pavements store heat and release it slowly at night, city centres are often several degrees warmer than the surrounding countryside, an effect known as the urban heat island. Trees reduce this in two ways: by blocking sunlight and by releasing water vapour through their leaves, a process that cools the surrounding air.',
          'Trees also manage water. During heavy rain, their leaves and branches intercept a significant proportion of rainfall, and their roots help water soak into the soil rather than rushing into overloaded drains. Some cities now calculate how much they would need to spend on larger pipes and storage tanks if their trees were removed.',
          'The evidence on health is growing but harder to interpret. Several studies have found that people living on streets with more trees report better mental well-being, and hospital patients with a view of trees have been shown to recover slightly faster after surgery. However, wealthier neighbourhoods tend to have more trees, and wealth itself is linked to better health, so researchers must be careful not to confuse cause and effect.',
          'Not every tree is equally useful. Large, long-lived species provide far more shade and store far more carbon than small ornamental trees, but they need space for their roots and decades to reach maturity. Some species also release chemicals that contribute to air pollution on hot days, while others produce pollen that triggers allergies. As a result, foresters increasingly recommend planting a wide mix of species, partly so that a single disease cannot wipe out an entire street, as Dutch elm disease did across much of Europe in the 1970s.',
          'Perhaps the biggest challenge is not planting trees but keeping them alive. In some programmes, up to a third of young trees die within five years, usually because they are not given enough water during their first summers. Several cities have responded by recruiting local residents to "adopt" a tree outside their home, and early results suggest that adopted trees are far more likely to survive.'
        ],
        groups: [
          {
            type: 'tfng', ins: 'Questions 1–6. Do the following statements agree with the information given in Passage 1? Write TRUE if the statement agrees with the information, FALSE if it contradicts the information, NOT GIVEN if there is no information on this.',
            items: [
              { n: 1, q: 'Tree cover in many industrial cities decreased between 1950 and 1990.', a: 'TRUE', why: 'Paragraph 1: “tree cover fell steadily between 1950 and 1990”.' },
              { n: 2, q: 'The term "green infrastructure" was first used by engineers.', a: 'NOT GIVEN', why: 'The passage says researchers use the term, but not who first used it.' },
              { n: 3, q: 'In one city, each dollar spent on street trees produced over five dollars of benefits.', a: 'TRUE', why: 'Paragraph 2: “every dollar … returned more than five dollars in benefits”.' },
              { n: 4, q: 'City centres are usually cooler than the countryside at night.', a: 'FALSE', why: 'Paragraph 3: city centres are “several degrees warmer” because buildings release heat at night.' },
              { n: 5, q: 'Hospital patients with a view of trees recover much more quickly than other patients.', a: 'FALSE', why: 'Paragraph 5 says they recover “slightly faster”, not much more quickly.' },
              { n: 6, q: 'Residents generally prefer small ornamental trees to large trees.', a: 'NOT GIVEN', why: 'Residents\' preferences are never mentioned.' }
            ]
          },
          {
            type: 'gap', layout: 'sentences', ins: 'Questions 7–10. Complete the sentences below.', limit: 'Choose NO MORE THAN TWO WORDS from the passage for each answer.',
            lines: ['When trees release water vapour, this cools the surrounding [[7]].', 'Some cities estimate the cost of the larger pipes and [[8]] they would need without trees.', 'It is difficult to separate the health effects of trees from those of [[9]], because richer areas have more trees.', 'Planting many different species reduces the risk that one [[10]] could destroy all the trees in a street.'],
            key: { 7: ['air'], 8: ['storage tanks', 'tanks'], 9: ['wealth'], 10: ['disease'] },
            why: { 7: 'Paragraph 3: “a process that cools the surrounding air”.', 8: 'Paragraph 4: “larger pipes and storage tanks”.', 9: 'Paragraph 5: “wealth itself is linked to better health”.', 10: 'Paragraph 6: “so that a single disease cannot wipe out an entire street”.' }
          },
          {
            type: 'gap', layout: 'short', ins: 'Questions 11–13. Answer the questions below.', limit: 'Choose NO MORE THAN THREE WORDS from the passage for each answer.',
            lines: ['Which disease destroyed many trees across Europe in the 1970s? [[11]]', 'What do young trees most often lack in their first summers? [[12]]', 'Who are some cities asking to look after individual young trees? [[13]]'],
            key: { 11: ['Dutch elm disease'], 12: ['water', 'enough water'], 13: ['(local) residents'] },
            why: { 11: 'Paragraph 6: “as Dutch elm disease did across much of Europe”.', 12: 'Paragraph 7: “not given enough water during their first summers”.', 13: 'Paragraph 7: “recruiting local residents to adopt a tree”.' }
          }
        ]
      },
      {
        title: 'Passage 2', heading: 'Sleep and Memory', note: 'You should spend about 20 minutes on Questions 14–26. Researchers named in this passage are fictional.', lettered: true,
        paras: [
          'For centuries, sleep was regarded as a passive state, a nightly interruption during which the brain simply switched off to rest. This view began to change in the 1950s, when scientists recording the electrical activity of sleeping volunteers noticed periods in which the brain was almost as active as when awake, accompanied by rapid movements of the eyes. These episodes, now called rapid eye movement (REM) sleep, were soon linked to vivid dreaming, and researchers began to ask what else the sleeping brain might be doing.',
          'We now know that a night\'s sleep is highly organised. After falling asleep, a person passes through stages of increasingly deep sleep, reaching what is known as slow-wave sleep, in which brain waves become large and slow. This is followed by a period of REM sleep, and the whole cycle, which lasts roughly 90 minutes, repeats four or five times a night. Slow-wave sleep dominates the early part of the night, while REM periods become longer towards morning.',
          'Some of the strongest evidence for a link between sleep and memory comes from simple experiments. Volunteers learn a list of word pairs in the evening and are tested twelve hours later. Those who have slept in between consistently remember more than those who have spent the same period awake. Crucially, the advantage is not explained by tiredness at the time of testing, since it also appears when the "awake" group is tested at a well-rested time of day.',
          'How might sleep strengthen memories? One influential theory focuses on the hippocampus, a structure deep in the brain that records new experiences quickly but only temporarily. During slow-wave sleep, the hippocampus appears to "replay" the day\'s events, sending the information to the outer layer of the brain, the cortex, for long-term storage. Dr Kenji Morita, recording from cells in the brains of rats, found that the sequence of activity produced as an animal ran through a maze was repeated, at high speed, while it slept afterwards.',
          'REM sleep seems to play a different role. In one study, Professor Anna Ruiz gave participants a series of number puzzles that contained a hidden shortcut. Those who had a night of sleep rich in REM were more than twice as likely to discover the shortcut the next morning. Other work suggests that REM sleep helps us process emotional experiences: Dr Grace Obi found that people who slept after viewing upsetting images later rated the same images as less disturbing, even though they remembered them clearly.',
          'These findings have practical implications. Students who stay up all night before an exam may be sacrificing the very process that would help them retain what they have studied. Even short periods of sleep can help: Dr Peter Lund found that a nap of around twenty minutes in the early afternoon improved performance on a memory test later that day. The message is not that sleep can replace study, but that study without sleep is far less effective than it could be.'
        ],
        groups: [
          {
            type: 'match', ins: 'Questions 14–19. Passage 2 has six paragraphs, A–F. Choose the correct heading for each paragraph from the list of headings below.', listTitle: 'List of Headings',
            opts: [{ k: 'i', t: 'Lessons for learners' }, { k: 'ii', t: 'The dangers of sleeping pills' }, { k: 'iii', t: 'An outdated view of sleep' }, { k: 'iv', t: 'How the brain rehearses during the night' }, { k: 'v', t: 'Why animals need less sleep than humans' }, { k: 'vi', t: 'The structure of a night\'s sleep' }, { k: 'vii', t: 'Evidence that sleep protects new learning' }, { k: 'viii', t: 'A different role for dreaming sleep' }, { k: 'ix', t: 'Measuring how long people sleep' }],
            items: [
              { n: 14, q: 'Paragraph A', a: 'iii', why: 'A describes the old belief that sleep was passive, and how it changed.' },
              { n: 15, q: 'Paragraph B', a: 'vi', why: 'B describes stages and 90-minute cycles.' },
              { n: 16, q: 'Paragraph C', a: 'vii', why: 'C gives experimental evidence that sleepers remember more.' },
              { n: 17, q: 'Paragraph D', a: 'iv', why: 'D explains hippocampal “replay” during sleep.' },
              { n: 18, q: 'Paragraph E', a: 'viii', why: 'E is about REM (dreaming) sleep having a different function.' },
              { n: 19, q: 'Paragraph F', a: 'i', why: 'F gives practical implications for students.' }
            ]
          },
          {
            type: 'match', ins: 'Questions 20–23. Match each finding with the correct researcher, A–D.', listTitle: 'List of Researchers',
            opts: [{ k: 'A', t: 'Anna Ruiz' }, { k: 'B', t: 'Kenji Morita' }, { k: 'C', t: 'Peter Lund' }, { k: 'D', t: 'Grace Obi' }],
            items: [
              { n: 20, q: 'A short daytime sleep improved memory performance.', a: 'C', why: 'Paragraph F: Lund — “a nap of around twenty minutes … improved performance”.' },
              { n: 21, q: 'Patterns of brain activity were repeated in sleeping animals.', a: 'B', why: 'Paragraph D: Morita recorded rats\' activity “repeated, at high speed, while it slept”.' },
              { n: 22, q: 'People were more likely to notice a hidden pattern after REM sleep.', a: 'A', why: 'Paragraph E: Ruiz — participants were “more than twice as likely to discover the shortcut”.' },
              { n: 23, q: 'Sleep can make unpleasant memories feel less intense.', a: 'D', why: 'Paragraph E: Obi — images rated “as less disturbing”.' }
            ]
          },
          {
            type: 'mcq', ins: 'Questions 24–26. Choose the correct letter, A, B, C or D.',
            items: [
              { n: 24, q: 'Before the 1950s, sleep was generally thought to be', opts: ['essential for memory.', 'a time when the brain was inactive.', 'mainly about dreaming.', 'harmful to learning.'], a: 'B', why: 'Paragraph A: “a passive state … the brain simply switched off”.' },
              { n: 25, q: 'A complete sleep cycle lasts approximately', opts: ['45 minutes.', '60 minutes.', '90 minutes.', '120 minutes.'], a: 'C', why: 'Paragraph B: “the whole cycle, which lasts roughly 90 minutes”.' },
              { n: 26, q: 'The writer\'s main purpose in paragraph F is to', opts: ['criticise students who sleep too much.', 'describe a new experiment in detail.', 'explain what the research means in practice.', 'argue that sleep can replace studying.'], a: 'C', why: 'F opens “These findings have practical implications” and explicitly says sleep cannot replace study.' }
            ]
          }
        ]
      },
      {
        title: 'Passage 3', heading: 'The Paradox of Choice in Consumer Markets', note: 'You should spend about 20 minutes on Questions 27–40.', lettered: true,
        paras: [
          'Conventional economic theory holds that more choice is always better: a consumer who can choose between thirty kinds of jam is at least as well off as one who can choose between six, because she can always ignore the options she does not want. For most of the twentieth century, retailers acted on this assumption, steadily expanding the range of products on their shelves. Few people questioned whether this expansion was actually making shoppers any happier. In my view, that silence was a mistake.',
          'The best-known challenge came from a study conducted in a supermarket, in which shoppers were offered samples of jam from either a large display of 24 varieties or a small display of six. The large display attracted more visitors, but people who saw the small display were around ten times more likely to buy a jar. The researchers concluded that too many options can lead to "choice overload", causing people to delay a decision or avoid it altogether.',
          'The study became famous, and its message was repeated in countless business books. Yet later attempts to reproduce the result have produced mixed findings. A review that combined data from dozens of experiments found that, on average, the effect of large assortments was close to zero. This does not mean that choice overload is a myth; rather, it appears only under certain conditions — for example, when options are difficult to compare, when shoppers have no clear preference, or when they are under time pressure.',
          'There is also a psychological cost that appears after the decision has been made. When we choose from many alternatives, we are more likely to imagine that one of the rejected options would have been better. This "anticipated regret" can reduce our satisfaction with a perfectly good purchase. People described as "maximisers", who feel they must find the best possible option, appear particularly vulnerable; "satisficers", who stop searching once they find something good enough, tend to report greater contentment, even when their choices are objectively worse.',
          'Businesses have responded in different ways. Some have deliberately reduced their range: one large retailer cut the number of products it sold by around fifteen per cent and reported that sales rose. Others have kept wide ranges but introduced tools to simplify decisions, such as filters, recommendations and "bestseller" labels. These tools can be helpful, but I would argue that they also give companies considerable power to steer customers towards the products that are most profitable for the seller rather than most suitable for the buyer.',
          'Online shopping has transformed the problem. A physical shop is limited by its shelf space, but a website can offer millions of items. Some economists celebrate this "long tail", which allows customers with unusual tastes to find exactly what they want. However, the sheer number of options means that most shoppers rely heavily on rankings and reviews, and there is evidence that a considerable proportion of online reviews are not genuine.',
          'What, then, should consumers do? The research suggests a few simple strategies: decide in advance which features matter most, limit the number of options considered, and accept that "good enough" is often the best choice. Policy makers, too, have a role. Pension schemes that offer a carefully chosen default option have been far more successful at encouraging people to save than schemes that present dozens of funds. Choice is valuable, but it is not an unlimited good — and more of it is not always better.'
        ],
        groups: [
          {
            type: 'ynng', ins: 'Questions 27–31. Do the following statements agree with the claims of the writer? Write YES if the statement agrees with the claims of the writer, NO if it contradicts the claims, NOT GIVEN if it is impossible to say what the writer thinks.',
            items: [
              { n: 27, q: 'Twentieth-century retailers should have asked whether more products made shoppers happier.', a: 'YES', why: 'Paragraph A: “Few people questioned … In my view, that silence was a mistake.”' },
              { n: 28, q: 'Later research has consistently confirmed the findings of the jam study.', a: 'NO', why: 'Paragraph C: later attempts “produced mixed findings”.' },
              { n: 29, q: 'Choice overload is an entirely imaginary effect.', a: 'NO', why: 'Paragraph C: “This does not mean that choice overload is a myth.”' },
              { n: 30, q: 'Maximisers tend to earn more money than satisficers.', a: 'NOT GIVEN', why: 'Income is never discussed.' },
              { n: 31, q: 'Decision-making tools may benefit sellers more than buyers.', a: 'YES', why: 'Paragraph E: “I would argue that they also give companies considerable power to steer customers.”' }
            ]
          },
          {
            type: 'match', ins: 'Questions 32–35. Which paragraph, A–G, contains the following information? You may use any letter more than once.',
            opts: ['A', 'B', 'C', 'D', 'E', 'F', 'G'].map(k => ({ k, t: '' })), compact: true,
            items: [
              { n: 32, q: 'an example of a business that increased sales by offering fewer products', a: 'E', why: 'Paragraph E: a retailer cut its range by 15% “and reported that sales rose”.' },
              { n: 33, q: 'a reference to shoppers who may be misled by fake opinions', a: 'F', why: 'Paragraph F: “a considerable proportion of online reviews are not genuine”.' },
              { n: 34, q: 'the circumstances in which too much choice becomes a problem', a: 'C', why: 'Paragraph C lists conditions: hard to compare, no clear preference, time pressure.' },
              { n: 35, q: 'an example taken from outside the retail sector', a: 'G', why: 'Paragraph G: pension schemes.' }
            ]
          },
          {
            type: 'gap', layout: 'summary', ins: 'Questions 36–40. Complete the summary below.', limit: 'Choose ONE WORD ONLY from the passage for each answer.', title: 'Too much choice?',
            lines: ['In a famous supermarket experiment, the larger display of jam attracted more [[36]], but shoppers were far more likely to buy from the smaller one. The researchers called this effect choice [[37]]. Even after a decision, people may experience anticipated [[38]], which lowers their satisfaction. Shoppers who accept an option that is good enough, known as [[39]], tend to be happier. For governments, offering a carefully selected [[40]] option can encourage people to save for retirement.'],
            key: { 36: ['visitors'], 37: ['overload'], 38: ['regret'], 39: ['satisficers'], 40: ['default'] },
            why: { 36: 'Paragraph B: “The large display attracted more visitors.”', 37: 'Paragraph B: “choice overload”.', 38: 'Paragraph D: “This anticipated regret”.', 39: 'Paragraph D: “satisficers … tend to report greater contentment”.', 40: 'Paragraph G: “a carefully chosen default option”.' }
          }
        ]
      }
    ]
  },
  {
    id: 'RG1', module: 'R', title: 'General Training Reading Test 1', level: 'Beginner', track: 'general', minutes: 45, added: '2026-10-20', plays: 1325,
    parts: [
      {
        title: 'Section 1', heading: 'Swimming in Northvale & Library Update', note: 'Questions 1–10',
        html: `<h3>Swimming in Northvale: Your Guide to Local Pools</h3>
<p><b>A — Riverside Leisure Pool.</b> Our most popular family pool has a 25-metre main pool and a separate splash area for toddlers. A wave machine operates every weekend from 2 p.m. to 4 p.m. There is a café overlooking the pool and free parking for 120 cars. Closed on Mondays for cleaning. Open 8 a.m. – 9 p.m.</p>
<p><b>B — Hollis Road Baths.</b> Built in 1912, this is the oldest pool in the region and has kept many of its original features. Evening sessions are for adults only, and we run a ten-week course for adults who have never learned to swim. There is no car park, but the pool is a two-minute walk from the central bus station. Open 7 a.m. – 8 p.m.</p>
<p><b>C — Northvale Sports Centre.</b> Home to the town\'s competitive swimming clubs, the centre has a 50-metre pool with eight lanes. Lane swimming begins at 6 a.m. on weekdays for those who want to swim before work. Members of the sports centre receive a 20% discount on all swimming sessions.</p>
<p><b>D — Greenway Lido.</b> This heated outdoor pool is open from May to September only. It has a large grassy area for sunbathing and picnics. Children under five swim free when accompanied by an adult. Open 10 a.m. – 7 p.m.</p>
<hr>
<h3>Northvale Library: New Opening Hours and Services</h3>
<p>From 1 March, the library will open from 9 a.m. to 8 p.m. Monday to Thursday and from 9 a.m. to 5 p.m. on Fridays and Saturdays. The library will remain closed on Sundays.</p>
<p>Membership remains free for all Northvale residents. People who live outside the area are welcome to join for an annual fee of £10.</p>
<p><b>New services.</b> Members may now use our 3D printer free of charge, although sessions must be booked in advance and the cost of materials will be charged. A homework club for children aged 8–14 runs every Tuesday and Thursday from 4 p.m. to 6 p.m. It is staffed by volunteers, all of whom are trained teachers. Laptops can be borrowed for up to two hours for use inside the library; you will need your library card.</p>
<p>Printing costs 10p per page for black and white and 50p per page for colour. Our new café is run by a local social enterprise that provides training for young people.</p>`,
        groups: [
          {
            type: 'match', ins: 'Questions 1–5. Look at the four pools, A–D. For which pool are the following statements true? You may use any letter more than once.',
            opts: [{ k: 'A', t: 'Riverside Leisure Pool' }, { k: 'B', t: 'Hollis Road Baths' }, { k: 'C', t: 'Northvale Sports Centre' }, { k: 'D', t: 'Greenway Lido' }],
            items: [
              { n: 1, q: 'It is only open for part of the year.', a: 'D', why: 'Greenway Lido “is open from May to September only”.' },
              { n: 2, q: 'It offers a course for adult beginners.', a: 'B', why: 'Hollis Road: “a ten-week course for adults who have never learned to swim”.' },
              { n: 3, q: 'It opens earliest in the morning on weekdays.', a: 'C', why: 'Sports Centre lane swimming “begins at 6 a.m. on weekdays”.' },
              { n: 4, q: 'It has a wave machine.', a: 'A', why: 'Riverside: “A wave machine operates every weekend”.' },
              { n: 5, q: 'Very young children can swim there without paying.', a: 'D', why: 'Greenway: “Children under five swim free”.' }
            ]
          },
          {
            type: 'tfng', ins: 'Questions 6–10. Do the following statements agree with the information about the library? Write TRUE, FALSE or NOT GIVEN.',
            items: [
              { n: 6, q: 'From March, the library will open on Sundays.', a: 'FALSE', why: '“The library will remain closed on Sundays.”' },
              { n: 7, q: 'People who live outside Northvale must pay to become members.', a: 'TRUE', why: '“People who live outside the area … join for an annual fee of £10.”' },
              { n: 8, q: 'Users of the 3D printer must pay for the materials they use.', a: 'TRUE', why: '“The cost of materials will be charged.”' },
              { n: 9, q: 'The homework club is run by paid library staff.', a: 'FALSE', why: '“It is staffed by volunteers.”' },
              { n: 10, q: 'The library café is the most popular café in Northvale.', a: 'NOT GIVEN', why: 'Its popularity is not mentioned.' }
            ]
          }
        ]
      },
      {
        title: 'Section 2', heading: 'Brightline Logistics — Health and Safety for New Staff', note: 'Questions 11–20',
        html: `<h3>Brightline Logistics: Health and Safety Guide for New Staff</h3>
<p><b>Personal protective equipment (PPE).</b> Different areas of the warehouse have different requirements. In the loading bay, all staff must wear a high-visibility vest and steel-toed boots at all times. Hard hats are required in the racking area, where goods are stored on high shelves and there is a risk of falling objects.</p>
<p>In the cold store, where the temperature is kept at minus 18 degrees, insulated gloves and a thermal jacket are provided. These must be returned to the cold store supervisor at the end of each shift and must not be taken home. Ear defenders are compulsory in the packing hall whenever the conveyor machines are running.</p>
<p><b>Reporting an accident.</b> If an accident happens, your first priority is to make sure the area is safe and that nobody else is at risk. Then call a trained first aider. Their names and phone extensions are displayed on the noticeboard in the staff canteen. All injuries, even minor ones, must be recorded in the accident book within 24 hours. The accident book is kept at the reception desk. Your line manager will then complete an investigation form, and a copy will be sent to the health and safety officer. If an injury results in more than seven days off work, the company is legally required to report it to the national safety authority.</p>`,
        groups: [
          {
            type: 'table', ins: 'Questions 11–15. Complete the table.', limit: 'Choose ONE WORD ONLY from the text for each answer.',
            head: ['Area', 'Equipment required', 'Notes'],
            rows: [['Loading bay', 'high-visibility vest and steel-toed [[11]]', 'at all times'], ['Racking area', '[[12]] hats', 'risk of falling objects'], ['Cold store', 'insulated gloves and a thermal [[13]]', 'return to the cold store [[14]] after each shift'], ['Packing hall', 'ear [[15]]', 'when conveyor machines are running']],
            key: { 11: ['boots'], 12: ['hard'], 13: ['jacket'], 14: ['supervisor'], 15: ['defenders'] },
            why: { 11: '“steel-toed boots”', 12: '“Hard hats are required in the racking area.”', 13: '“insulated gloves and a thermal jacket”', 14: '“returned to the cold store supervisor”', 15: '“Ear defenders are compulsory in the packing hall.”' }
          },
          {
            type: 'flow', ins: 'Questions 16–20. Complete the flow-chart.', limit: 'Choose ONE WORD ONLY from the text for each answer.', title: 'Reporting an accident',
            steps: ['Make sure the area is [[16]] and nobody else is at risk', 'Call a first aider — names are on the noticeboard in the staff [[17]]', 'Record the injury in the accident book (kept at [[18]]) within 24 hours', 'Line manager completes an [[19]] form; copy sent to health and safety officer', 'More than seven [[20]] off work → company reports to the national safety authority'],
            key: { 16: ['safe'], 17: ['canteen'], 18: ['reception', '(the) reception desk'], 19: ['investigation'], 20: ['days'] },
            why: { 16: '“make sure the area is safe”', 17: '“the noticeboard in the staff canteen”', 18: '“kept at the reception desk”', 19: '“complete an investigation form”', 20: '“more than seven days off work”' }
          }
        ]
      },
      {
        title: 'Section 3', heading: 'The Bicycle: Two Centuries of Change', note: 'Questions 21–30',
        paras: [
          'The earliest ancestor of the bicycle appeared in Germany in 1817. Invented by Karl Drais, the "running machine" had two wheels in line but no pedals: riders pushed themselves along with their feet. It was briefly fashionable, but it was soon banned from pavements in several cities because riders frequently collided with pedestrians.',
          'Pedals arrived in the 1860s in France, attached directly to the front wheel. Because one turn of the pedals produced only one turn of the wheel, manufacturers made front wheels larger and larger in order to increase speed. The result was the "high-wheeler" of the 1870s, known in Britain as the penny-farthing, whose front wheel could be 1.5 metres in diameter. It was fast but dangerous: a sudden stop could throw the rider over the handlebars, and riding one was largely limited to athletic young men.',
          'The breakthrough came in 1885 with the "safety bicycle", which had two wheels of similar size and a chain that drove the rear wheel. Together with the air-filled tyre, patented a few years later by John Boyd Dunlop, it made cycling comfortable and safe enough for almost anyone. The 1890s saw a cycling boom. For women in particular, the bicycle offered a new independence, and it encouraged changes in clothing as long, heavy skirts gave way to more practical dress.',
          'In the twentieth century, the motor car pushed the bicycle to the margins in many wealthy countries, although it remained the main form of transport for millions of people in Asia. Interest revived from the 1970s, driven first by fuel shortages and later by concerns about health and the environment. Today, cities such as Copenhagen and Amsterdam are famous for their cycling infrastructure, and many other cities have introduced bike-sharing schemes. Electric bicycles, which use a battery-powered motor to assist the rider, have opened cycling to older people and to those living in hilly areas.'
        ],
        groups: [
          {
            type: 'mcq', ins: 'Questions 21–24. Choose the correct letter, A, B or C.',
            items: [
              { n: 21, q: 'Drais\'s running machine was banned from pavements because', opts: ['it was too expensive.', 'riders often hit people who were walking.', 'it damaged the road surface.'], a: 'B', why: '“riders frequently collided with pedestrians”.' },
              { n: 22, q: 'Front wheels of early pedal bicycles became larger in order to', opts: ['make them safer.', 'make them faster.', 'carry heavier loads.'], a: 'B', why: '“larger and larger in order to increase speed”.' },
              { n: 23, q: 'The high-wheeler was mainly ridden by', opts: ['women.', 'athletic young men.', 'older people.'], a: 'B', why: '“largely limited to athletic young men”.' },
              { n: 24, q: 'During the twentieth century, the bicycle', opts: ['disappeared from Asia.', 'remained important in parts of Asia.', 'was banned in wealthy countries.'], a: 'B', why: '“it remained the main form of transport for millions of people in Asia”.' }
            ]
          },
          {
            type: 'gap', layout: 'short', ins: 'Questions 25–27. Answer the questions below.', limit: 'Choose NO MORE THAN THREE WORDS from the text for each answer.',
            lines: ['Which part of the safety bicycle did the chain drive? [[25]]', 'Who patented the air-filled tyre? [[26]]', 'What first caused renewed interest in cycling in the 1970s? [[27]]'],
            key: { 25: ['(the) rear wheel', 'back wheel'], 26: ['(John Boyd) Dunlop', 'John Dunlop'], 27: ['fuel shortages', 'fuel shortage'] },
            why: { 25: '“a chain that drove the rear wheel”', 26: '“patented … by John Boyd Dunlop”', 27: '“driven first by fuel shortages”' }
          },
          {
            type: 'gap', layout: 'summary', ins: 'Questions 28–30. Complete the summary.', limit: 'Choose ONE WORD ONLY from the text for each answer.',
            lines: ['In the 1890s the bicycle gave women a new sense of [[28]] and led to changes in [[29]]. Today, [[30]] bicycles have made cycling possible for older people and those living in hilly areas.'],
            key: { 28: ['independence'], 29: ['clothing', 'dress'], 30: ['electric'] },
            why: { 28: '“the bicycle offered a new independence”', 29: '“changes in clothing”', 30: '“Electric bicycles … have opened cycling to older people”' }
          }
        ]
      }
    ]
  }
];
