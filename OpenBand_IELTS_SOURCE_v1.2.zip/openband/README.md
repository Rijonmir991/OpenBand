# OpenBand: Free IELTS Preparation

**Prepare Better. Practise More. Pay Nothing.**

OpenBand is a free IELTS preparation and mock test platform for IELTS Academic and General Training candidates, built especially with students in Bangladesh in mind. All modules, mock tests and learning tools are free. There are no subscriptions, premium locks or payment pages.

Developed by **MD REJON**.

---

## What's included

| Area | Features |
|---|---|
| **Homepage** | Hero section, "100% free" message, module cards, Academic/GT choice, daily practice, word of the day, latest tests, tips, progress preview, FAQ, footer with developer credit |
| **Dashboard** | Overall estimated band, per-module bands and progress bars, band-trend chart, study streak (7-day view), daily goal, recommended next practice, "continue where you left off", recent tests, saved words |
| **Listening** | 2 original tests (60 questions). Audio player (play/pause, progress bar, seeking, speed). Practice and timed modes; in timed mode each recording plays once. Form, note, table, sentence completion, map labelling, MCQ, matching. Transcripts, explanations, estimated band |
| **Reading** | Academic test (3 passages, 40 Q) and General Training test (30 Q). Split screen with a resizable divider, highlighting and notes, and tabs on mobile. TFNG, YNNG, headings, matching features/information, MCQ, sentence/summary/table/flow-chart completion, short answer |
| **Writing** | 17 tasks: Academic Task 1 (line, bar, pie, table, map, process, mixed), Task 2 (5 essay types), GT letters (formal, semi-formal, informal), GT essays. Editor with live word count, optional timer and autosave. Sample answers, task tips, writing history |
| **Writing feedback** | Automated text analysis across the 4 criteria: estimated band, strengths, weaknesses, grammar/usage issues, vocabulary suggestions, sentence and coherence suggestions, improvement plan, and a self-assessment form. **Clearly labelled as an estimate, not an AI evaluation** |
| **Speaking** | Part 1 (10 topics), Part 2 (12 cue cards with 1-minute prep and 2-minute timers), Part 3 discussion. Examiner questions read aloud, microphone recording, playback, recording history, optional live transcript (speech rate and filler-word count), mock speaking test, self-assessment |
| **Full mock test** | Academic or GT. Listening, then Reading, then Writing Task 1, then Task 2, with timers. Pause or resume between sections. Automatic marking, result summary, Writing estimate (Task 2 counts double), optional Speaking band, overall band, and full answer review |
| **Learning centre** | Daily words, 55 topic words with **Bangla meanings**, flashcards, vocabulary quiz, favourites, pronunciation, 7 grammar topics with instant checking, paraphrasing practice, sentence improvement, connectors and expressions, collocation quiz |
| **Band calculator** | Listening, Academic Reading and GT Reading raw-score conversion, Writing and Speaking input, overall band with the rounding explained, and editable conversion tables |
| **Test library** | 69 activities, with search, 9 categories and filters (Beginner, Intermediate, Advanced, Academic, General Training, Recently Added, Most Practised) |
| **Student accounts** | Free registration: name, roll/student ID, email and/or phone, password, target band, test type, institution, target country, exam date. Log in with email, phone or roll ID. Passwords are stored only as salted PBKDF2-SHA256 hashes. Each student has separate progress. Sign-in history (time, browser, OS, device). Profile editing, password change, backup/restore. Guests can still practise, and guest progress can move into a new account |
| **Admin (hidden)** | Password-only sign-in with no hints and growing lock-outs after wrong attempts. Includes: overview statistics, **Students** (search, filter, sort, profile, progress, sign-in history, edit, block/unblock, reset password, reset progress, delete, CSV export), **Notices** shown on student dashboards, content editors (tests, audio, writing, speaking, vocabulary, grammar), and site settings (tagline, banner, contact, registration on/off, require login for tests, certificate rule, band tables, admin password, wipe data) |
| **Certificate** | Students generate a printable certificate (mock test result or practice achievement) drawn from their real results. It has a certificate number, the developer's photo and signature, and a clear "practice certificate — not an official IELTS result" notice. Download as PNG, or print/save as PDF |
| **How to use** | Full step-by-step guide in **Bangla and English** (⋮ menu → How to use), with a 4-week study plan |
| **Bangla interface** | Menus, buttons, headings, messages, FAQ, tips, guide and dates appear in Bangla. Practice questions stay in English |
| **Everywhere** | Light and dark mode, Bangla/English interface, responsive from 360px up, keyboard focus styles, reduced-motion support, empty, loading and error states, confirmation before submitting |

All content (passages, scripts, questions, essays, cue cards) is **original**, not copied from official IELTS material. Countries in charts (Northland, Eastmere, Southport) and researchers in Reading Passage 2 are fictional.

### About the audio
Listening scripts are read aloud by the **browser's built-in speech engine** (Web Speech API). This means every test has working audio with no copyrighted recordings and no audio hosting. Voice quality depends on the device: Chrome and Edge on desktop or Android usually sound best. Admins can upload real recordings (MP3/M4A/WAV) for any custom test section.

### About scores
All bands are **estimates**. Raw-score conversion uses widely published IELTS tables (configurable in Admin, then Settings). The Writing analyser measures length, structure, linking, sentence variety, vocabulary range and common error patterns. It is not AI and cannot fully judge ideas. Speaking bands are self-assessed. OpenBand is not affiliated with IELTS, the British Council, IDP or Cambridge.

---

## Running it

**Option 1: open the file.** Open `dist/index.html` in Chrome, Edge or Firefox. Everything works except the Admin area, which needs HTTPS or localhost for secure hashing. Microphone recording also works best on localhost or HTTPS.

**Option 2: local server (recommended).**
```bash
cd dist
python3 -m http.server 8080
# open http://localhost:8080
```

**Developing.** Source files are in `src/`. Run a server in `src/` to load them separately (`src/index.html`), then rebuild the single-file bundle:
```bash
python3 build.py      # writes dist/index.html
```
No npm install or build tools are required. Python 3 is used only to bundle the files.

## Deploying
`dist/index.html` is a single self-contained file (about 370 KB) and can go on any static host:
- **Netlify / Vercel / Cloudflare Pages:** drag the `dist` folder into the dashboard, or set the publish directory to `dist`.
- **GitHub Pages:** commit `dist/index.html` as `index.html` on the `gh-pages` branch, or set Pages to serve `/dist`.
- **Any web server:** upload `index.html`.

Serve it over **HTTPS** so the microphone and Admin area work.

## Admin access
- The admin area is **not linked anywhere**. Open it by tapping **"Developed by MD REJON"** in the footer **5 times**, or go to `#/rejon-control`.
- Sign in with the admin password only (no username). The password itself is **not** in the source code. Only its PBKDF2-SHA256 hash (310,000 iterations) is stored in `src/core.js` (`ADMIN_DEFAULT`).
- A wrong password shows only "Wrong password." After 5 wrong attempts the form locks for 5 minutes, then 15, 45 and so on, up to 24 hours.
- Change the password in Admin → Site settings (stored as a new hash on that device). To change the built-in password for every deployment, generate a new hash:
  ```bash
  node -e "const c=require('crypto');const s=c.randomBytes(16).toString('hex');console.log(s, c.pbkdf2Sync('NEW-PASSWORD',s,310000,32,'sha256').toString('hex'))"
  ```
  Then put the salt and hash into `ADMIN_DEFAULT` and rebuild.

> **Important:** this is a static site, so all checks run in the visitor's browser. The lock-out stops casual guessing, but a 6-digit numeric password can be brute-forced offline by someone who downloads the code. Use a longer password (letters and numbers, 10+ characters) and, for real security, the server-side admin described below.

> **Where student data lives:** accounts and results are saved in each browser's local storage. In the admin panel you see every student who registered **on that same browser or device**, for example a coaching-centre computer. To see all students from every phone and PC in one place, connect the online database (next section).

## Folder structure
```
openband/
├── build.py              # bundles src/ into dist/index.html
├── dist/index.html       # the complete app (deploy this)
├── docs/schema.prisma    # suggested database schema for a backend
├── src/
│   ├── index.html        # dev entry (generated by build.py)
│   ├── styles.css        # design system: colours, components, dark mode, responsive
│   ├── core.js           # storage (per-student), accounts, admin hash, router, icons, band tables, marking, audio, timers
│   ├── i18n.js           # Bangla dictionary + interface translator, Bangla FAQ/tips
│   ├── accounts.js       # login/register, profile, certificate generator, how-to-use guide
│   ├── exam.js           # Listening/Reading engine: renderer, player, highlighter, review, results
│   ├── writing.js        # charts (SVG), editor, text analysis, feedback, history
│   ├── speaking.js       # recorder, Part 1/2/3, mock interview, self-assessment
│   ├── learn.js          # vocabulary, flashcards, quizzes, grammar, paraphrasing, collocations
│   ├── pages.js          # shell, home, dashboard, library, calculator, mock test, account, about
│   ├── admin.js          # admin auth and content management
│   ├── main.js           # boot
│   └── data/
│       ├── listening.js  # listening tests (scripts plus questions)
│       ├── reading.js    # reading tests (passages plus questions)
│       ├── content.js    # writing tasks, speaking, vocabulary, grammar, tips, FAQ
│       └── dev.js        # developer name + photo (MD REJON)
```

## Adding content
Tests are plain objects, and the admin editor validates them. Question group types:
- `gap`, with `layout`: `form` (`"Label|value [[n]]"`), `notes` (`#Heading` lines), `sentences`, `summary` or `short`, plus `key: {n: [accepted answers]}`. Optional words go in brackets: `"(the) library"`.
- `table` (`head`, `rows`), `flow` (`steps`), both using `[[n]]` gaps.
- `mcq` (`items[{n,q,opts,a,why}]`), `tfng`, `ynng`.
- `match` (`opts[{k,t}]`, `items[{n,q,a}]`). Add `image` (SVG) for map or diagram labelling.

## Connecting a backend (next step)
All data access goes through `OB.store` and `OB.auth` in `core.js`, so they can be swapped for an API client. A free **Firebase** (Auth + Firestore) or **Supabase** project is the quickest way to make student accounts work across all devices, so the admin sees every student. Suggested setup: **Next.js API routes, PostgreSQL and Prisma** (schema in `docs/schema.prisma`).

| Endpoint | Purpose |
|---|---|
| `POST /api/auth/register`, `/login`, `/logout` | Accounts. Hash passwords with bcrypt or argon2 and use HTTP-only session cookies |
| `GET /api/tests`, `GET /api/tests/:id` | Content (answer keys returned only after submission) |
| `POST /api/attempts` | Save results; server-side marking |
| `GET/PUT /api/progress`, `/api/drafts`, `/api/favourites` | Sync learner data |
| `POST /api/writing/evaluate` | **Optional AI evaluation.** The server calls the AI provider with a key kept in server environment variables. Never put API keys in frontend code. Label responses as estimates |
| `POST /api/speaking/upload` | Store recordings (object storage) |
| `/api/admin/*` | Admin CRUD, protected by a server-side role check |

Create the first admin with a seed script that reads `ADMIN_EMAIL` and `ADMIN_PASSWORD` from the environment and stores only a hash. Never hard-code credentials.

## Technology note
The brief preferred Next.js, TypeScript and Tailwind. This build is dependency-free vanilla JavaScript, because package installation was unavailable in the build environment. It is organised into modules by feature, with one storage layer and data-driven content, so porting to React or Next.js components and adding a backend is straightforward.

## Privacy
Accounts, progress, essays and saved words are stored in `localStorage` (passwords only as hashes). Audio recordings are stored in IndexedDB. Nothing is sent to any server. The optional live transcript uses the browser's own speech recognition service, which may process audio remotely (for example, Chrome sends it to Google). It is off by default.

---
*This platform was created to make IELTS preparation more accessible. Our goal is to help students practise, improve and prepare without financial barriers.*
**Developed by MD REJON**
