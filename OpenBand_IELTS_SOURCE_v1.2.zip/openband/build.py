#!/usr/bin/env python3
"""Bundle OpenBand into one self-contained HTML file: dist/index.html.
Also writes src/index.html for development (loads the separate source files).
Usage: python3 build.py
"""
from pathlib import Path

ROOT = Path(__file__).parent
SRC = ROOT / "src"
JS = ["core.js", "i18n.js", "data/dev.js", "data/listening.js", "data/reading.js", "data/content.js",
      "exam.js", "writing.js", "speaking.js", "learn.js", "accounts.js", "pages.js", "admin.js", "main.js"]

HEAD = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OpenBand — Free IELTS Preparation</title>
<meta name="description" content="Free IELTS preparation and mock tests: Listening, Reading, Writing and Speaking practice with instant marking. Prepare Better. Practise More. Pay Nothing.">
<meta name="theme-color" content="#14213D">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40'%3E%3Crect width='40' height='40' rx='12' fill='%233157D5'/%3E%3Crect x='9' y='22' width='5' height='9' rx='2.5' fill='%23fff'/%3E%3Crect x='17.5' y='16' width='5' height='15' rx='2.5' fill='%23fff'/%3E%3Crect x='26' y='9' width='5' height='22' rx='2.5' fill='%2372D6B2'/%3E%3C/svg%3E">
"""


def build():
    css = (SRC / "styles.css").read_text(encoding="utf-8")
    parts = []
    for f in JS:
        code = (SRC / f).read_text(encoding="utf-8")
        if "</script" in code.lower():
            raise SystemExit(f"{f} contains '</script' which would break inlining")
        parts.append(f"/* ===== {f} ===== */\n{code}")
    js = "\n".join(parts)
    noscript = '<noscript><p style="padding:24px;font-family:sans-serif">OpenBand needs JavaScript enabled.</p></noscript>'
    out = f"{HEAD}<style>\n{css}\n</style>\n</head>\n<body>{noscript}<div style=\"padding:40px;text-align:center;font-family:sans-serif;color:#5B6683\">Loading OpenBand…</div>\n<script>\n{js}\n</script>\n</body>\n</html>\n"
    (ROOT / "dist").mkdir(exist_ok=True)
    (ROOT / "dist" / "index.html").write_text(out, encoding="utf-8")
    dev = f"{HEAD}<link rel=\"stylesheet\" href=\"styles.css\">\n</head>\n<body>{noscript}\n" + "".join(f'<script src="{f}"></script>\n' for f in JS) + "</body>\n</html>\n"
    (SRC / "index.html").write_text(dev, encoding="utf-8")
    print(f"Built dist/index.html ({len(out) // 1024} KB) and src/index.html")


if __name__ == "__main__":
    build()
